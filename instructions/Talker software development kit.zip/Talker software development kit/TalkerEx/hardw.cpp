////////////////////////////////////////////////////////////////////////////
//
// Hardware interface class
//
// This code provides all of the basic, lower-level functionality needed to
//  communicate with whatever hardware is in use. The functions and other
//  aspects of this class will of course depend crucially upon how the
//  hardware being supported operates.

#include "stdafx.h"
#include "hardw.h"                             // Definitions of our stuff

////////////////////////////////////////////////////////////////////////////
//
// CHardIF - the code that handles all or most of the hardware-specific stuff
//
////////////////////////////////////////////////////////////////////////////
//! Constructor initialises member variables and sets up events and buffers
CHardIF::CHardIF()
{
    m_pWnd = nullptr;
    m_pTalk = nullptr;
    m_nNum = 0;                                 // The talker number, zero is default
    m_dRate = WAVE_RATE;
    m_bEventEn = true;
    m_nLevel = 0;
    m_bConnected = false;                       // At the moment we are disconnected
    m_bActive = false;                          // and therefore not active
    m_uLastCount = 0;                           // Initialise timing information
    m_dBlockTime = 0;
    m_dInitTime = 0;
}

//! Destructor makes sure we are disconnected and cleans up
CHardIF::~CHardIF()
{
    Disconnect();                               // Make sure we are disconnected
}

//! Connect to hardware
int CHardIF::Connect(CTalkIF* pTalk, CWnd* pWnd)
{
    m_csLastConErr.Empty();                     // Start off with no connection error
    if (Connected())                            // Cannot connect unless disconnected
    {
        m_csLastConErr = _T("Cannot connect when already connected");
        return DTE_BAD_STATE;
    }

    m_pTalk = pTalk;                            // Save pointer to the talker interface
    m_pWnd = pWnd;                              // Save the window for messages

    TRACE(_T("Connected to hardware\n"));

    SetConnected(true);                         // We are now connected
    Interrogate();                              // Find out what we have here; build the talker and channel info
    SetActive(false);                           //  and in the idle state
    return 0;
}

//! Shut down and disconnect from hardware
int CHardIF::Disconnect(bool bNotify)
{
    if (!Connected())                           // Do nothing if not connected
        return 0;
    if (m_bActive)                              // If sampling is in progress, kill it off
    {
        // TODO add code to kill sampling off
    }
    SetActive(false);
    if (bNotify)                                // Unless disabled, notify hardware
    {
        // TODO add code to notify hardware of closing connection, if needed
    }

    // TODO close connection to hardware

    SetConnected(false);                        // Tidy up the connection state information
    m_pWnd = nullptr;                           // Clean up and we are done
    m_pTalk = nullptr;
    return 0;
}

//! Check that comms with hardware appear to be OK, returns false if hardware gone
bool CHardIF::CheckComms()
{
    if (!Connected())                           // Do nothing if not connected
        return false;
    // TODO add code to return false if hardware appears to have gone, if possible
    return true;                                // Otherwise return true as all OK
}

//! reload information from the hardware
int CHardIF::Refresh()
{
    return Interrogate();                       // rebuild the talker and channel info
}

//! Return best estimate of current hardware time TODO make all necessary changes
// This is my current preferred mechanism for finding the current time for the
//  hardware to send to Spike2 for drift compensation. The idea is that m_uLastCount
//  holds the count of data points/blocks/whatever which gives us a data time when
//  divided by the rate. Then the value is adjusted using m_dBlockTime, which is the
//  time at which we got the data that set m_uLastCount, to give us our estimate of
//  the actual time now from the point-of-view of the hardware.
//
// The while loop is used because an obvious way of receiving data from the hardware
//  is to have a separate thread which polls for it or handles data reception. This
//  means that m_uLastCount and m_dBlockTime could change spontaneously when the other
//  thread does something, so we need to repeatedly find two times until they are the
//  same, which means they have not changed during the two calculations.
double CHardIF::Now()
{
    double dNow = 0;
    if (m_bActive)
    {
        double dN1, dN2;
        do                                      // The loop avoids problems
        {                                       // with data updating as we read it
            dN1 = (m_uLastCount / 1000.0) + (m_timer.Seconds()-m_dBlockTime);
            dN2 = (m_uLastCount / 1000.0) + (m_timer.Seconds()-m_dBlockTime);
        } while (fabs(dN1-dN2) > 1e-4);         // Keep going until the times match
        dNow = dN1;                             // Return our best time
    }
    return dNow;
}

///////////////////////////////////////////////////////////////////////////////
//
int CHardIF::MakeData(double dNow, std::vector<CString>& vcsInfo)
{
    // Event data is generated every 4 seconds, a burst of three events
    if (m_abActive[1] && ((dNow - m_dLast[1]) >= 4))
    {
        m_dLast[1] += 4;                        // Time for this event
        double dTime = m_dLast[1];

        CString wstr;
        wstr.Format(_T("Sending data packet for events at %g"), dTime);
        vcsInfo.push_back(wstr);

        DWORD dwSize = sizeof(TalkerData) + (sizeof(double) * 3);
        TalkerData* pHead = (TalkerData*)malloc(dwSize);
        if (pHead)
        {
            memset(pHead, 0, dwSize);           // Prepare the data packet
            pHead->nSize = (int)dwSize;         // The total data size
            pHead->nCode = TKC_TALKERDATA;
            pHead->nChan = 1;                   // The events are channel 1
            pHead->nItems = 3;
            pHead->dStart = dTime - 2;
            pHead->nItemSize = sizeof(double);

            double* pEvent = (double*)MovePtr(pHead, sizeof(TalkerData));
            *pEvent = dTime - 2;
            pEvent++;
            *pEvent = dTime - 1;
            pEvent++;
            *pEvent = dTime;

            pHead->dNow = dNow;                 // Packet send time last of all
            m_pTalk->SendBlock(pHead, dwSize);  // Send the data

            free(pHead);
        }
        else
            vcsInfo.push_back("Failed to allocate memory for talker event data");

        return 0;
    }

    /*    // ADC data at 1 KHz is generated in bursts every 2 seconds, each burst being 1 second long
        if (m_abActive[2] && ((dNow - m_dLast[2]) >= 2))
        {
            m_dLast[2] += 2;                    // Time for this data
            double dTime = m_dLast[2];

            CString wstr;
            wstr.Format("Sending data packet for ADC data at %d", dwTime);
            vcsInfo.Add(wstr);

            DWORD dwSize = sizeof(TalkerData) + (sizeof(short) * 1000);
            TalkerData* pHead = (TalkerData*)malloc(dwSize);
            if (pHead)
            {
                memset(pHead, 0, dwSize);           // Prepare the data packet
                pHead->nSize = (int)dwSize;         // The total data size
                pHead->nCode = TKC_TALKERDATA;
                pHead->nChan =  2;                  // The ADC data is channel 2
                pHead->nItems = 1000;
                pHead->dStart = dTime-1;
                pHead->dFinish = 1;                 // This is a separate block
                pHead->nItemSize = sizeof(short);

                short* pAdc = (short*)MovePtr(pHead, sizeof(TalkerData));
                for (int i = 0; i < 1000; ++i)
                    pAdc[i] = (i*50) - 25000;

                pHead->dNow = dNow;    // Packet send time last of all
                m_pTalk->SendBlock(pHead, dwSize);   // Send the data

                free(pHead);
            }
            else
                vcsInfo.Add("Failed to allocate memory for talker ADC data");

            return 0;
        }*/

    // ADC data at the selected rate is generated on a 25 second cycle, with 20 seconds of data and
    //  then a gap. Each packet is 1 second or so long.
    if (m_abActive[2] && ((dNow - m_dLast[2]) >= 1))
    {
        double dInt = 1.0 / m_dRate;
        double dTime = m_dLast[2];              // The time for the first data point
        double dCur = dNow;                     // The current time
        dCur = ((int)(dCur / dInt)) * dInt;     // Truncate to multiple of point interval
        int nPoints = 0;                        // Count of points to send

        double dPhase = fmod(dTime, 25);        // Phase in 25 second cycle at start time
        double dPN = fmod(dCur, 25);            // Phase we have reached now
        bool bOn = dPhase < 20;                 // We generate data for the first 20 seconds of each 25
        bool bOnEnd = dPN < 20;                 // On status at the end
        if (bOn)                                // If writing at the start
        {
            if (bOnEnd)
                nPoints = (int)floor(((dCur - dTime) / dInt) + 0.5);
            else
                nPoints = (int)floor(((20 - dPhase) / dInt) + 0.5);
        }
        else                                    // Here for not writing at the start
        {
            if (bOnEnd)
            {
                dTime += (25 - dPhase);         // Time for the firsdt point
                nPoints = (int)floor(((dCur - dTime) / dInt) + 0.5);
            }
        }
        m_dLast[2] = dCur;                      // Point time we have reached
        if (nPoints == 0)                       // All done if no data to send
            return 0;

        CString wstr;
        wstr.Format(_T("Sending data packet for ADC data at %g"), dTime);
        vcsInfo.push_back(wstr);

        DWORD dwSize = sizeof(TalkerData) + (sizeof(short) * nPoints);
        TalkerData* pHead = (TalkerData*)malloc(dwSize);
        if (pHead)
        {
            memset(pHead, 0, dwSize);           // Prepare the data packet
            pHead->nSize = (int)dwSize;         // The total data size
            pHead->nCode = TKC_TALKERDATA;
            pHead->nChan = 2;                   // The ADC data is channel 2
            pHead->nItems = nPoints;
            pHead->dStart = dTime;              // This is contiguous data
            pHead->nItemSize = sizeof(short);
            if (m_bWaveOn)                      // If already on then data is contiguous
                pHead->nFlags |= TDF_CONTIG;
            if (!bOnEnd)                        // If finishing a block, flush splining
                pHead->nFlags |= TDF_FLUSH;

            short* pAdc = (short*)MovePtr(pHead, sizeof(TalkerData));
            double dDat = (fmod(dTime, 1) * 50000) - 25000;
            for (int i = 0; i < nPoints; ++i)
            {
                pAdc[i] = (short)dDat;
                dDat += 50000.0 / m_dRate;
                if (dDat > 25000)
                    dDat -= 50000;
            }
            pHead->dNow = dNow;                 // Packet send time last of all
            m_pTalk->SendBlock(pHead, dwSize);  // Send the data
            free(pHead);
            m_bWaveOn = bOnEnd;                 // Save the current write state
        }
        else
            vcsInfo.push_back("Failed to allocate memory for talker ADC data");

        return 0;
    }

    // ADC marker data is generated every 50 ms, data items 25 ms apart
    if (m_abActive[3] && ((dNow - m_dLast[3]) >= 0.050))
    {
        m_dLast[3] += 0.050;                    // Time for this data
        double dTime = m_dLast[3];

        CString wstr;
        wstr.Format(_T("Sending data packet for ADC marker data at %g"), dTime);
        vcsInfo.push_back(wstr);

        DWORD dwSize = sizeof(TalkerData) + ((sizeof(TalkDataMarker) + (sizeof(short) * 64)) * 2);
        TalkerData* pHead = (TalkerData*)malloc(dwSize);
        if (pHead)
        {
            int i;
            memset(pHead, 0, dwSize);           // Prepare the data packet
            pHead->nSize = (int)dwSize;         // The total data size
            pHead->nCode = TKC_TALKERDATA;
            pHead->nChan = 3;                   // The channel is 3
            pHead->nItems = 2;
            pHead->dStart = dTime - 0.025;
            pHead->nItemSize = sizeof(TalkDataMarker) + (sizeof(short) * 64);

            TalkDataMarker* pMark = (TalkDataMarker*)MovePtr(pHead, sizeof(TalkerData));
            pMark->lMark = 1;
            pMark->dTime = dTime - 0.025;
            short* pS = (short*)MovePtr(pMark, sizeof(TalkDataMarker));
            for (i = 0; i < 16; ++i)
            {
                pS[i * 2] = (short)(i * 500);
                pS[(i * 2) + 1] = (short)(i * -500);
            }
            for (i = 0; i < 16; ++i)
            {
                pS[(i * 2) + 32] = (short)((16 - i) * 500);
                pS[(i * 2) + 33] = (short)((16 - i) * -500);
            }

            pMark = (TalkDataMarker*)MovePtr(pMark, pHead->nItemSize);
            pMark->lMark = 2;
            pMark->dTime = dTime;
            pS = (short*)MovePtr(pMark, sizeof(TalkDataMarker));
            for (i = 0; i < 16; ++i)
            {
                pS[i * 2] = (short)(i * -500);
                pS[(i * 2) + 1] = (short)(i * 500);
            }
            for (i = 0; i < 16; ++i)
            {
                pS[(i * 2) + 32] = (short)((16 - i) * -500);
                pS[(i * 2) + 33] = (short)((16 - i) * 500);
            }

            pHead->dNow = dNow;                 // Packet send time last of all
            m_pTalk->SendBlock(pHead, dwSize);  // Send the data
            free(pHead);
        }
        else
            vcsInfo.push_back("Failed to allocate memory for talker ADCMark data");

        return 0;
    }

    // Real marker data is generated ever 100 ms
    if (m_abActive[4] && ((dNow - m_dLast[4]) >= 0.100))
    {
        m_dLast[4] += 0.100;                    // Time for this data
        double dTime = m_dLast[4];

        CString wstr;
        wstr.Format(_T("Sending data packet for real wave data at %g"), dTime);
        vcsInfo.push_back(wstr);

        DWORD dwSize = sizeof(TalkerData) + sizeof(TalkDataMarker) + (sizeof(double) * 2);
        TalkerData* pHead = (TalkerData*)malloc(dwSize);
        if (pHead)
        {
            memset(pHead, 0, dwSize);           // Prepare the data packet
            pHead->nSize = (int)dwSize;         // The total data size
            pHead->nCode = TKC_TALKERDATA;
            pHead->nChan = 4;                   // The channel is 4
            pHead->nItems = 1;
            pHead->dStart = dTime;
            pHead->nItemSize = sizeof(TalkDataMarker) + (sizeof(double) * 2);

            TalkDataMarker* pMark = (TalkDataMarker*)MovePtr(pHead, sizeof(TalkerData));
            pMark->lMark = ((int)(m_dLast[4] / 0.100)) & 1;
            pMark->dTime = dTime;
            double* pD = (double*)MovePtr(pMark, sizeof(TalkDataMarker));
            pD[0] = fmod(dTime, 20);
            pD[1] = dTime;

            pHead->dNow = dNow;                 // Packet send time last of all
            m_pTalk->SendBlock(pHead, dwSize);  // Send the data
            free(pHead);
        }
        else
            vcsInfo.push_back("Failed to allocate memory for talker RealMark data");

        return 0;
    }

    // Real wave data at 2.3 KHz is generated in bursts every second, each burst being 0.5 second long
    if (m_abActive[6] && ((dNow - m_dLast[6]) >= 1))
    {
        m_dLast[6] += 1;                        // Time for this data
        double dTime = m_dLast[6];

        CString wstr;
        wstr.Format(_T("Sending data packet for real wave data at %g"), dTime);
        vcsInfo.push_back(wstr);

        DWORD dwSize = sizeof(TalkerData) + (sizeof(double) * 1000);
        TalkerData* pHead = (TalkerData*)malloc(dwSize);
        if (pHead)
        {
            memset(pHead, 0, dwSize);           // Prepare the data packet
            pHead->nSize = (int)dwSize;         // The total data size
            pHead->nCode = TKC_TALKERDATA;
            pHead->nChan = 6;                   // The channel is 6
            pHead->nItems = 1000;
            pHead->dStart = dTime - (1000.0 / RWAVE_RATE);
            pHead->nFlags = TDF_FLUSH;
            pHead->nItemSize = sizeof(double);

            double* pDWave = (double*)MovePtr(pHead, sizeof(TalkerData));
            for (int i = 0; i < 1000; ++i)
                pDWave[i] = (i / 125.0) - 4;

            pHead->dNow = dNow;                 // Packet send time last of all
            m_pTalk->SendBlock(pHead, dwSize);  // Send the data
            free(pHead);
        }
        else
            vcsInfo.push_back(_T("Failed to allocate memory for talker RealWave data"));

        return 0;
    }
    return 0;
}

/*!
Handle any remaining packets of data at the end of sampling as this talker
has been told to stop. We generate extra ADC data to demonstrate this.
*/
void CHardIF::MakeLastData(double dEnd, std::vector<CString>& vcsInfo)
{
    if (!m_abActive[2]) return;                 // Nothing to do if ADC data is off
    double dInt = 1.0 / m_dRate;
    double dTime = m_dLast[2];                  // The time for the first data point
    double dNow = ((int)(dEnd / dInt)) * dInt;  // Truncate to multiple of point interval
    int nPoints = 0;                            // Count of points to send

    double dPhase = fmod(dTime, 25);            // Phase in 25 second cycle at start time
    double dPN = fmod(dNow, 25);                // Phase we have reached now
    bool bOn = dPhase < 20;                     // We generate data for the first 20 seconds of each 25
    bool bOnEnd = dPN < 20;                     // On status at the end
    if (bOn)                                    // If writing at the start
    {
        if (bOnEnd)
            nPoints = (int)floor(((dNow - dTime) / dInt) + 0.5);
        else
            nPoints = (int)floor(((20 - dPhase) / dInt) + 0.5);
    }
    else                                        // Here for not writing at the start
    {
        if (bOnEnd)
        {
            dTime += (25 - dPhase);             // Time for the first point
            nPoints = (int)floor(((dNow - dTime) / dInt) + 0.5);
        }
    }
    m_dLast[2] = dNow;                          // Point time we have reached
    if (nPoints > 0)                            // Data to send?
    {
        CString str;
        str.Format(_T("Sending data packet for ADC data at %g"), dTime);
        vcsInfo.push_back(str);

        DWORD dwSize = sizeof(TalkerData) + (sizeof(short) * nPoints);
        TalkerData* pHead = (TalkerData*)malloc(dwSize);
        if (pHead)
        {
            memset(pHead, 0, dwSize);           // Prepare the data packet
            pHead->nSize = (int)dwSize;         // The total data size
            pHead->nCode = TKC_TALKERDATA;
            pHead->nChan = 2;                   // The ADC data is channel 2
            pHead->nItems = nPoints;
            pHead->dStart = dTime;              // This is contiguous data
            pHead->nItemSize = sizeof(short);
            if (m_bWaveOn)                      // If already on then data is contiguous
                pHead->nFlags |= TDF_CONTIG;
            pHead->nFlags |= TDF_FLUSH;         // Always set the flush flag when finishing

            short* pAdc = (short*)MovePtr(pHead, sizeof(TalkerData));
            double dDat = (fmod(dTime, 1) * 50000) - 25000;
            for (int i = 0; i < nPoints; ++i)
            {
                pAdc[i] = (short)dDat;
                dDat += 50000.0 / m_dRate;
                if (dDat > 25000)
                    dDat -= 50000;
            }
            pHead->dNow = dEnd;                 // Packet send time last of all
            m_pTalk->SendBlock(pHead, dwSize);  // Send the data
            free(pHead);
            m_bWaveOn = bOnEnd;                 // Save the current write state
        }
        else
            vcsInfo.push_back("Failed to allocate memory for talker ADC data");
    }
}

/*!
Generate an error record, save it in the queue and notify the window of it.
\param  csErr    A string describing the error in a human-friendly fashion
\param  nLevel   Error level (0 to 3, being info, warning, error and critical)
\param  nChan    The channel number to which the error applies or -1 for all channels
\param  nCode    The (presumed negative) error code
*/
void CHardIF::LogError(const CString& csErr, int nLevel, int nChan, int nCode)
{
    CTalkErr err(csErr, nLevel, nChan, nCode);  // Build error information object
    m_errs.save(err);                           // Save it in the queue
}

//! Get the talker name - must be ASCII so don't do anything weird
CString CHardIF::Name() const
{
    CString str = TALK_NAME;                    // Get the basic talker name
    if (m_nNum > 0)                             // Append number if necessary
        str.Format(_T("%s%d"), TALK_NAME, m_nNum);  // just simple numeric text
    return str;
}

//! Get the number of talker channels available
int CHardIF::Chans()
{
    return (int)m_vChans.size();                // Channel count equals vector size
}

//! Return the general talker information
int CHardIF::Talk(TalkerInfo& talk)
{
    if (!Connected() || (Chans() <= 0))         // Return error if not connected to good hardware
        return DTE_NO_HW;

    // Return information about this talker as generated by Interrogate function
    talk = m_rInfo;                             // Start off with the basic info
    CStringA astr(Name());                      // We need the name as ASCII
    strcpy_s(talk.szName, TALK_NAME_SZ, astr.GetString()); // The name, might have number added
    talk.nChans = Chans();                      // The number of channels
    return 0;
}

//! Return the information about a talker channel
int CHardIF::Chan(int nChan, TalkerChanInfo& chan)
{
    if (!Connected() || (Chans() <= 0))         // Return error if not connected to good hardware
        return DTE_NO_HW;
    if ((nChan < 0) || (nChan >= Chans()))      // or if channel number is stupid
        return DTE_NO_HW;

    // Return information about this channel as generated by Interrogate function
    chan = m_vChans[nChan];                     // Copy all the information across
    chan.nChan = nChan;                         // Make sure the channel number is correct
    return 0;
}

/*! Return information about the configuraion dialog
\param  dlg     Structure to hold dialog information.
\return         0 or a -ve error code.
*/
int CHardIF::Dlg(TalkerDlgInfo& dlg)
{
    dlg.nItems = 4;                             // Number of dialog items
    dlg.dHigh = 0;                              // Fix the dialog width too
    dlg.dWide = 50;
    strcpy_s(dlg.szTitle, sizeof(dlg.szTitle), "TalkerEx configuration");
    return 0;
}

/*! Return information about a dialog item
\param  nItem   The item number.
\param  item    Structure to hold dialog item information.
\return         0 or a -ve error code.
*/
int CHardIF::DlgItem(int nItem, TalkerDlgItem& item)
{
    item.nItem = nItem;                         // The dialog item must be set
    switch (nItem)                              // Rest according to the item
    {
    case 0:                                     // Item 0 is a real with waveform rate
        item.nType = TDT_REAL;                  // Set the type code
        strcpy_s(item.szText, sizeof(item.szText), "ADC waveform rate (Hz)");
        item.dLo = 10;
        item.dHi = 5000;
        item.dSpin = 10;
        item.nPre = 2;
        break;
    case 1:                                     // Item 1 is a groupbox
        item.nType = TDT_GROUP;                 // Set the type code
        item.dX = 0.6;
        item.dY = 2.0;
        item.dWide = 49.2;
        item.dHigh = 3.2;
        strcpy_s(item.szText, sizeof(item.szText), "Event channels");
        break;
    case 2:                                     // Item 2 is a checkboxes
        item.nType = TDT_CHECK;                 // Set the type code
        strcpy_s(item.szText, sizeof(item.szText), "Enable event channel");
        break;
    case 3:                                     // Item 3 is a list
        item.nType = TDT_LIST;                  // Set the type code
        strcpy_s(item.szText, sizeof(item.szText), "Initial level");
        strcpy_s(item.szList, sizeof(item.szList), "Low|High");
        break;
    default:                                    // This should never happen
        ASSERT(FALSE);
        break;
    }
    return 0;
}

/*! Return or save dialog item value
\param  bGet    True to get current value, false to set new value
\param  nItem   The item number.
\param  pkt     Structure holding or to hold relevant value.
\return         0 or a -ve error code.
*/
int CHardIF::DlgValue(bool bGet, int nItem, TalkPacket& pkt)
{                                               // TODO Change the code to match the parameters needed
    if (bGet)
        pkt.nParam1 = nItem;                    // The item number must be returned if reading
    switch (nItem)                              // Values according to the item
    {
    case 0:                                     // Item 0 is wave rate
        if (bGet)                               // Read or write according to bGet
            pkt.dParam1 = m_dRate;
        else
            m_dRate = pkt.dParam1;
//        wstr.Format("DlgGet command received, item %d, value %g", pPkt->nParam1, pkt.dParam1);
//        csInfo.Add(wstr);
        break;
    case 2:                                     // Item 2 is the event enable
        if (bGet)                               // Read or write according to bGet
            pkt.nParam2 = m_bEventEn ? 1 : 0;
        else
            m_bEventEn = pkt.nParam2 != 0;
//        wstr.Format("DlgGet command received, item %d, value %d", pPkt->nParam1, pkt.nParam2);
//        csInfo.Add(wstr);
        break;
    case 3:                                     // Item 6 is the initial level
        if (bGet)                               // Read or write according to bGet
            pkt.nParam2 = m_nLevel;
        else
            m_nLevel = pkt.nParam2;
        break;
//        wstr.Format("DlgGet command received, item %d, value %d", pPkt->nParam1, pkt.nParam2);
//        csInfo.Add(wstr);
        break;
    default:                                    // This should never happen
        ASSERT(FALSE);                          // Unless the case statement does not match dialog item count
        break;
    }
    return 0;
}

/*!
Return XML item information. The szName and nType parts of xnv should be set to the
item name (as used in XML file) and type, respectively. The nVal, dVal or szText
parts of xnv (according to the type) should be set to the either the current value
or the default value of the parameter. Set nType to -1 if nItem is out-of-range,
this will indicate to Spike2 that there are no more XML items.
\param  bGet    True to get current value, false to get default value.
\param  nItem   The item number.
\param  xnv     Structure to hold the required information.
\return         0 or a -ve error code.
*/
int CHardIF::XmlNameValue(bool bGet, int nItem, TalkerXMLNameVal& xnv)
{                                               // TODO Change the code to match the parameters needed
    xnv.nItem = nItem;                          // Must always return the item number
    switch (nItem)
    {
    case 0:                                     // First parameter is waveform rate
        strcpy_s(xnv.szName, sizeof(xnv.szName), "WRate");
        xnv.nType = 1;                          // Value to indicate a real value
        xnv.dVal = bGet ? m_dRate : WAVE_RATE;
        break;
    case 1:                                     // Next is event channel enable
    {
        strcpy_s(xnv.szName, sizeof(xnv.szName), "EvtEn");
        xnv.nType = 0;                          // Value to indicate an integer
        xnv.nVal = bGet ? (m_bEventEn ? 1 : 0) : 1;
        break;
    }
    case 2:                                     // Next is item selecting initial direction
        strcpy_s(xnv.szName, sizeof(xnv.szName), "IDir");
        xnv.nType = 0;                          // Value to indicate an integer
        xnv.nVal = bGet ? m_nLevel : 0;
        break;
    default:
        xnv.nType = -1;                         // Return -1 to indicate no more parameters
        break;
    }
    return 0;
}

/*!
Save configuration value read from XML. The nParam2, dParam1 or szParam parts
parts of pkt (according to the type) hold the new value of the parameter.
\param  nItem   The item number.
\param  pkt     Structure with the new parameter value in it.
\return         0 or a -ve error code.
*/
int CHardIF::XmlValue(int nItem, TalkPacket& pkt)
{
    switch (nItem)
    {
    case 0:                                     // First parameter is waveform rate
        m_dRate = pkt.dParam1;
        break;
    case 1:                                     // Next is event channel enable
        m_bEventEn = pkt.nParam2 != 0;
        break;
    case 2:                                     // Next is level item (initial direction)
        m_nLevel = pkt.nParam2;
        break;
    default:                                    // This should never happen
        ASSERT(FALSE);                          // Unless the case statement does not match XmlNameValue
        break;
    }
    return 0;
}

//! Deal with initialisation of sampling information
int CHardIF::SampleClear()
{
    for (int i = 0; i < NUMCHANS; ++i)          // Clear all channel active flags
        m_abActive[i] = false;
    m_dInitTime = m_timer.Seconds();            // Save the time for this
    return 0;
}

//! Deal with channel enabling for sampling. Return value is zero if all is
//  OK or -1 if the channel is somehow unavailable.
int CHardIF::EnableChan(int nChan)
{
    if ((nChan == 1) && !m_bEventEn)            // Channel controlled by enable?
        return -1;                              // Say channel is off if not enabled...
    else if ((nChan >= 0) && (nChan < NUMCHANS)) // prevent trampling
        m_abActive[nChan] = true;
    return 0;
}

//! Deal with query if ready to sample. Return value 1 if ready, 0 if not yet
//  or -1 if unable to sample
int CHardIF::QueryReady()
{
    bool bActive = false;
    for (int i = 0; i < NUMCHANS; ++i)
        if (m_abActive[i])
            bActive = true;
    bool bReady = true;
    if (bActive)
        bReady = (m_timer.Seconds() > (m_dInitTime + 5));
    return bReady ? 1 : 0;
}

/*!
Start sampling or stop it
\param  bStart  True to start sampling, false to stop
\return         0 or a -ve error code
*/
int CHardIF::Sample(bool bStart)
{
    if (bStart)                                 // Do a bit of extra setup before starting
    {
        //m_dTimeZero = m_timer.Seconds();
        for (int i = 0; i < NUMCHANS; ++i)      // Initialise last data times for all channels
            m_dLast[i] = 0;
        m_bWaveOn = false;                      // Waveform output not on-going
    }
    else
    {
        // TODO add code to stop sampling, log error if this fails
    }
    return 0;
}

//! 
/*!
Retrieve and save (locally) information about talker and available channels
\return         0 or a -ve error code
*/
int CHardIF::Interrogate()
{
    int nRes = 0;

    // Here we load up the structure with information about this talker
    m_rInfo.nChans = NUMCHANS;                  // Number of channels
    m_rInfo.nVer = 120;                         // Version 1.20 - supports spec version 4
    CStringA astr(Name());                      // We need our name as ASCII
    strcpy_s(m_rInfo.szName, TALK_NAME_SZ, astr.GetString()); // The talker name
    strcpy_s(m_rInfo.szDesc, TALK_DESC_SZ, "Example talker for testing");
    m_rInfo.nVerComp = 100;                     // Compatible with version 1.00 and later
    m_rInfo.nConfigID = 1;                      // Test config data
    m_rInfo.nFlags = m_pTalk->IsRemote() ? TKF_REMOTE : 0;  // Tell Spike2 if we are remote
    m_rInfo.nFlags |= TKF_SPCONF;               //  we use Spike2-based config dialog
    m_rInfo.nFlags |= TKF_ACTALL;               //  and we want to be activated allways

    m_vChans.clear();                           // Get rid of all channel information
    for (int i = 0; i < NUMCHANS; ++i)
    {
        TalkerChanInfo rChan;                   // Clean talker channel info
        switch (i)                              // This keeps things a bit organised
        {
        case 0:                                 // Channel 0 is the marker data
            rChan.nType = TCT_MARKER;           // Simple marker data
            rChan.nFlags =  0;
            strcpy_s(rChan.szDesc, sizeof(rChan.szDesc), "Markers generated from the menu");
            strcpy_s(rChan.szTitle, sizeof(rChan.szTitle), "Codes");
            rChan.dIRate = 1;
            break;
        case 1:                                 // Channel 1 is the event data
            rChan.nType = TCT_EVENT;            // Event data at 4 second intervals
            rChan.nFlags = m_bEventEn ? 0 : TCF_UNAVAIL;
            strcpy_s(rChan.szDesc, sizeof(rChan.szDesc), "Events generated at fixed time intervals");
            strcpy_s(rChan.szTitle, sizeof(rChan.szTitle), "Ticks");
            rChan.dIRate = 0.25;
            break;
        case 2:                                 // Channel 2 is ADC data
            rChan.nType = TCT_ADC;              // ADC data
            rChan.nFlags = 0;
            strcpy_s(rChan.szDesc, sizeof(rChan.szDesc), "Example ADC data at specified rate");
            strcpy_s(rChan.szTitle, sizeof(rChan.szTitle), "Wave");
            rChan.dIRate = 1;
            rChan.dScale = 1;
            rChan.dOffset = 0;
            strcpy_s(rChan.szUnits, sizeof(rChan.szUnits), "Volts");
            rChan.dWRate = m_dRate;
            break;

        case 3:                                 // Channel 3 is ADCMARK data
            rChan.nType = TCT_ADCMARK;          // ADCMARK data
            rChan.nFlags = 0;
            strcpy_s(rChan.szDesc, sizeof(rChan.szDesc), "Example WaveMark data at 10 kHz");
            strcpy_s(rChan.szTitle, sizeof(rChan.szTitle), "AMark");
            rChan.dIRate = 100;
            rChan.dScale = 1000;
            rChan.dOffset = 0;
            strcpy_s(rChan.szUnits, sizeof(rChan.szUnits), "mV");
            rChan.nCount = 32;
            rChan.nTrig = 8;
            rChan.nTrace = 2;                   // Two traces to test handling
            rChan.dWRate = 9000;                // Rate to test interpolation
            break;

        case 4:                                 // Channel 4 is REALMARK data
            rChan.nType = TCT_REALMARK;         // REALMARK data
            rChan.nFlags = 0;
            strcpy_s(rChan.szDesc, sizeof(rChan.szDesc), "Example RealMark data at 10 Hz");
            strcpy_s(rChan.szTitle, sizeof(rChan.szTitle), "RMark");
            rChan.dIRate = 10;
            rChan.dMax = 10;
            rChan.dMin = -10;
            strcpy_s(rChan.szUnits, sizeof(rChan.szUnits), "Arb");
            rChan.nCount = 2;
            break;
        case 5:                                 // Channel 5 is TEXTMARK data
            rChan.nType = TCT_TEXTMARK;         // TEXTMARK data
            rChan.nFlags = 0;
            strcpy_s(rChan.szDesc, sizeof(rChan.szDesc), "Example TextMark data");
            strcpy_s(rChan.szTitle, sizeof(rChan.szTitle), "Note");
            rChan.dIRate = 1;
            strcpy_s(rChan.szUnits, sizeof(rChan.szUnits), "Text");
            rChan.nCount = 60;
            break;
        case 6:                                 // Channel 6 is Real wave data
            rChan.nType = TCT_REALWAVE;         // Realwave data
            rChan.nFlags = 0;
            strcpy_s(rChan.szDesc, sizeof(rChan.szDesc), "Example Real wave data at 2300 Hz");
            strcpy_s(rChan.szTitle, sizeof(rChan.szTitle), "RWave");
            rChan.dIRate = 1;
            rChan.dScale = 1;
            rChan.dOffset = 0;
            strcpy_s(rChan.szUnits, sizeof(rChan.szUnits), "Volts");
            rChan.dWRate = RWAVE_RATE;
            break;
        case 7:                                 // Channel 7 is the level data
            rChan.nType = TCT_LEVEL;            // Event data
            rChan.nFlags = TCF_S2TIMED;         // We will generate these with keyboard data, Spike2 times
            strcpy_s(rChan.szDesc, sizeof(rChan.szDesc), "Level toggles with each keyboard marker");
            strcpy_s(rChan.szTitle, sizeof(rChan.szTitle), "Level");
            rChan.dIRate = 0.25;
            break;
        default:
            break;
        }
        m_vChans.push_back(rChan);
    }

    return nRes;
}