//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by talkerex.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define ID_INDICATOR_CONNECT            129
#define ID_INDICATOR_TIME               130
#define ID_INDICATOR_SAMPLING           131
#define ID_INDICATOR_BLANK              132
#define ID_INDICATOR_SERVER             133
#define IDD_CONSET                      310
#define IDB_TOOLBARL                    311
#define IDD_DRIFTOPT                    312
#define IDD_LOCCONFIG                   313
#define IDD_ARBCMD                      314
#define IDC_MACHINE                     1000
#define IDC_TNUM                        1001
#define IDC_DRDEBUG                     1002
#define IDC_YSCALE                      1003
#define IDC_XSCALE                      1004
#define IDC_CMD                         1005
#define IDM_RECONNECT                   32765
#define IDM_REFRESH                     32766
#define IDM_CONSET                      32767
#define IDM_DRIFTOPT                    32768
#define ID_FILE_CONNECT                 32771
#define ID_FILE_DISCONNECT              32772
#define ID_FILE_AUTO                    32773
#define ID_EDIT_CODE0                   32774
#define ID_EDIT_CODE1                   32775
#define ID_EDIT_CODE2                   32776
#define ID_EDIT_CODE3                   32777
#define ID_EDIT_TEXTMARKER              32778
#define ID_EDIT_PROBLEM                 32779
#define ID_EDIT_SENDSTRING              32780
#define ID_FILE_STARTSAMPLINGCOMMAND    32781
#define ID_FILE_STOPSAMPLINGCOMMAND     32782
#define ID_FILE_STARTSAMPLING           32783
#define ID_FILE_STOPSAMPLING            32784
#define ID_FILE_ABORTSAMPLING           32785
#define ID_FILE_ARBITRARYCOMMAND        32786
#define ID_FILE_ARBCMD                  32787

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           315
#endif
#endif
