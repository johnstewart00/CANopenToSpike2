#pragma once

////////////////////////////////////////////////////////////////////////////
//
// CLocConfDlg dialog is a dummy local configuration dialog
//
class CLocConfDlg : public CDialog
{
	DECLARE_DYNAMIC(CLocConfDlg)

public:
	CLocConfDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CLocConfDlg();

    // Dialog Data
	enum { IDD = IDD_LOCCONFIG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////////////////////
//
// CCmdDlg dialog to enter an arbitrary Spike2 command
//
class CCmdDlg : public CDialog
{
	DECLARE_DYNAMIC(CCmdDlg)

public:
	CCmdDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCmdDlg();

    // Dialog Data
	enum { IDD = IDD_ARBCMD };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedOk();
    afx_msg void OnEnChangeCmd();
};
