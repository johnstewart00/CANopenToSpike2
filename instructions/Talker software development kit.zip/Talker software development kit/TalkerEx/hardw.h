////////////////////////////////////////////////////////////////////////////
//
// hardw.h
//
// Defines for code that manages connection and communication with the
// specific hardware supported by this talker.
//
// Written 2017 by Cambridge Electronic Design Ltd, freely available.
//
// Started 30/May/2016 by TDB
//
#pragma once
#ifndef __HARDW_H__
#define __HARDW_H__

#include "..\common\s2talk.h"                   //!< Talker interface defines
#include "..\common\talkif.h"                   //!< The talker interface object

constexpr char const* TALK_NAME = "TalkerEx";   //!< Our talker name

constexpr int  NUMCHANS = 8;                    //!< The number of (fake) talker channels

// These are the default ADC (integer) data rate and the fixed rate for the realwave data
constexpr int WAVE_RATE = 1100;
constexpr int RWAVE_RATE = 2300;

// Error codes, we start these at -40 to avoid other error code values.
enum eErrCodesH
{
    DTE_NO_HW = -40,                            // The hardware was not found or has closed connection
    DTE_BAD_STATE = -41,                        // Talker idle when should be active or vice-versa
    DTE_NO_MEMORY = -42,                        // Memory or resource shortage caused failure
    DTE_FAILURE = -43                           // Transmission or receive failure
};

//! The class that handles communications with the hardware
/*!
This class will need substantial redesign to adapt it to the particular
behaviour of the hardware. The idea is that all of the hardware-specific
aspects of the talker can be encapsulated here, but inevitably these will
affect other aspects of the software such as the menu functions available.
*/
class CHardIF
{
public:
    CHardIF();
    virtual ~CHardIF();

    // Functions to connect to hardware and disconnect
    int             Connect(CTalkIF* pTalk, CWnd* pWnd);
    int             Disconnect(bool bNotify = true); //!< Undo connection process
    bool            CheckComms();               //!< Check that we can still communicate
    int             Refresh();                  //!< Re-read hardware information
    double          Now();                      //!< Get best estimate of current hardware time

    int             MakeData(double dNow, std::vector<CString>& vcsInfo);
    void            MakeLastData(double dEnd, std::vector<CString>& vcsInfo);

    // Error information access functions
    int             Errors(){return m_errs.errors();}   //!< Get the stored error count
    CTalkErr        GetError(){return m_errs.get();}    //!< Get the oldest error from the top of the queue
    CString         LastConErr() const {return m_csLastConErr;} //!< Get info on last connect failure

    // Other functions should be put here TODO add necessary functions
    CString         Name() const;                       //!< The talker name - must be ASCII only
    void            SetNum(int num){m_nNum = num;}      //!< Set and get the talker number
    int             Num() const {return m_nNum;}
    int             Chans();                            //!< Count of talker channels available
    int             Talk(TalkerInfo& talk);             //!< Fill in overall talker information
    int             Chan(int nChan, TalkerChanInfo& chan);  //!< Fill in talker channel information
    int             Dlg(TalkerDlgInfo& dlg);                //!< Fill in information about the configuration dialog
    int             DlgItem(int nItem, TalkerDlgItem& item); //!< Fill in information about a dialog item
    int             DlgValue(bool bGet, int nItem, TalkPacket& pkt); //!< Return or save dialog item value
    int             XmlNameValue(bool bGet, int nItem, TalkerXMLNameVal& xnv); //!< Return XML item information
    int             XmlValue(int nItem, TalkPacket& pkt);   //!< Save configuration value read from XML
    int             SampleClear();                      //!< Deal with sampling initialisation
    int             EnableChan(int nChan);              //!< Deal with channel enable
    int             QueryReady();                       //!< Deal with sampling query ready
    int             Sample(bool bStart);                //!< Start or stop sampling

    // State access
    bool            Connected() const {return m_bConnected;}
    void            SetConnected(bool bConnect){m_bConnected = bConnect;}
    bool            Active() const {return m_bActive;}
    void            SetActive(bool bActive){m_bActive = bActive;}

    bool            ChanActive(int n) const {return m_abActive[n];}  //!< Test for a channel being active
    int             LevelPar() const {return m_nLevel;}

protected:

private:
    int             Interrogate();              //!< Read back all information about the hardware
    void            LogError(const CString& csErr, int nLevel, int nChan, int nCode); //!< Save error and generate notification

    CTalkTimer      m_timer;                    //!< High-accuracy timer
    CTalkIF*        m_pTalk;                    //!< Talker interface pointer
    CWnd*           m_pWnd;                     //!< Window to receive notification messages
    int             m_nNum;                     //!< The hardware number if used - default zero

    // The basic talker information, and the information about channels
    TalkerInfo      m_rInfo;                    //!< Information about the talker
    std::vector<TalkerChanInfo> m_vChans;       //!< A vector holding the channel information

    double          m_dInitTime;                // Time of sample clear (for ready simulation)
    bool            m_abActive[NUMCHANS];       // Array of channel in use flags
    double          m_dLast[NUMCHANS];          // Last time data for channels
    bool            m_bWaveOn;                  // Flag controlling the waveform data

    // Here we have our example configuration parameters
    double          m_dRate;                    // Waveform data rate
    int             m_bEventEn;                 // Enable for event channel
    int             m_nLevel;                   // Initial direction for level chan

    CString         m_csLastConErr;             //!< Info string for last failure to connect
    volatile bool   m_bConnected;               //!< True if we are connected
    volatile bool   m_bActive;                  //!< True if sampling is active
    volatile unsigned int m_uLastCount;         //!< Point count for last received data
    volatile double m_dBlockTime;               //!< Time at which last data was recieved

    CErrQ           m_errs;                     //!< The queue holding our errors
};

#endif
