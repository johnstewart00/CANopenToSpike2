////////////////////////////////////////////////////////////////////////////
//
// LocConfDlg.cpp : implementation file
//
#include "stdafx.h"
#include "TalkerEx.h"
#include "mainfrm.h"
#include "LocConfDlg.h"

////////////////////////////////////////////////////////////////////////////
//
// CLocConfDlg dialog
//
////////////////////////////////////////////////////////////////////////////
//
IMPLEMENT_DYNAMIC(CLocConfDlg, CDialog)

CLocConfDlg::CLocConfDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLocConfDlg::IDD, pParent)
{

}

CLocConfDlg::~CLocConfDlg()
{
}

void CLocConfDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CLocConfDlg, CDialog)
END_MESSAGE_MAP()

// CLocConfDlg message handlers


////////////////////////////////////////////////////////////////////////////
//
// CCmdDlg dialog
//
////////////////////////////////////////////////////////////////////////////
//
IMPLEMENT_DYNAMIC(CCmdDlg, CDialog)

CCmdDlg::CCmdDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCmdDlg::IDD, pParent)
{

}

CCmdDlg::~CCmdDlg()
{
}

void CCmdDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CCmdDlg, CDialog)
    ON_BN_CLICKED(IDOK, &CCmdDlg::OnBnClickedOk)
    ON_EN_CHANGE(IDC_CMD, &CCmdDlg::OnEnChangeCmd)
END_MESSAGE_MAP()


// CCmdDlg message handlers

void CCmdDlg::OnBnClickedOk()
{
    CString cmd;
    GetDlgItemText(IDC_CMD, cmd);
    ((CMainFrame*)GetParent())->Talker()->SendPacket(TKC_COMMAND, 0, 0, 0, 0, &cmd);
}


void CCmdDlg::OnEnChangeCmd()
{
    // TODO:  If this is a RICHEDIT control, the control will not
    // send this notification unless you override the CDialog::OnInitDialog()
    // function and call CRichEditCtrl().SetEventMask()
    // with the ENM_CHANGE flag ORed into the mask.

    // TODO:  Add your control notification handler code here
}
