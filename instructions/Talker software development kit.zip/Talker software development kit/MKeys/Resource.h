//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mkeys.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define ID_INDICATOR_CONNECT            129
#define ID_INDICATOR_TIME               130
#define ID_INDICATOR_SAMPLING           131
#define ID_INDICATOR_BLANK              132
#define ID_INDICATOR_SERVER             133
#define IDD_CONSET                      310
#define IDB_TOOLBARL                    313
#define IDC_MACHINE                     1000
#define IDC_TNUM                        1001
#define IDM_RECONNECT                   32775
#define IDM_REFRESH                     32779
#define IDM_CONSET                      32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        314
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
