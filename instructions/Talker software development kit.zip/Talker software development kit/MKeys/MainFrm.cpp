//! mainfrm.cpp : implementation of the CMainFrame class
#include "stdafx.h"
#include "mainfrm.h"

#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
    ON_WM_DESTROY()
	ON_WM_SETFOCUS()
    ON_WM_INITMENUPOPUP()
    ON_WM_TIMER()
    ON_WM_CHAR()
    ON_COMMAND(ID_EDIT_CLEAR, OnEditClear)
    ON_COMMAND(IDM_RECONNECT, OnReconnect)
    ON_UPDATE_COMMAND_UI(IDM_RECONNECT, OnUpdateReconnect)
    ON_MESSAGE(TKN_PACKET, OnTalkPacket)
    ON_COMMAND(IDM_CONSET, OnConSet)
    ON_UPDATE_COMMAND_UI(IDM_CONSET, OnUpdateConSet)
    ON_UPDATE_COMMAND_UI(ID_INDICATOR_SERVER, OnUpdateServer)
    ON_UPDATE_COMMAND_UI(ID_INDICATOR_CONNECT, OnUpdateConnect)
    ON_UPDATE_COMMAND_UI(ID_INDICATOR_SAMPLING, OnUpdateSampling)
    ON_UPDATE_COMMAND_UI(ID_INDICATOR_TIME, OnUpdateTime)
END_MESSAGE_MAP()

//! Standard constructor for the main frame window
CMainFrame::CMainFrame()
{
    m_csServer = ".";                           // Default connection parameters
    m_nLog = 0;                                 // Initialise member variables
    m_nNum = 0;
    m_dwSpikeConnect = 0;
    m_uTimer = 0;
    m_dTimeZero = 0;
}

//! Destructor - do whatever needed to undo constructor, hopefully nothing
CMainFrame::~CMainFrame()
{
}

// array of IDs used to initialize the status bar
static UINT BASED_CODE indicators[] =
{
    ID_SEPARATOR,			                    // status line indicator
    ID_INDICATOR_SERVER,
    ID_INDICATOR_CONNECT,
    ID_INDICATOR_SAMPLING,
    ID_INDICATOR_TIME
};

//! We are being created, do other setup that has to happen after that
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1) // Get this window created
		return -1;

	// Create a text display child view to occupy the client area of the frame
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE("Failed to create view window\n");
		return -1;
	}

    // Create a toolbar to hold buttons as defined in the resources
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE("Failed to create toolbar\n");
		return -1;                              // fail to create
	}

    // Now, do we have to adjust for high-DPI screens?
    CClientDC dc(nullptr);                      // get the screen DC
    int nPixelsPerInch = dc.GetDeviceCaps(LOGPIXELSY); // get the vertical resolution
    // Large size is double, so height is 30, width is 32. The rules are that the sizes
    // here must be at least 7 pixels more that the button width and 6 more than the height.
    if ((nPixelsPerInch > 140) && m_wndToolBar.LoadBitmap(IDB_TOOLBARL))
        m_wndToolBar.SetSizes(CSize(39, 36), CSize(32, 30));

    // Create and set up the status bar
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT)))
	{
		TRACE(_T("No status bar\n"));
		return false;		// fail to create
	}

    // Make pane zero much smaller so that the others are nearly always visible
    UINT uID, uStyle;
    int nWidth;
    m_wndStatusBar.GetPaneInfo(0, uID, uStyle, nWidth);
    m_wndStatusBar.SetPaneInfo(0, uID, uStyle, nWidth/8);

    // Set Status bar as highest bar after its parent so that it gets resized correctly
    m_wndStatusBar.BringWindowToTop();
    
    m_uTimer = SetTimer(1001, 250, 0);          // Get a timer message every 250 milliseconds
	return 0;
}

//! We are being destroyed, do anything needed to tidy up, and undo OnCreate
void CMainFrame::OnDestroy()
{
    KillTimer(m_uTimer);                        // Kill off the timer
    if (m_cTalk.Connected())                    // Then disconnect from Spike2
        m_cTalk.Disconnect(true);               //  notify Spike2 as we initiated this
}

//! You can modify the creation process here, otherwise just leave alone
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 0, 0,
                        LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME)));
	return TRUE;
}

//! CMainFrame message handlers
void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	m_wndView.SetFocus();	                    // forward focus to the text view window
}

//! Allow the text view to handle messages as it desires
BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// otherwise, do default handling
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

//! Allow a reconnection attempt to Spike2 by clearing the various blocking flags
void CMainFrame::OnReconnect()
{
    m_dwSpikeConnect = 0;
    m_cTalk.ResetBlock();                       
}

//! Enable for commands allowed if connected to hardware but not sampling
void CMainFrame::OnUpdateIfIdle(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(m_cTalk.State() < TKS_ACTIVE);
}

//! Enable for reconnect to Spike2 command
void CMainFrame::OnUpdateReconnect(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(!m_cTalk.Connected() && m_cTalk.LowSpec());
}

//!< Return our talker name
CString  CMainFrame::Name() const
{
    CString str(TALK_NAME);
    if (m_nNum > 0)
        str.Format(_T("%s%d"), TALK_NAME, m_nNum);
    return str;
}

//! Return count of status strings displayed at fixed locations at the top of view
int CMainFrame::LogStatus()
{
    return 2;
}

//! Return one of the status strings (0 to n-1) out of the number returned above
CString CMainFrame::StatusString(int num) 
{
    CString str;
    switch (num)
    {
    case 0:                                     // The first string is the hardware information
        str.Format(_T("%s talker uses local keyboard to generate Spike2 markers in separate channel"), Name().GetString());
        break;
    case 1:                                     // The second string is the Spike2 connection status
    {
        CString csServ = Server();
        if (csServ == ".")
            csServ = "local system";
        else
            csServ = "machine " + csServ;

        switch (m_cTalk.State())
        {
        case TKS_DISCONNECT:                    // The disconnected state (for various reasons)
        {
            if (m_cTalk.LowSpec())
                str.Format(_T("Not connected to Spike2, reconnection blocked as Spike2 version was too old, use File -> Re-connect to unblock"));
            else
            {
                str.Format(_T("Not connected to Spike2 on %s"), csServ.GetString());
                if (m_cTalk.LastConErr().GetLength() > 0)
                    str += _T(": ") + m_cTalk.LastConErr();
            }
            break;
        }
        case TKS_IDLE:
            str.Format(_T("Connected to Spike2 version %.2f on %s, talker specification version %d, not sampling"), m_cTalk.Spike2Ver()/100.0, csServ.GetString(), m_cTalk.SpecVer());
            break;
        case TKS_ACTIVE:
            str.Format(_T("Connected to Spike2 version %.2f on %s, talker specification version %d, sampling in progress"), m_cTalk.Spike2Ver()/100.0, csServ.GetString(), m_cTalk.SpecVer());
            break;
        }
    }
    }
    return str;
}

/*!
Log an error message that will be displayed in the text display view
\param  nLevel   error level from 0 to 3 (info, warning, error, critical)
\param  nChan    channel number or -1 for all the talker
\param  csInfo   error information string
\param  nCode    error code value
*/
void CMainFrame::LogError(int nLev, int nChan, const CString& csInfo, int nCode)
{
    CString csLev;
    switch (nLev)
    {
        case 0 : csLev = _T("information");break;
        case 1 : csLev = _T("warning");break;
        case 2 : csLev = _T("error");break;
        default : csLev = _T("critical error");break;
    }
    CString cStr;
    if (nChan < 0)
        cStr.Format(_T("%s %s - %s, code %d"), Name().GetString(), csLev.GetString(), csInfo.GetString(), nCode);
    else
        cStr.Format(_T("%s %s - %s, chan %d, code %d"), Name().GetString(), csLev.GetString(), csInfo.GetString(), nChan, nCode);
    LogString(cStr);
}

//! Add strings from a string array to the strings displayed in the text display view
void CMainFrame::LogStrings(const CStringArray& csInfo)
{
    for (int i = 0; i < csInfo.GetSize(); ++i)
        LogString(csInfo.GetAt(i));
}

//! Add a string to the strings displayed in the text display view
void CMainFrame::LogString(const CString& cStr)
{
    if (cStr.IsEmpty())                         // Ignore blank strings
        return;
    CString wstr;
    if (m_cTalk.State() == TKS_ACTIVE)          // If active we can get time
        wstr.Format(_T("%04d (%.3f) %s"), m_nLog, ActiveTime(), cStr.GetString()); // Build a string with number and time
    else
        wstr.Format(_T("%04d %s"), m_nLog, cStr.GetString()); // Build a string with a number
    while (m_acsLog.GetSize() >= MAX_LOG)       // Don't allow the array to get too big
        m_acsLog.RemoveAt(0);
    m_acsLog.Add(wstr);                         // and put in the new one at the bottom
    m_nLog++;
    m_wndView.UpdateScroller();                 // Update scroll bar and redraw
}

//! Set the Spike2 server machine name
void CMainFrame::SetServer(const CString& csServer)
{
    m_csServer = csServer;
}

//! The 250 millisecond timer function - the heartbeat of the talker
//  All the background activities happen here
void CMainFrame::OnTimer(UINT_PTR nIDEvent)
{
    while (m_cTalk.Errors() > 0)                // Empty talker error queue
    {
        CTalkErr err(m_cTalk.GetError());       // Retrieve the oldest error
        if (err.level() < 0)
            m_cTalk.Disconnect(true);           // Negative error level for disconnect
        else
            LogError(err.level(), true, err.string(), err.code()); // Or display error information
    }

    if (!m_cTalk.Connected() && (GetTickCount() > m_dwSpikeConnect)) // Connect to Spike2 if OK to reconnect
    {
        CString csLast = m_cTalk.LastConErr();
        int nRes = m_cTalk.Connect(Name(), m_csServer, 0, 0, 1, this);
        if ((nRes == 0) || (m_cTalk.LastConErr() != csLast))
            m_wndView.UpdateScroller();         // Update text & scroll bar and redraw
        m_dwSpikeConnect = GetTickCount() + CONNECT_INT; // So we do not try again too soon
    }

    if (m_cTalk.Active())                       // Connected and sampling is in progress?
    {
    }
    CFrameWnd::OnTimer(nIDEvent);               // Call base class handler
}

//! Handle a notification message from the talker that a packet had been received from Spike2
LRESULT CMainFrame::OnTalkPacket(WPARAM /*wParam*/, LPARAM /*lParam*/)
{
    CStringArray csInfo;
    switch (m_cTalk.State())
    {
    case TKS_IDLE:                              // Respond to Spike2 if idling
    {
        int nRes = TalkIdle(m_cTalk, csInfo);   // This handles the possible idle packets
        if (nRes < 0)                           // -ve result means disconnect request from Spike2
        {                                       // presumably it is shutting down
            CString wstr;
            wstr.Format(_T("Talker %s disconnected"), m_cTalk.Name().GetString());
            m_cTalk.Disconnect(false);          // Don't notify Spike2 as it requested this
            m_dwSpikeConnect = GetTickCount() + CONNECT_PAUSE; // Block automatic reconnection for a bit
            csInfo.Add(wstr);
            m_wndView.UpdateScroller();         // Update scroll bar and redraw
        }
        else if (nRes > 0)                      // >0 result means switch to active state
        {
            m_cTalk.SetState(TKS_ACTIVE);       // Set active state
            m_wndView.UpdateScroller();         // Update scroll bar and redraw
        }
        break;
    }
    case TKS_ACTIVE:                            // Deal with Spike2 messages if active
    {
        int nRes = TalkActive(m_cTalk, csInfo); // This handles the possible active packets
        if (nRes < 0)                           // -ve result means disconnect request from Spike2
        {                                       // presumably it is shutting down
            CString wstr;
            wstr.Format(_T("Talker %s disconnected"), m_cTalk.Name().GetString());
            m_cTalk.Disconnect(false);          // Don't notify Spike2 as it requested this
            m_dwSpikeConnect = GetTickCount() + CONNECT_PAUSE; // Block automatic reconnection for a bit
            csInfo.Add(wstr);
            m_wndView.UpdateScroller();         // Update scroll bar and redraw
        }
        else if (nRes == 0)                     // A zero result means switching back to idling
        {
            m_cTalk.SendPacket(TKC_TALKERIDLE); // Send TalkerIdle to say done
            m_cTalk.SetState(TKS_IDLE);         // Switch to idle state as required
            m_wndView.UpdateScroller();         // Update scroll bar and redraw
        }
        break;
    }
    default:
        ASSERT(FALSE);
        break;
    }
#ifdef _DEBUG
    LogStrings(csInfo);                         // Only display general information when debugging
#endif
    return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Idle state packet handler. The packet has been checked for validity
//  and a good size, so we can be sure it is basically correct.
//
// The return value is 0 if we want to keep in the idle state, 1 if we
//  should switch to the active state, and -1 if we should disconnect in
//  response to a Spike2 request.
//
int CMainFrame::TalkIdle(CTalkIF& talk, CStringArray& csInfo)
{
    int nRes = 0;                               // Default result is to stay idle
    CString wstr;                               // Workspace string
    volatile TalkPacket* pPkt = talk.RxBuf();   // Pointer to the received packet

    bool bResp = true;                          // Flag for standard response wanted
    TalkPacket rResp;                           // Mostly we can use this standard response
    rResp.nCode = pPkt->nCode | TKC_RESPONSE_BIT; //  the code can modify it if it wants
    switch (pPkt->nCode)
    {
    case TKC_GETINFO:                           // Get overall talker information
    {
        wstr.Format(_T("GetInfo command received"));
        csInfo.Add(wstr);

        // Generate information about this talker
        TalkerInfo rInfo;                       // Prepare talker info structure for use
        rInfo.nChans = 1;                       // Number of channels - we only do keyboard data
        rInfo.nVer = 110;                       // Version 1.10
        CStringA astr(Name());                  // We need this as ASCII
        strcpy_s(rInfo.szName, TALK_NAME_SZ, astr.GetString()); // Our name - must match connect request
        strcpy_s(rInfo.szDesc, 60, "Marker channel from external keyboard");
        rInfo.nVerComp = 100;                   // Compatible with version 1.00 and later
        rInfo.nConfigID = 0;                    // No config data
        rInfo.nFlags = m_cTalk.IsRemote() ? TKF_REMOTE : 0;  // Tell Spike2 if we are remote
        rInfo.nFlags |= TKF_NODRDB;             // Disable drift compensation debug information

        // Send the talker information to Spike2
        m_cTalk.SendBlock(&rInfo, sizeof(TalkerInfo));
        bResp = false;                      // Standard response not required
        Invalidate();                           // Redraw as we may only now have Spike2 version
        break;
    }
    case TKC_GETCHAN:                           // Get talker channel information - should never happen
    {
        wstr.Format(_T("GetChan %d command received"), pPkt->nParam1);
        csInfo.Add(wstr);
        if (pPkt->nParam1 == 0)                 // This will always be true, we hope
        {
            TalkerChanInfo rChan;               // Prepare talker channel info structure
            rChan.nChan = pPkt->nParam1;        // The channel number
            rChan.nType = TCT_MARKER;           // Provide information on a single marker channel type
            rChan.nFlags = TCF_S2TIMED;         // Use Spike2-generated timing
            strcpy_s(rChan.szDesc, 256, "Marker channel from external keyboard data");
            strcpy_s(rChan.szTitle, TALK_CTITL_SZ, "Keys");
            rChan.dIRate = 1;
            m_cTalk.SendBlock(&rChan, sizeof(TalkerChanInfo));
            bResp = false;                      // Standard response not required
        }
        else                                    // Here for a bad channel number
        {
            ASSERT(FALSE);
            rResp.nCode |= TKC_ERROR_BIT;       // Standard response will be an error
            rResp.nParam1 = TKE_BAD_COMMAND;
        }
        break;
    }
    case TKC_GETCONFIG:                         // Should never happen
    {
        wstr.Format(_T("GetConfig command received"));
        csInfo.Add(wstr);
        ASSERT(FALSE);
        rResp.nCode |= TKC_ERROR_BIT;           // Standard response will be an error
        rResp.nParam1 = TKE_BAD_COMMAND;
        break;
    }
    case TKC_SETCONFIG:                         // Should never happen
    {
        wstr.Format(_T("SetConfig command received"));
        csInfo.Add(wstr);
        ASSERT(FALSE);
        rResp.nCode |= TKC_ERROR_BIT;           // Standard response will be an error
        rResp.nParam1 = TKE_BAD_COMMAND;
        break;
    }
    case TKC_LOCALCONFIG:                       // Should not happen unless talker does local config
    {                                           // in which case call hardware interface to do this
        wstr.Format(_T("LocalConfig command received"));
        csInfo.Add(wstr);
        ASSERT(FALSE);
        rResp.nCode |= TKC_ERROR_BIT;           // Standard response will be an error
        rResp.nParam1 = TKE_BAD_COMMAND;
        break;
    }
    case TKC_DLGINFO:                           // Get information on configuration dialog
    {
        wstr.Format(_T("DlgInfo command received"));
        csInfo.Add(wstr);
        rResp.nCode |= TKC_ERROR_BIT;           // Return an error as this should not happen
        rResp.nParam1 = TKE_BAD_COMMAND;
        break;
    }
    case TKC_DLGITEM:                           // Get information on configuration dialog item
    {
        wstr.Format(_T("DlgItem command received, item %d"), pPkt->nParam1);
        csInfo.Add(wstr);
        rResp.nCode |= TKC_ERROR_BIT;           // Return an error as this should not happen
        rResp.nParam1 = TKE_BAD_COMMAND;
        break;
    }
    case TKC_DLGGET:                            // Get configuration dialog item value
    {
        wstr.Format(_T("DlgGet command received, item %d, int resp %d"), pPkt->nParam1, rResp.nParam2);
        csInfo.Add(wstr);
        rResp.nCode |= TKC_ERROR_BIT;           // Return an error as this should not happen
        rResp.nParam1 = TKE_BAD_COMMAND;
        break;
    }
    case TKC_DLGSET:                            // Set configuration dialog item value
    {
        wstr.Format(_T("DlgSet command received, item %d, int val %d"), pPkt->nParam1, pPkt->nParam2);
        csInfo.Add(wstr);
        rResp.nCode |= TKC_ERROR_BIT;           // Return an error as this should not happen
        rResp.nParam1 = TKE_BAD_COMMAND;
        break;
    }
    case TKC_XMLNAMEVAL:                        // Get parameter (=configuration dialog item) XML info
    {
        wstr.Format(_T("XMLNameValue command received to %s parameter %d"), pPkt->nParam2 ? "write" : "read", pPkt->nParam1);
        csInfo.Add(wstr);
        TalkerXMLNameVal xnv;                   // To hold the XML item information
        xnv.nType = -1;
        talk.SendBlock(&xnv, sizeof(TalkerXMLNameVal));
        bResp = false;                          // Standard response not required
        break;
    }
    case TKC_XMLVALUE:                          // Set parameter (=configuration dialog item) value from XML
    {
        wstr.Format(_T("XMLValue command received for parameter %d"), pPkt->nParam1);
        csInfo.Add(wstr);
        rResp.nCode |= TKC_ERROR_BIT;           // Return an error as this should not happen
        rResp.nParam1 = TKE_BAD_COMMAND;
        break;
    }
    case TKC_SAMPLECLEAR:                       // Get ready for sampling
    {
        wstr.Format(_T("SampleClear command received, data is %g %g"), pPkt->dParam1, pPkt->dParam2);
        csInfo.Add(wstr);
        break;
    }
    case TKC_ENABLECHAN:
    {
        wstr.Format(_T("EnableChan command received, chan %d, data %d"), pPkt->nParam1, pPkt->nParam2);
        csInfo.Add(wstr);
        break;
    }
    case TKC_DRIFTINFO:
    {
        wstr.Format(_T("DriftInfo command received"));
        csInfo.Add(wstr);
        TalkerDriftInfo rPkt;                   // The drift rate seems slow, and info jagged, so buffer behaviour
        rPkt.dSDDump = 6;                       // Try not to reject too much data from the SD calculations
        rPkt.dSDUse = 3;                        //  and from the drift calculations
        rPkt.nDiffAvg = 100;                    // Drift info is at 4 Hz so this is 25 seconds
        rPkt.nDrBf = 400;                       // Look back over the last 100 seconds to estimate drift slope
        talk.SendBlock(&rPkt, sizeof(TalkerDriftInfo)); // Send off the data
        bResp = false;                          // so no ordinary response wanted
        break;
    }
    case TKC_QUERYREADY:
    {
        wstr.Format(_T("Query ready command received"));
        csInfo.Add(wstr);
        rResp.nParam1 = 1;                      // Just flag that we are ready
        break;
    }
    case TKC_SAMPLESTART:
    {                                           // Save some crucial time information
        if (talk.IsLocal())                     // If we are local to Spike2
            m_dTimeZero = pPkt->dParam1;        //  we know the sampling time zero value
        else
            m_dTimeZero = m_timer.Seconds() - pPkt->dParam2; // If remote we must estimate
        wstr.Format(_T("SampleStart command received, clock %g, delay %g, local timer %g"), pPkt->dParam1, pPkt->dParam2, m_timer.Seconds());
        csInfo.Add(wstr);
        nRes = 1;                               // Return 1 to switch to active state
        break;
    }
    case TKC_SENDSTRING :                       // Spike2 sent a string to the talker
        wstr.Format(_T("StrToTalker command received, function code %d, string %s"), pPkt->nParam1, pPkt->szParam);
        csInfo.Add(wstr);
        bResp = false;                          // No response required
        break;

    case TKC_TALKERCLOSE :                      // Spike2 wants the talker to close
        wstr.Format(_T("TalkerClose command received"));
        csInfo.Add(wstr);
        bResp = false;                          // No response required
        nRes = -1;                              // -1 return will close connection
        break;
    }

    if (bResp)                                  // Send the standard response
        talk.SendBlock(&rResp, sizeof(TalkPacket));

    // We have to call DoneRx once the data packet has been handled. If we are going
    //  to disconnect as a result of a Spike2 request however, we don't call it as
    //  that can result in a race condition leading to a read error from CTalkIF.
    if (nRes >= 0)                              // Don't call if we are about to disconnect
        talk.DoneRx();                          // Otherwise MUST call this once packet handled
    return nRes;
}

///////////////////////////////////////////////////////////////////////////////
//
// Active state packet handler. The packet has been checked for validity
//  and a good size so we can be sure it is basically correct.
//
// The return value is 1 if we want to keep in the active state, 0 if we
//  should switch to the idle state, and -1 if we should disconnect in
//  response to a Spike2 request.
//
int CMainFrame::TalkActive(CTalkIF& talk, CStringArray& csInfo)
{
    int nRes = 1;                               // Default result is 1 to keep active
    CString wstr;                               // Workspace string
    volatile TalkPacket* pPkt = talk.RxBuf();   // Pointer to the received packet
    switch (pPkt->nCode)
    {
    case TKC_SAMPLEKEY:
        wstr.Format(_T("SampleKey notification received, key %d, time %g"), pPkt->nParam1, pPkt->dParam1);
        csInfo.Add(wstr);
        break;

    case TKC_SAMPLESTOP:
    {
        if (pPkt->dParam1 >= 0)
            wstr.Format(_T("SampleStop command received, time %g"), pPkt->dParam1);
        else
            wstr.Format(_T("SampleStop received indicating sampling crash stop"));
        csInfo.Add(wstr);
        nRes = 0;                               // Return 0 to return to idle state
        break;
    }
    case TKC_SENDSTRING :                       // Spike2 sent a string to the talker
        wstr.Format(_T("SendString command received, function code %d, string %s"), pPkt->nParam1, pPkt->szParam);
        csInfo.Add(wstr);
        break;

    case TKC_TALKERIDLE:
    {
        wstr.Format(_T("TalkerIdle command received"));
        csInfo.Add(wstr);
        nRes = 0;                               // Return 0 to return to idle state
        break;
    }
    case TKC_TALKERCLOSE :                      // Spike2 wants the talker to close
    {
        wstr.Format(_T("TalkerClose command received"));
        csInfo.Add(wstr);
        nRes = -1;                              // and return -1 to disconnect
        break;
    }
    }

    // We have to call DoneRx once the data packet has been handled. If we are going
    //  to disconnect as a result of a Spike2 request however, we don't call it as
    //  that can result in a race condition leading to a read error from CTalkIF.
    if (nRes >= 0)                              // Don't call if we are about to disconnect
        talk.DoneRx();                          // Otherwise MUST call this once packet handled
    return nRes;
}

//! Update the status bar panes
void CMainFrame::OnUpdateServer(CCmdUI *pCmdUI)
{
    if (m_csServer == _T("."))
        pCmdUI->SetText(_T("Local"));
    else
        pCmdUI->SetText(m_csServer);
}

void CMainFrame::OnUpdateConnect(CCmdUI *pCmdUI)
{
    if (m_cTalk.Connected())
        pCmdUI->SetText(_T("Connected to Spike2"));
    else
        pCmdUI->SetText(_T("Not connected"));
}

void CMainFrame::OnUpdateSampling(CCmdUI *pCmdUI)
{
    if (m_cTalk.Connected())
    {
        if (m_cTalk.Active())
            pCmdUI->SetText(_T("Sampling"));
        else
            pCmdUI->SetText(_T("Idle"));
    }
    else
        pCmdUI->SetText(_T(""));
}

void CMainFrame::OnUpdateTime(CCmdUI *pCmdUI)
{
    if (m_cTalk.Active())
    {
        CString str;
        str.Format(_T("%.1f s"), ActiveTime());
        pCmdUI->SetText(str);
    }
    else
        pCmdUI->SetText(_T(""));
}

//!< Handle incoming character by sending packet to Spike2
void CMainFrame::OnChar(UINT nChar, UINT /*nRepCnt*/, UINT /*nFlags*/)
{
    if (m_cTalk.State() == TKS_ACTIVE)          // Ignore this if not active
    {
        //TRACE("Sending data packet for character %d\n", nChar);
        DWORD dwSize = sizeof(TalkerData) + sizeof(TalkDataMarker);
        std::vector<byte> buf(dwSize, 0);
        TalkerData* pHead = reinterpret_cast<TalkerData*>(buf.data());
        pHead->nSize = (int)dwSize;             // The total data size
        pHead->nCode = TKC_TALKERDATA;
        pHead->nChan = 0;                       // Channel number is always zero
        pHead->nItems = 1;
        pHead->dStart = 0;
        pHead->nItemSize = sizeof(TalkDataMarker);
        TalkDataMarker* pMark = reinterpret_cast<TalkDataMarker*>(MovePtr(pHead, sizeof(TalkerData)));
        pMark->lMark = nChar & 0xff;
        pMark->dTime = 0;
        pHead->dNow = 0;                        // No packet send time as we are wholly Spike2 timed
        m_cTalk.SendBlock(pHead, dwSize);       // Send the data
    }
}

//! Return estimated Spike2 time since the sampling started
double CMainFrame::ActiveTime()
{
    double dTime = 0;
    if (m_cTalk.State() == TKS_ACTIVE)          // If active we can get time
        dTime = m_timer.Seconds() - m_dTimeZero; // Relative to sampling start
    return dTime;
}

//! Clear the text display window
void CMainFrame::OnEditClear()
{
    m_acsLog.RemoveAll();                       // Empty out all the strings
    m_wndView.UpdateScroller();                 // Update scroll bar and redraw
}

// Menu command to edit the connection settings
void CMainFrame::OnConSet()
{
    CConSetDlg conDlg(m_csServer, Num(), this);
	if (conDlg.DoModal() == IDOK)
    {
        CString csServ = conDlg.Server();
        csServ.Trim();                          // Get rid of unwanted white space
        if (csServ.IsEmpty())                   // Convert empty string to local machine
            csServ = _T(".");
        int num = conDlg.Num();
        if ((m_csServer != csServ) || (Num() != num))
        {
            if (m_cTalk.Connected())            // Disconnect before changing settings
                m_cTalk.Disconnect(true);
            SetServer(csServ);                  // Save the new settings
            SetNum(num);
            m_dwSpikeConnect = 0;               // Allow an immediate connection attempt
            m_wndView.UpdateScroller();         // Update text, scroll bar and redraw
        }
    }
}

//! Enable for reconnect to Spike2 command
void CMainFrame::OnUpdateConSet(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(!m_cTalk.Active());
}

//! The dialog used to edit connectiion settings
CConSetDlg::CConSetDlg(const CString& csServ, int num, CWnd* pParent)
    : CDialog(CConSetDlg::IDD, pParent)
{
    m_csServ = csServ;
    if (m_csServ == _T("."))                    // Convert local machine to blank
        m_csServ.Empty();
    m_num = num;
}

void CConSetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
    DDX_Text(pDX, IDC_MACHINE, m_csServ);
    DDX_Text(pDX, IDC_TNUM, m_num);
    DDV_MinMaxInt(pDX, m_num, 0, 9);
}

BEGIN_MESSAGE_MAP(CConSetDlg, CDialog)
END_MESSAGE_MAP()

