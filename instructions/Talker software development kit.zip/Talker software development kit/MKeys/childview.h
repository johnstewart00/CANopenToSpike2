//! childview.h : interface for the CChildView class
#pragma once

class CChildView : public CWnd
{
public:
	                CChildView();
    void            UpdateScroller();

// Overrides
protected:
	virtual BOOL    PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual         ~CChildView();

	// Generated message map functions
protected:
    CFont           m_font;                     // The font to be used
    TEXTMETRIC      m_tm;                       // Text info for our font
    CScrollBar*     m_pHScroller;               // horizontal scroll bar
    int             m_nSBHeight;                // Vertical size of scroll bar
    int             m_nSBRange;                 // Range of scroll bar or 0 if disabled

    afx_msg int     OnCreate(LPCREATESTRUCT lpCS);
	afx_msg void    OnPaint();
	afx_msg void    OnSize(UINT nType, int cx, int cy);
    afx_msg void    OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
    afx_msg void    OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);

	DECLARE_MESSAGE_MAP()

public:
    afx_msg void    OnEditCopy();
};

