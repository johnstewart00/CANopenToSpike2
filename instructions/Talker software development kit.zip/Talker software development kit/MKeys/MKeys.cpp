// talkapp.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "mkeys.h"
#include "mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CTalkerApp
BEGIN_MESSAGE_MAP(CTalkerApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_HELP_INDEX, OnHelp)
	ON_COMMAND(ID_HELP_USING, CWinApp::OnHelpUsing)
    ON_COMMAND(ID_HELP, OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, CWinApp::OnContextHelp)
	ON_COMMAND(ID_DEFAULT_HELP, CWinApp::OnHelpIndex)
END_MESSAGE_MAP()

// CTalkerApp construction
CTalkerApp::CTalkerApp()
{
	SetAppID(_T("CED.MKeys.AppID.NoVersion"));
}

// The one and only CTalkerApp object
CTalkerApp theApp;

// CTalkerApp initialization
BOOL CTalkerApp::InitInstance()
{
	CWinApp::InitInstance();
    //CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);

	EnableTaskbarInteraction(FALSE);

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	SetRegistryKey(_T("CED MKeys Application"));

	// To create the main window, this code creates a new frame window
	// object and then sets it as the application's main window object
	CMainFrame* pFrame = new CMainFrame;
	if (!pFrame)
		return FALSE;
	m_pMainWnd = pFrame;

    // Now that we have the main window created, we can parse through the command line
    //  and update the main window with any parameters supplied.
    CString csLine(m_lpCmdLine);                // a local copy of the command line
    csLine.TrimRight();                         // Clean up leading\trailing spaces
    csLine.TrimLeft();
    if (!csLine.IsEmpty())                      // If anything left in command line...
	{
        CString csWrk;                          // a work string
        while (!csLine.IsEmpty())               // anything to be done?
        {
            int iPos;
            if (csLine[0] == '"')               // If starts with quotes...
                iPos = csLine.Mid(1).Find('"')+1; // ...find closing quote
            else
                iPos = csLine.Find(' ');        // find a space character

            if (iPos > 0)                       // 0=nowt for ", first for space
            {
                csWrk = csLine.Left(iPos+1);    // copy it (includes final char)
                csLine = csLine.Mid(iPos+1);    // remove it from the work space
            }
            else
            {
                csWrk = csLine;                 // use the entire string...
                csLine.Empty();                 // ...so nothing left
            }

            if ((csWrk[0] == _T('-')) || (csWrk[0] == _T('/'))) // if an option we can use it
            {
                int nChar = csWrk.GetLength();
                TCHAR cOpt(' ');                // Option character
                if (nChar > 1) cOpt = csWrk[1];
                CString csPar;                  // Option parameter
                if (nChar > 2) csPar = csWrk.Right(nChar-2);
                csPar.TrimLeft();               // Clean up the parameter string
                csPar.TrimRight();
                switch (cOpt)
                {
                case _T('S') :                  // S option sets the server name
                case _T('s') :
                    if (!csPar.IsEmpty())       // Set up the server name if supplied
                        pFrame->SetServer(csPar);
                    break;

                case _T('N'):                   // N option specifies the number
                case _T('n') :
                    if (!csPar.IsEmpty())       // Process the parameter if we can
                    {
                        int num = _ttoi(csPar); // and set up the server
                        pFrame->SetNum(num);
                    }
                    break;

                default :
                    break;
                }
            }
            csLine.TrimLeft();                   // tidy up the end
        }
	}

	// create and load the frame with its resources
	pFrame->LoadFrame(IDR_MAINFRAME, WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, NULL, NULL);

	// The one and only window has been initialized, so show and update it
	pFrame->ShowWindow(SW_SHOW);
	pFrame->UpdateWindow();
	return TRUE;
}

int CTalkerApp::ExitInstance()
{
	//CoUninitialize();
	return CWinApp::ExitInstance();
}

// CAboutDlg dialog used for App About
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

// App command to run the dialog
void CTalkerApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

// CTalkerApp message handlers
/////////////////////////////////////////////////////////////////////////////
//
// Help Button (IDHELP) has been pressed, or F1 (ID_HELP) was pressed. We
//  invoke the relevant page in the main Signal help.
//
void CTalkerApp::OnHelp()
{
    CString csPath;
    TCHAR szStartDir[MAX_PATH*2];
    if (::GetModuleFileName(NULL, szStartDir, MAX_PATH*2) != MAX_PATH*2)
    {							            // remove the app filename part
        csPath = szStartDir;
        csPath.MakeReverse();               // makes search easier
        int iPathEnd = csPath.FindOneOf(_T("\\:")); // find path end
        if (iPathEnd != -1)
        {
            csPath = csPath.Right(csPath.GetLength()-iPathEnd);
            csPath.MakeReverse();           // back to correct direction
        }
        else
            csPath.Empty();
    }
    ::HtmlHelp(::GetDesktopWindow(), csPath+_T("mkeys.chm"), HH_DISPLAY_INDEX, 0);
}

