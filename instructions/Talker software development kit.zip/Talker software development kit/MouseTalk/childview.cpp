///////////////////////////////////////////////////////////////////////////////
//
// childview.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "childview.h"

#include "mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


///////////////////////////////////////////////////////////////////////////////
//
// CChildView
//
///////////////////////////////////////////////////////////////////////////////
//
CChildView::CChildView() :
    m_pHScroller( nullptr )                     // no HScroller yet
    , m_nSBHeight( 0 )
    , m_nSBRange( 0 )
{
}

///////////////////////////////////////////////////////////////////////////////
//
CChildView::~CChildView()
{
    delete m_pHScroller;
}

///////////////////////////////////////////////////////////////////////////////
//
BEGIN_MESSAGE_MAP(CChildView, CWnd)
    ON_WM_CREATE()
    ON_WM_SIZE()
	ON_WM_PAINT()
    ON_WM_HSCROLL()
    ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////////
//
// CChildView message handlers
//
///////////////////////////////////////////////////////////////////////////////
//
BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
int CChildView::OnCreate(LPCREATESTRUCT lpCS)
{
    int iReturn = CWnd::OnCreate(lpCS);
    try
    {
        m_pHScroller = new CScrollBar;
    }
    catch(CMemoryException* pe)
    {
        pe->Delete();
        m_pHScroller = nullptr;
    }
    RECT rClientRect;                           // this is used as a default rectangle
    GetClientRect((LPRECT)&rClientRect);        // actual ones set by override
    if (m_pHScroller && m_pHScroller->Create(WS_CHILD|WS_VISIBLE|SBS_HORZ, rClientRect, this, NULL))
        m_pHScroller->SetScrollRange(0, 80);    // A dummy range for now

	CPaintDC dc(this);                          // Device context for painting
    LOGFONT lf;
    memset(&lf, 0, sizeof(lf));                 // Clear out the logfont info
    lf.lfHeight = 100;                          // We want a ten-point font
    lf.lfOutPrecision = OUT_TT_PRECIS;          // True type if available
    lf.lfQuality = PROOF_QUALITY;               // Good quality
    _tcscpy_s(lf.lfFaceName, LF_FACESIZE, _T("Open Sans")); // Choose font by name
    VERIFY(m_font.CreatePointFontIndirect(&lf, &dc)); // Make the font to use

    dc.SelectObject(m_font);                    // Select font into the DC
    dc.GetTextMetrics(&m_tm);                   // Get text size info
    m_nSBHeight = ::GetSystemMetrics(SM_CYHSCROLL); // Height of scroll bar

    return iReturn;
}

///////////////////////////////////////////////////////////////////////////////
//
void CChildView::OnSize(UINT nType, int cx, int cy)
{
    if (m_pHScroller)
    {
        CRect rS(0, cy-m_nSBHeight, cx, cy);    // Rectangle for scroller
        m_pHScroller->MoveWindow(rS);           // Get the scroller there
        UpdateScroller();                       // Update scroller position
    }
    CWnd::OnSize(nType, cx, cy);
}

///////////////////////////////////////////////////////////////////////////////
//
void CChildView::OnPaint() 
{
	CPaintDC dc(this);                          // Device context for painting
    dc.SelectObject(m_font);                    // Select font into the DC
    CMainFrame* pMain = static_cast<CMainFrame*>(AfxGetApp()->GetMainWnd());
    CRect r;
    GetClientRect(r);                           // Get the total area available
    r.bottom -= ::GetSystemMetrics(SM_CYHSCROLL);
    int nScroll = m_nSBRange > 0 ? m_pHScroller->GetScrollPos() : 0; // Scroll position in chars
    int nStatus = pMain->LogStatus();           // Number of fixed status strings
    for (int i=1; i <= nStatus; ++i)
    {
        CString csState = pMain->StatusString(i-1);
        if (nScroll)                            // Remove characters scrolled out of view
            csState.Delete(0, nScroll);
        dc.TextOut(m_tm.tmMaxCharWidth, m_tm.tmHeight*i, csState, csState.GetLength());
    }
    int nLine = nStatus+2;                      // The line to draw onto
    int nSpace = r.Height() / m_tm.tmHeight;    // Number of lines of text we can draw
    nSpace -= nLine;                            // Subtract top area to give number of log lines
    CStringArray* pLog = pMain->GetLog();
    int nFirst = (int)pLog->GetSize() - nSpace; // First line to draw based on space available
    if (nFirst < 0) nFirst = 0;                 // But keep it sensible
    for (int i=nFirst; i < pLog->GetSize(); ++i)
    {
        CString str(pLog->GetAt(i));
        if (str.GetLength() > 0)
        {
            if (nScroll)                        // Remove characters scrolled out of view
                str.Delete(0, nScroll);
            dc.TextOut(m_tm.tmMaxCharWidth, m_tm.tmHeight*nLine, str, str.GetLength());
        }
        nLine++;
    }
}

///////////////////////////////////////////////////////////////////////////////
//
void CChildView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
    if (pScrollBar == m_pHScroller)
    {
        int nScroll = m_pHScroller->GetScrollPos();
        switch (nSBCode)
        {
        case SB_RIGHT:
            nScroll = m_nSBRange;               // Right hand side
            break;

        case SB_LINERIGHT:
            nScroll++;
            break;

        case SB_LINELEFT:
            nScroll--;
            break;

        case SB_PAGERIGHT:
            nScroll += 2;
            break;

        case SB_PAGELEFT:
            nScroll += 2;
            break;

        case SB_THUMBPOSITION:                  // final position of a thumb drag
        case SB_THUMBTRACK:                     // position change during a thumb drag
            nScroll = nPos;
            break;

        case SB_LEFT:
            nScroll = 0;
            break;

        default:
            break;
        }
        if (nScroll < 0)
            nScroll = 0;                        // Sanitise new scroller position
        if (nScroll > m_nSBRange)
            nScroll = m_nSBRange;
        if (nScroll != m_pHScroller->GetScrollPos())
        {
            m_pHScroller->SetScrollPos(nScroll);
            Invalidate();                       // Update and redraw
        }
    }
}

///////////////////////////////////////////////////////////////////////////////
//
void CChildView::UpdateScroller()
{
    if (!m_pHScroller)                          // Just in case this gets called early
        return;
    int nPos = m_pHScroller->GetScrollPos();    // Get the current position
    CRect r;
    GetClientRect(r);                           // Get the total area available
    int cx = r.Width();
    int nChars = cx / m_tm.tmAveCharWidth;      // Chars we can show on screen
    int nMax = 0;                               // Search for longest string to show
    CMainFrame* pMain = static_cast<CMainFrame*>(AfxGetApp()->GetMainWnd());
    int nStatus = pMain->LogStatus();           // Number of fixed status strings
    for (int i=0; i < nStatus; ++i)
    {
        CString str = pMain->StatusString(i);
        if (str.GetLength() > nMax)             // Find the longest one
            nMax = str.GetLength();
    }
    CStringArray* pLog = pMain->GetLog();       // Other info
    for (int i=0; i < pLog->GetSize(); ++i)
    {
        int len = pLog->GetAt(i).GetLength();
        if (len > nMax)                         // look for even longer
            nMax = len;
    }
    nMax += (nChars / 10);                      // Throw in 20% extra space needed
    if (nMax > nChars)                          // Scroller needed?
        m_nSBRange = nMax - nChars;             // Save range and flag scroller in use
    else
        m_nSBRange = 0;                         // or flag not in use
    if (m_nSBRange > 0)
        m_pHScroller->SetScrollRange(0, m_nSBRange);
    if (nPos > m_nSBRange)
        nPos = m_nSBRange;
    m_pHScroller->SetScrollPos(nPos);
    m_pHScroller->EnableScrollBar(m_nSBRange > 0 ? ESB_ENABLE_BOTH : ESB_DISABLE_BOTH);
    Invalidate();                               // Force a redraw
}

///////////////////////////////////////////////////////////////////////////////
//
void CChildView::OnEditCopy()
{
    if (!OpenClipboard())
    {
        AfxMessageBox(_T("Cannot open the Clipboard"));
        return;
    }

    // Remove the current Clipboard contents
    if (!EmptyClipboard())
    {
        AfxMessageBox(_T("Cannot empty the Clipboard"));
        return;
    }
    
    CMainFrame* pM = static_cast<CMainFrame*>(AfxGetApp()->GetMainWnd());
    int nStatus = pM->LogStatus();              // Number of fixed status strings
    CString csState;                            // Get the standard status strings
    for (int i=1; i <= nStatus; ++i)
    {
        csState += pM->StatusString(i-1);
        csState += _T("\r\n");
    }
    CStringArray* pLog = pM->GetLog();          // Append all the log strings
    if (pLog->GetSize() > 0)                    // With a blank line before
        csState += _T("\r\n");
    for (int i=0; i < pLog->GetSize(); ++i)
    {
        if (pLog->GetAt(i).GetLength() > 0)
        {
            csState += pLog->GetAt(i);
            csState += _T("\r\n");
        }
    }

    int iLen = (csState.GetLength()+1) * sizeof(TCHAR);
    HGLOBAL hGlb = GlobalAlloc(GMEM_MOVEABLE, iLen); 
    if (hGlb == NULL) 
    { 
        AfxMessageBox(_T("Cannot allocate memory for Clipboard data"));
        CloseClipboard(); 
        return; 
    } 
 
    // Lock the handle and copy the text to the buffer. 
    LPTSTR lpTstr = (LPTSTR)GlobalLock(hGlb);
    if (!lpTstr)                                // Bit of caution here
    {
        GlobalFree(hGlb);
        CloseClipboard();
        return;
    }
    memcpy(lpTstr, csState.GetString(), iLen);
    GlobalUnlock(hGlb); 
    if (::SetClipboardData(CF_UNICODETEXT, hGlb) == NULL)
    {
        AfxMessageBox(_T("Unable to set Clipboard data"));
        CloseClipboard();
        return;
    }
    CloseClipboard();
}
