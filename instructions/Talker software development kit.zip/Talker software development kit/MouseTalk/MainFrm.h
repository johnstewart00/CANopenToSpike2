//! mainfrm.h : interface for the CMainFrame class
#pragma once

#include "..\common\s2talk.h"                   // All the standard talker defines and structures
#include "childview.h"                          // The text view displaying status and log info
#include "..\common\talkif.h"                   // The talker interface object
#include "resource.h"

constexpr char const* TALK_NAME = "MouseTalk";  //!< Our talker name
constexpr int MIN_SPEC_VER = 3;                 //!< The minimum talker interface spec version we accept
constexpr int CONNECT_INT = 1000;               //!< Milliseconds between attempts to connect to hardware
constexpr int CONNECT_PAUSE = 5000;             //!< Milliseconds we hold off on Spike2 reconnect after Spike2 quits
constexpr int MAX_LOG = 60;                     //!< Maximum number of log message strings that are stored
constexpr int DRIFT_THROT = 10;                 //!< Used to throttle 10 Hz timer function for 1 Hz drift information

class CMainFrame : public CFrameWnd
{
public:
	CMainFrame();
	virtual ~CMainFrame();

protected: 
	DECLARE_DYNAMIC(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL    PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL    OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);

// Implementation
public:
    CString         Name() const;               //!< Return our talker name
    void            SetNum(int num){m_nNum = num;} //!< Set and get the talker number
    int             Num() const {return m_nNum;}
    void            SetServer(const CString& csServer); //!< Set and get the Spike2 machine name
    CString         Server() const {return m_csServer;}

    int             LogStatus();                //!< Count of status strings at top of view
    CString         StatusString(int num);      //!< Generate status string n (0 based)
    CStringArray*   GetLog(){return &m_acsLog;} //!< Access to log text
    afx_msg void    OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);

protected:
    bool            ValidScrPlace(WINDOWPLACEMENT* pPlace);
    void            DoRegistry(bool bSave);     //!< Save and load registry settings
    double          ActiveTime();               //!< Time since sampling started
    int             TalkIdle(CTalkIF& talk, CStringArray& csInfo);
    int             TalkActive(CTalkIF& talk, CStringArray& csInfo);
    void            SendMousePos();             // Send the mouse position data

    void            LogError(int nLev, int nChan, const CString& csInfo, int nCode);
    void            LogStrings(const CStringArray& csInfo);
    void            LogString(const CString& cStr);

    CString         m_csServer;                 //!< The Spike2 talker server machine name or "." if local
    int             m_nNum;                     //!< The hardware number - zero for default

    CToolBar        m_wndToolBar;               //!< Standard toolbar - change buttons in resource editor
    CStatusBar      m_wndStatusBar;             //!< Standard status bar with panes
	CChildView      m_wndView;                  //!< The text view that displays status and log info

    CTalkIF         m_cTalk;                    //!< Talker interface handler class

    DWORD           m_dwSpikeConnect;           //!< The next time we are allowed to try to connect to Spike2
    UINT_PTR        m_uTimer;                   //!< Identifier for SetTimer timer
    CTalkTimer      m_timer;                    //!< High-accuracy timer used for all timing
    int             m_iyScrl;                   //!< Screen resolution information
    int             m_ixScrl;
    double          m_dTimeZero;                //!< Our clock time corresponding to Spike2 sampling time zero
    int             m_nDriftCount;              //!< Used to count timer intervals for drift info

    int             m_nLog;                     //!< The count of log messages so they can be numbered
    CStringArray    m_acsLog;                   //!< The array of log messages for display

// Generated message map functions
protected:
	afx_msg int     OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void    OnDestroy();
    afx_msg void    OnTimer(UINT_PTR nIDEvent);
	afx_msg void    OnSetFocus(CWnd *pOldWnd);
    afx_msg void    OnReconnect();
    afx_msg void    OnEditClear();
    afx_msg void    OnUpdateIfIdle(CCmdUI* pCmdUI);
    afx_msg void    OnUpdateReconnect(CCmdUI* pCmdUI);
    afx_msg LRESULT OnTalkPacket(WPARAM wParam, LPARAM lParam);
    afx_msg void    OnConSet();
    afx_msg void    OnUpdateConSet(CCmdUI* pCmdUI);
    afx_msg void    OnUpdateServer(CCmdUI *pCmdUI);
    afx_msg void    OnUpdateConnect(CCmdUI *pCmdUI);
    afx_msg void    OnUpdateSampling(CCmdUI *pCmdUI);
    afx_msg void    OnUpdateTime(CCmdUI *pCmdUI);
	DECLARE_MESSAGE_MAP()
};


// CConSetDlg dialog used to alter connection settings
class CConSetDlg : public CDialog
{
public:
	CConSetDlg(const CString& csServ, int num, CWnd* pParent);

    CString     Server() const {return m_csServ;} // Member var access
    int         Num() const {return m_num;}
// Dialog Data
	enum { IDD = IDD_CONSET };

protected:
	virtual void DoDataExchange(CDataExchange* pDX); // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()

private:
    CString     m_csServ;
    int         m_num;
};

