#pragma once

#define OEMRESOURCE
#undef NOOEMRESOURCE
#define VC_EXTRALEAN		            // Exclude rarely-used stuff from Windows headers
#define NOMINMAX

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

// Modify the following defines if you have to target a platform prior to the ones specified below.
// Refer to MSDN for the latest info on corresponding values for different platforms.
#ifndef WINVER				            // Allow use of features specific to Windows 7 or later
#define WINVER 0x0601		            // Change this to the appropriate value to target other versions of Windows
#endif

#ifndef _WIN32_WINNT		            // Allow use of features specific to Windows 7 or later           
#define _WIN32_WINNT 0x0601	            // Change this to the appropriate value to target other versions of Windows.
#endif						

#ifndef _WIN32_WINDOWS		            // Allow use of features specific to Windows 7 or later
#define _WIN32_WINDOWS 0x0601           // Change this to the appropriate value to target Windows Me or later.
#endif

#include "targetver.h"

#include <afxwin.h>                     // MFC core and standard components
#include <afxext.h>                     // MFC extensions
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			            // MFC support for Windows Common Controls
#endif                                  // _AFX_NO_AFXCMN_SUPPORT
#include <afxpriv.h>
#include <afxdisp.h>                    // MFC ole support

#include <math.h>
#include <limits.h>
#include <assert.h>

// stl includes
// Turn off range checking in STL iterators if not debug
#ifndef _DEBUG
#define _SECURE_SCL 0
#endif

#include <functional>
#include <string>
#include <memory>
#include <algorithm>
#include <numeric>
#include <list>
#include <vector>
#include <array>
#include <queue>
#include <deque>
#include <map>
#include <set>
#include <mutex>
//#include <unordered_map>
//#include <boost/bimap.hpp>
//#include <boost/bimap/unordered_set_of.hpp>

