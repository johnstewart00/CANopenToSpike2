//! mainfrm.cpp : implementation of the CMainFrame class
#include "stdafx.h"
#include "mainfrm.h"

#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
    ON_WM_DESTROY()
	ON_WM_SETFOCUS()
    ON_WM_INITMENUPOPUP()
    ON_WM_TIMER()
    ON_COMMAND(ID_EDIT_CLEAR, OnEditClear)
    ON_COMMAND(IDM_REFRESH, OnRefresh)
    ON_UPDATE_COMMAND_UI(IDM_REFRESH, OnUpdateIfIdle)
    ON_COMMAND(IDM_RECONNECT, OnReconnect)
    ON_UPDATE_COMMAND_UI(IDM_RECONNECT, OnUpdateReconnect)
    ON_MESSAGE(TKN_PACKET, OnTalkPacket)
    ON_COMMAND(IDM_CONSET, OnConSet)
    ON_UPDATE_COMMAND_UI(IDM_CONSET, OnUpdateNotActive)
    ON_COMMAND(IDM_DRIFTOPT, OnDriftOpt)
    ON_UPDATE_COMMAND_UI(IDM_DRIFTOPT, OnUpdateNotActive)
    ON_UPDATE_COMMAND_UI(ID_INDICATOR_SERVER, OnUpdateServer)
    ON_UPDATE_COMMAND_UI(ID_INDICATOR_CONNECT, OnUpdateConnect)
    ON_UPDATE_COMMAND_UI(ID_INDICATOR_SAMPLING, OnUpdateSampling)
    ON_UPDATE_COMMAND_UI(ID_INDICATOR_TIME, OnUpdateTime)
END_MESSAGE_MAP()

//! Standard constructor for the main frame window
CMainFrame::CMainFrame()
{
    m_csServer = ".";                           // Default connection parameters
    m_nLog = 0;                                 // Initialise member variables
    m_dTimeBase = 1e-4;
    m_dwHardConnect = 0;
    m_dwSpikeConnect = 0;
    m_uTimer = 0;
    m_dTimeZero = 0;
    m_dHardZero = -1;
    m_dDrYScale = 1.0;                          // Set up 'passive' drift adjustment values
    m_dDrYScale = 1.0;
    m_bDrDebug = false;

    // We may need somewhere suitable to save information - the common application data path
    TCHAR szPath[MAX_PATH+1];                   // A string to hold the result
    memset(szPath, 0, sizeof(szPath));          // Suitably cleared
    if (SUCCEEDED(SHGetFolderPath(NULL, CSIDL_LOCAL_APPDATA, NULL, SHGFP_TYPE_CURRENT, szPath)))
    {
        m_csAppPath.Format(_T("%s\\CED\\skeltalk\\"), szPath); // TODO Change to your talker name
        if (PathExists(m_csAppPath) != 0)       // Check that the directory exists
        {                                       // If it does not, make it in stages
            CString csCED;                      // This holds the intermediate CED directory
            csCED.Format(_T("%s\\CED\\"), szPath);
            if (PathExists(csCED) != 0)         // Check if the CED directory exists
                ::CreateDirectory(csCED, nullptr); // Create it if its not there
            if (PathExists(csCED) == 0)         // Check that CED directory now does exist
                ::CreateDirectory(m_csAppPath, nullptr); // If it does, create the skeltalk subdir
        }
        if (PathExists(m_csAppPath) != 0)       // Now, did all that work?
            m_csAppPath.Empty();                // Clear out string if we didn't succeed
    }
    if (m_csAppPath.IsEmpty())                  // Still got nothing?
    {                                           // Just get My Documents - we assume this succeeds
        SHGetFolderPath(NULL, CSIDL_MYDOCUMENTS, NULL, SHGFP_TYPE_CURRENT, szPath);
        m_csAppPath = szPath;                   // Use the result with backslash appended
        m_csAppPath += _T("\\");
    }
    ASSERT(!m_csAppPath.IsEmpty());
}

//! Destructor - do whatever needed to undo constructor, hopefully nothing
CMainFrame::~CMainFrame()
{
}

// array of IDs used to initialize the status bar
static UINT BASED_CODE indicators[] =
{
    ID_SEPARATOR,			                    // status line indicator
    ID_INDICATOR_SERVER,
    ID_INDICATOR_CONNECT,
    ID_INDICATOR_SAMPLING,
    ID_INDICATOR_TIME
};

//! We are being created, do other setup that has to happen after that
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1) // Get this window created
		return -1;

	// Create a text display child view to occupy the client area of the frame
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE(_T("Failed to create view window\n"));
		return -1;
	}

    // Create a toolbar to hold buttons as defined in the resources TODO change buttons as appropriate
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE(_T("Failed to create toolbar\n"));
		return -1;                              // fail to create
	}

    // Now, do we have to adjust for high-DPI screens?
    CClientDC dc(nullptr);                      // get the screen DC
    int nPixelsPerInch = dc.GetDeviceCaps(LOGPIXELSY); // get the vertical resolution
    // Large size is double, so height is 30, width is 32. The rules are that the sizes
    // here must be at least 7 pixels more that the button width and 6 more than the height.
    if ((nPixelsPerInch > 140) && m_wndToolBar.LoadBitmap(IDB_TOOLBARL))
        m_wndToolBar.SetSizes(CSize(39, 36), CSize(32, 30));

    // Create and set up the status bar
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT)))
	{
		TRACE(_T("No status bar\n"));
		return false;		// fail to create
	}

    // Make pane zero much smaller so that the others are nearly always visible
    UINT uID, uStyle;
    int nWidth;
    m_wndStatusBar.GetPaneInfo(0, uID, uStyle, nWidth);
    m_wndStatusBar.SetPaneInfo(0, uID, uStyle, nWidth/8);

    // Set Status bar as highest bar after its parent so that it gets resized correctly
    m_wndStatusBar.BringWindowToTop();

    // TODO add any other setting up needed

    DoRegistry(false);                          // Load app data from the registry

    m_uTimer = SetTimer(1001, 250, 0);          // Get a timer message every 250 milliseconds
	return 0;
}

// Return true if at least 25% of the window placement will be visible
// bApp selects the application area if true, else its the desktop
bool CMainFrame::ValidScrPlace(WINDOWPLACEMENT* pPlace)
{
    CRect rWork;
    rWork.left = ::GetSystemMetrics(SM_XVIRTUALSCREEN);
    rWork.top = ::GetSystemMetrics(SM_YVIRTUALSCREEN);
    rWork.right = rWork.left + ::GetSystemMetrics(SM_CXVIRTUALSCREEN);
    rWork.bottom = rWork.top + ::GetSystemMetrics(SM_CYVIRTUALSCREEN);
    if (rWork.right == 0)                       // The operating system might be a touch old...
    {
        rWork.left = 0;
        rWork.top = 0;
        rWork.right = ::GetSystemMetrics(SM_CXSCREEN);
        rWork.bottom = ::GetSystemMetrics(SM_CYSCREEN);
    }
    bool bValid = true;
    switch (pPlace->showCmd)                    // Do the best we can based upon show
    {
    case SW_RESTORE:
    case SW_SHOWNORMAL:
    {
        CRect rWnd(pPlace->rcNormalPosition);
        CRect rOver(rWork & rWnd);              // The overlapping area
        if ((rOver.Width() < (rWnd.Width()/4)) ||
            (rOver.Height() < (rWnd.Height()/4)))
            bValid = false;
        break;
    }
    case SW_SHOWMAXIMIZED:
    {
        break;
    }
    case SW_SHOWMINIMIZED:
        if (!rWork.PtInRect(pPlace->ptMinPosition))
            bValid = false;
        break;
    }
    if (!bValid)
        TRACE(_T("Invalid window placement supplied\n"));
    return bValid;
}

void CMainFrame::DoRegistry(bool bSave)
{
    CString csSets = _T("Settings");
    if (m_cHardW.Num() > 0)                     // We need to use a separate registry location
        csSets.Format(_T("Settings%d"), m_cHardW.Num()); // if the device number is explicitly set
    CString csPlace = _T("AppLocation");
    CString csYScale = _T("DrYScal");
    CString csXScale = _T("DrXScal");
    CString csDrDbg = _T("DrDebug");
    CWinApp* pApp = AfxGetApp();

    if (bSave)                                  // Save information?
    {
        // First save the application window position
        WINDOWPLACEMENT rWndPlace;
        rWndPlace.length = sizeof(WINDOWPLACEMENT); // so GWP works
        GetWindowPlacement(&rWndPlace);
        pApp->WriteProfileBinary(csSets, csPlace, (LPBYTE)&rWndPlace, sizeof(WINDOWPLACEMENT));

        // Now save the other values
        pApp->WriteProfileInt(csSets, csYScale, (int)(m_dDrYScale*100));
        pApp->WriteProfileInt(csSets, csXScale, (int)(m_dDrXScale*100));
        pApp->WriteProfileInt(csSets, csDrDbg, m_bDrDebug ? 1 : 0);
    }
    else                                        // load information
    {
        bool bSetPos = false;

        // Now see if we have window placement information for the application.
        BYTE* pData;
        UINT dwSize;                            // Will be set to the data size
        if (pApp->GetProfileBinary(csSets, csPlace, (LPBYTE*)&pData, &dwSize))
        {
            if (dwSize == sizeof(WINDOWPLACEMENT))
            {
                WINDOWPLACEMENT* pWndPlace = (WINDOWPLACEMENT*)pData;
                pWndPlace->length = sizeof(WINDOWPLACEMENT); // so SWP works
                if (ValidScrPlace(pWndPlace))
                {
                    SetWindowPlacement(pWndPlace);
                    bSetPos = true;
                }
            }
            delete[] pData;
        }

        // Now read the other values
        m_dDrYScale = pApp->GetProfileInt(csSets, csYScale, 100) / 100.0;
        m_dDrXScale = pApp->GetProfileInt(csSets, csXScale, 100) / 100.0;
        m_bDrDebug = pApp->GetProfileInt(csSets, csDrDbg, 0) != 0;
        if (m_dDrYScale < 0.05)                 // Force the scalings to a plausible
            m_dDrYScale = 0.05;                 //  though very wide range
        if (m_dDrYScale > 20)
            m_dDrYScale = 20;
        if (m_dDrXScale < 0.05)
            m_dDrXScale = 0.05;
        if (m_dDrXScale > 20)
            m_dDrXScale = 20;

        if (!bSetPos)                           // If we did not set up the window
            ShowWindow(SW_SHOW);                //  make sure it is shown
        else
        {
            Invalidate();                       // Make sure we are displayed - Aero can get confused by SetWindowPlacement. TDB
            m_wndToolBar.Invalidate();          // NBNB this only seems to happen when initial help is up (when other toolbars are hidden)
            m_wndStatusBar.Invalidate();        //  but we may need to invalidate all the toolbars if the issue turns up in other situations
        }
    }
}

//! We are being destroyed, do anything needed to tidy up, and undo OnCreate
void CMainFrame::OnDestroy()
{
    KillTimer(m_uTimer);                        // Kill off the timer
    if (m_cHardW.Connected())                   // Shut down hardware first of all
        m_cHardW.Disconnect();
    if (m_cTalk.Connected())                    // Then disconnect from Spike2
        m_cTalk.Disconnect(true);               //  notify Spike2 as we initiated this
    DoRegistry(true);                           // Save app data in the registry
    // TODO add any other tidying up needed, to match OnCreate
}

//! You can modify the creation process here, otherwise just leave alone
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 0, 0,
                        LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME)));
	return TRUE;
}

//! Set and get hardware number
void CMainFrame::SetNum(int num)
{
    m_cHardW.SetNum(num);
}

int CMainFrame::Num() const
{
    return m_cHardW.Num();
}

//! CMainFrame message handlers
void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	m_wndView.SetFocus();	                    // forward focus to the text view window
}

//! Allow the text view to handle messages as it desires
BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// otherwise, do default handling
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

//! Refresh the hardware information as may have changed 
void CMainFrame::OnRefresh()
{
    m_cHardW.Refresh();
    m_wndView.UpdateScroller();                 // Update scroll bar and redraw
    if (m_cTalk.Connected())                    // Notify Spike2 that configuration may have changed
        m_cTalk.SendPacket(TKC_LOCALCONFIG);
}

//! Allow a reconnection attempt to Spike2 by clearing the various blocking flags
void CMainFrame::OnReconnect()
{
    m_dwSpikeConnect = 0;
    m_cTalk.ResetBlock();                       
}

//! Enable for commands allowed if connected to hardware but not sampling
void CMainFrame::OnUpdateIfIdle(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(m_cHardW.Connected() && (m_cTalk.State() < TKS_ACTIVE));
}

//! Enable for reconnect to Spike2 command
void CMainFrame::OnUpdateReconnect(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(m_cHardW.Connected() && !m_cTalk.Connected() &&
                   (m_cTalk.LowSpec() || m_cTalk.BadSerial()));
}

//! Return count of status strings displayed at fixed locations at the top of view
int CMainFrame::LogStatus()
{
    return 3;                                   // TODO alter the number of strings if necessary
    // If you do alter this then the switch statement in StatusString will also need adjustment
}

//! Return one of the status strings (0 to n-1) out of the number returned above
CString CMainFrame::StatusString(int num) 
{
    CString str;
    switch (num)
    {
    case 0:
        if (m_cHardW.Connected())                // The first string is the hardware connection status
        {
            CString csName = m_cHardW.Name();   // convert talker name to TSTR
            str.Format(_T("Connected to %s talker hardware: %d channels available"), csName.GetString(), m_cHardW.Chans());
        }
        else
            str.Format(_T("Not connected to hardware: %s"), m_cHardW.LastConErr().GetString());
        break;
    case 1:
        if (m_cHardW.Connected())                // The second string is the hardware information
        {
            // TODO Generate information about hardware in str
        }
        break;
    case 2:                                      // The third string is the Spike2 connection status
        if (m_cHardW.Connected())                // We only try to connect to Spike2 if we have a hardware connection
        {
            CString csServ = Server();
            if (csServ == ".")
                csServ = "local system";
            else
                csServ = "machine " + csServ;

            switch (m_cTalk.State())
            {
            case TKS_DISCONNECT:                // The disconnected state (for various reasons)
            {
                if (m_cTalk.LowSpec())          // Spike2 is too old for us...
                    str.Format(_T("Not connected to Spike2, reconnection blocked as Spike2 version was too old, use File -> Re-connect to unblock"));
                else if (m_cTalk.BadSerial())   // A serial number issue is something of a special case
                    str.Format(_T("Not connected to Spike2 as %s, reconnection blocked, use File -> Re-connect to unblock"),
                               m_cTalk.LastConErr().GetString());
                else                            // Here for connection failure for some unknown reason
                {
                    str.Format(_T("Not connected to Spike2 on %s"), csServ.GetString());
                    if (m_cTalk.LastConErr().GetLength() > 0)
                        str += _T(": ") + m_cTalk.LastConErr();
                }
                break;
            }
            case TKS_IDLE:
                str.Format(_T("Connected to Spike2 version %.2f on %s, talker specification version %d, not sampling"),
                             m_cTalk.Spike2Ver()/100.0, csServ.GetString(), m_cTalk.SpecVer());
                break;
            case TKS_ACTIVE:
                str.Format(_T("Connected to Spike2 version %.2f on %s, talker specification version %d, sampling in progress"),
                             m_cTalk.Spike2Ver()/100.0, csServ.GetString(), m_cTalk.SpecVer());
                break;
            }
        }
        else
            str.Format(_T("Not connected to Spike2 (as we do not have a connection to any hardware)"));
    }
    return str;
}

/*!
Log an error message that will be displayed in the text display view
\param  nLevel   error level from 0 to 3 (info, warning, error, critical)
\param  bTalk    true if notification comes from talker interface, otherwise hardware
\param  nChan    channel number or -1 if not channel-specific
\param  csInfo   error information string
\param  nCode    error code value
*/
void CMainFrame::LogError(int nLev, bool bTalk, int nChan, const CString& csInfo, int nCode)
{
    CString csLev;
    switch (nLev)
    {
        case 0 : csLev = _T("information");break;
        case 1 : csLev = _T("warning");break;
        case 2 : csLev = _T("error");break;
        default : csLev = _T("critical error");break;
    }
    CString csName = bTalk ? CString("Talker") : m_cHardW.Name();
    CString cStr;
    if (nChan < 0)                              // Not channel-specific?
        cStr.Format(_T("%s %s - %s, code %d"), csName.GetString(), csLev.GetString(), csInfo.GetString(), nCode);
    else
        cStr.Format(_T("%s %s - %s, channel %d, code %d"), csName.GetString(), csLev.GetString(), csInfo.GetString(), nChan, nCode);
    LogString(cStr);
}

//! Add strings from a string vector to the strings displayed in the text display view
void CMainFrame::LogStrings(const std::vector<CString>& vcsInfo)
{
    for (const auto& str : vcsInfo)
        LogString(str);
}

//! Add a string to the strings displayed in the text display view
void CMainFrame::LogString(const CString& cStr)
{
    if (cStr.IsEmpty())                         // Ignore blank strings
        return;
    CString wstr;
    if (m_cTalk.State() == TKS_ACTIVE)          // If active we can get time
        wstr.Format(_T("%04d (%.3f) %s"), m_nLog, ActiveTime(), cStr.GetString()); // Build a string with number and time
    else
        wstr.Format(_T("%04d %s"), m_nLog, cStr.GetString()); // Build a string with a number
    if (m_vcsLog.size() >= MAX_LOG)             // Don't allow the vector to get too big
    {
        int n = (int)(m_vcsLog.size()-MAX_LOG) + 1;  // strings to erase
        m_vcsLog.erase(m_vcsLog.begin(), m_vcsLog.begin()+n);
    }
    m_vcsLog.push_back(wstr);                   // and put in the new one at the bottom
    m_nLog++;
    m_wndView.UpdateScroller();                 // Update scroll bar and redraw
}

//! Set the Spike2 server machine name
void CMainFrame::SetServer(const CString& csServer)
{
    m_csServer = csServer;
}

//! The 250 millisecond timer function - the heartbeat of the talker
//  All the background activities happen here
void CMainFrame::OnTimer(UINT_PTR nIDEvent)
{
    while (m_cHardW.Errors() > 0)               // Empty hardware error queue
    {
        CTalkErr err(m_cHardW.GetError());      // Retrieve the oldest error
        if (err.level() < 0)
        {
            m_cHardW.Disconnect(false);         // Negative error level for disconnect
            m_dwHardConnect = GetTickCount() + CONNECT_PAUSE; // So we do not try again too soon
        }
        else
        {
            LogError(err.level(), false, err.chan(), err.string(), err.code()); // Or display error information
            if (m_cHardW.Active() && (err.level() > 0)) // Should we let Spike2 know?
                m_cTalk.SendProblem(err.level()-1, err.chan(), err.string());
        }
    }

    while (m_cTalk.Errors() > 0)                // Empty talker error queue
    {
        CTalkErr err(m_cTalk.GetError());       // Retrieve the oldest error
        if (err.level() < 0)
            m_cTalk.Disconnect(true);           // Negative error level for disconnect
        else
            LogError(err.level(), true, err.chan(), err.string(), err.code()); // Or display error information
    }

    if (m_cHardW.Connected() && !m_cTalk.Active()) // If in idle state then check hardware connection
    {
        if (!m_cHardW.CheckComms())             // Check that the hardware is there!
        {
            m_cHardW.Disconnect();              // If it has gone then disconnect in software
            m_dwHardConnect = GetTickCount() + CONNECT_PAUSE; //  and do not try again too soon
        }
    }

    if (!m_cHardW.Connected())                  // If not connected to hardware
    {
        if (m_cTalk.Connected())                // then we should not be connected to Spike2
            m_cTalk.Disconnect(true);

        if (GetTickCount() >= m_dwHardConnect)  // Try to connect to hardware if time for another try
        {
            CString csLast = m_cHardW.LastConErr();
            int nRes = m_cHardW.Connect(&m_cTalk, this);
            if ((nRes == 0) || (m_cHardW.LastConErr() != csLast))
                m_wndView.UpdateScroller();     // Update text, scroll bar and redraw
            m_dwHardConnect = GetTickCount() + CONNECT_INT; // So we do not try again too soon
        }
    }
    else                                        // If we are connected to hardware
    {
        if (!m_cTalk.Connected() && (GetTickCount() > m_dwSpikeConnect)) // Connect to Spike2 if OK to reconnect
        {
            CString csLast = m_cTalk.LastConErr();
            int nRes = m_cTalk.Connect(m_cHardW.Name(), m_csServer, MIN_SPEC_VER, 0, 0, this);
            if ((nRes == 0) || (m_cTalk.LastConErr() != csLast))
                m_wndView.UpdateScroller();     // Update text & scroll bar and redraw
            m_dwSpikeConnect = GetTickCount() + CONNECT_INT; // So we do not try again too soon
        }

        if (m_cTalk.Active())                   // Connected and sampling is in progress?
        {
            // This is an example of how to handle drift information TODO alter if needed
            TalkerData rDrift;                  // Send drift information to Spike2
            memset(&rDrift, 0, sizeof(TalkerData));
            rDrift.nSize = sizeof(TalkerData);
            rDrift.nCode = TKC_TALKERDATA;
            double dNow = m_cHardW.Now();       // Get hardware's best estimate of the current time
            rDrift.dNow = dNow + m_dHardZero;   // Spike2 time for drift data
            m_cTalk.SendBlock(&rDrift, (int)sizeof(TalkerData));
            
            // TODO if hardware is polled for data, poll it now in HandleData, otherwise you have to devise
            // another method of retrieving the data. It is assumed, though there is no example code
            // that actually does this, that the polling would add more data to buffers, one
            // per channel most likely, and that if the buffer had enough data it would then be
            // sent to Spike2.
        }
    }
    CFrameWnd::OnTimer(nIDEvent);               // Call base class handler
}

//! Handle a notification message from the talker that a packet had been received from Spike2
LRESULT CMainFrame::OnTalkPacket(WPARAM /*wParam*/, LPARAM /*lParam*/)
{
    std::vector<CString> vcsInfo;
    switch (m_cTalk.State())
    {
    case TKS_IDLE:                              // Respond to Spike2 if idling
    {
        int nRes = TalkIdle(m_cTalk, vcsInfo);  // This handles the possible idle packets
        if (nRes < 0)                           // -ve result means disconnect request from Spike2
        {                                       // presumably it is shutting down
            CString wstr;
            CString csName = m_cTalk.Name();
            wstr.Format(_T("Talker %s disconnected"), csName.GetString());
            m_cTalk.Disconnect(false);          // Don't notify Spike2 as it requested this
            m_dwSpikeConnect = GetTickCount() + CONNECT_PAUSE; // Block automatic reconnection for a bit
            vcsInfo.push_back(wstr);
            m_wndView.UpdateScroller();         // Update scroll bar and redraw
        }
        else if (nRes > 0)                      // >0 result means switch to active state
        {
            m_cTalk.SetState(TKS_ACTIVE);       // Set active state
            m_wndView.UpdateScroller();         // Update scroll bar and redraw
        }
        break;
    }
    case TKS_ACTIVE:                            // Deal with Spike2 messages if active
    {
        int nRes = TalkActive(m_cTalk, vcsInfo); // This handles the possible active packets
        if (nRes < 0)                           // -ve result means disconnect request from Spike2
        {                                       // presumably it is shutting down
            CString wstr;
            CString csName = m_cTalk.Name();
            wstr.Format(_T("Talker %s disconnected"), csName.GetString());
            m_cTalk.Disconnect(false);          // Don't notify Spike2 as it requested this
            m_dwSpikeConnect = GetTickCount() + CONNECT_PAUSE; // Block automatic reconnection for a bit
            vcsInfo.push_back(wstr);
            m_wndView.UpdateScroller();         // Update scroll bar and redraw
        }
        else if (nRes == 0)                     // A zero result means switching back to idling
        {
            m_cTalk.SendPacket(TKC_TALKERIDLE); // Send TalkerIdle to say done
            m_cTalk.SetState(TKS_IDLE);         // Switch to idle state as required
            m_wndView.UpdateScroller();         // Update scroll bar and redraw
        }
        break;
    }
    default:
        ASSERT(FALSE);
        break;
    }
#ifdef _DEBUG
    LogStrings(vcsInfo);                        // Only display general information when debugging
#endif
    return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Idle state packet handler. The packet has been checked for validity
//  and a good size, so we can be sure it is basically correct.
//
// The return value is 0 if we want to keep in the idle state, 1 if we
//  should switch to the active state, and -1 if we should disconnect in
//  response to a Spike2 request.
//
int CMainFrame::TalkIdle(CTalkIF& talk, std::vector<CString>& vcsInfo)
{
    int nRes = 0;                               // Default result is to stay idle
    CString wstr;                               // Workspace string
    volatile TalkPacket* pPkt = talk.RxBuf();   // Pointer to the received packet

    bool bResp = true;                          // Flag for standard response wanted
    TalkPacket rResp;                           // Mostly we can use this standard response
    rResp.nCode = pPkt->nCode | TKC_RESPONSE_BIT; //  the code can modify it if it wants

    switch (pPkt->nCode)
    {
    case TKC_GETINFO:                           // Get overall talker information
    {
        wstr.Format(_T("GetInfo command received"));
        vcsInfo.push_back(wstr);

        m_cHardW.Refresh();                     // Make sure our information is up to date
        TalkerInfo rInfo;
        if (m_cHardW.Talk(rInfo) == 0)          // Hardware system generates information
        {
            rInfo.nSize = sizeof(TalkerInfo);   // Make sure key information is correct
            rInfo.nCode = TKC_GETINFO|TKC_RESPONSE_BIT;
#ifndef _DEBUG
            if (!m_bDrDebug)                    // Unless option has been set
                rInfo.nFlags |= TKF_NODRDB;     // no drift debug in release software
#endif
            talk.SendBlock(&rInfo, sizeof(TalkerInfo));
            bResp = false;                      // Standard response not required
        }
        else
        {
            ASSERT(FALSE);
            rResp.nCode |= TKC_ERROR_BIT;       // Standard response will be an error
            rResp.nParam1 = TKE_BAD_COMMAND;
        }
        m_wndView.UpdateScroller();             // Redraw as we may only now have Spike2 version
        break;
    }
    case TKC_GETCHAN:                           // Get talker channel information
    {
        ASSERT(pPkt->nParam1 >= 0);
        ASSERT(pPkt->nParam1 < m_cHardW.Chans());
        wstr.Format(_T("GetChan %d command received"), pPkt->nParam1);
        vcsInfo.push_back(wstr);

        TalkerChanInfo rChan;                   // Prepare talker channel info structure
        if (m_cHardW.Chan(pPkt->nParam1, rChan) == 0) // hardware module sets this up
        {
            rChan.nSize = sizeof(TalkerChanInfo); // Make sure key information
            rChan.nCode = TKC_GETCHAN|TKC_RESPONSE_BIT; // is correct
            talk.SendBlock(&rChan, sizeof(TalkerChanInfo));
            bResp = false;                      // Standard response not required
        }
        else
        {
            ASSERT(FALSE);
            rResp.nCode |= TKC_ERROR_BIT;       // Standard response will be an error
            rResp.nParam1 = TKE_BAD_COMMAND;
        }
        break;
    }
    case TKC_GETCONFIG:                         // Should never happen
    {
        wstr.Format(_T("GetConfig command received"));
        vcsInfo.push_back(wstr);
        ASSERT(FALSE);
        rResp.nCode |= TKC_ERROR_BIT;           // Standard response will be an error
        rResp.nParam1 = TKE_BAD_COMMAND;
        break;
    }
    case TKC_SETCONFIG:                         // Should never happen
    {
        wstr.Format(_T("SetConfig command received"));
        vcsInfo.push_back(wstr);
        ASSERT(FALSE);
        rResp.nCode |= TKC_ERROR_BIT;           // Standard response will be an error
        rResp.nParam1 = TKE_BAD_COMMAND;
        break;
    }
    case TKC_LOCALCONFIG:                       // Should not happen unless talker does local config
    {                                           // in which case call hardware interface to do this TODO if necessary
        wstr.Format(_T("LocalConfig command received"));
        vcsInfo.push_back(wstr);
        ASSERT(FALSE);
        rResp.nCode |= TKC_ERROR_BIT;           // Standard response will be an error
        rResp.nParam1 = TKE_BAD_COMMAND;
        break;
    }
    case TKC_DLGINFO:                           // Get information on configuration dialog
    {
        wstr.Format(_T("DlgInfo command received"));
        vcsInfo.push_back(wstr);
        TalkerDlgInfo tdi;
        m_cHardW.Dlg(tdi);                      // Hardware module does the work
        talk.SendBlock(&tdi, sizeof(TalkerDlgInfo));
        bResp = false;                          // Standard response not required
        break;
    }
    case TKC_DLGITEM:                           // Get information on configuration dialog item
    {
        wstr.Format(_T("DlgItem command received, item %d"), pPkt->nParam1);
        vcsInfo.push_back(wstr);
        TalkerDlgItem tdi;
        m_cHardW.DlgItem(pPkt->nParam1, tdi);   // Hardware module does the work
        talk.SendBlock(&tdi, sizeof(TalkerDlgItem));
        bResp = false;                          // Standard response not required
        break;
    }
    case TKC_DLGGET:                            // Get configuration dialog item value
    {
        m_cHardW.DlgValue(true, pPkt->nParam1, rResp); // Hardware module does the work
        wstr.Format(_T("DlgGet command received, item %d, int resp %d"), pPkt->nParam1, rResp.nParam2);
        vcsInfo.push_back(wstr);
        break;
    }
    case TKC_DLGSET:                            // Set configuration dialog item value
    {
        wstr.Format(_T("DlgSet command received, item %d, int val %d"), pPkt->nParam1, pPkt->nParam2);
        vcsInfo.push_back(wstr);
        m_cHardW.DlgValue(false, pPkt->nParam1, *const_cast<TalkPacket*>(pPkt)); // Hardware module does the work
        break;
    }
    case TKC_XMLNAMEVAL:                        // Get parameter (=configuration dialog item) XML info
    {
        wstr.Format(_T("XMLNameValue command received to %s parameter %d"), pPkt->nParam2 ? _T("write") : _T("read"), pPkt->nParam1);
        vcsInfo.push_back(wstr);
        TalkerXMLNameVal xnv;                   // To hold the XML item information
        m_cHardW.XmlNameValue(!pPkt->nParam2, pPkt->nParam1, xnv); // Hardware module does the work
        talk.SendBlock(&xnv, sizeof(TalkerXMLNameVal));
        bResp = false;                          // Standard response not required
        break;
    }
    case TKC_XMLVALUE:                          // Set parameter (=configuration dialog item) value from XML
    {
        wstr.Format(_T("XMLValue command received for parameter %d"), pPkt->nParam1);
        vcsInfo.push_back(wstr);
        m_cHardW.XmlValue(pPkt->nParam1, *const_cast<TalkPacket*>(pPkt)); // Hardware module does the work
        break;
    }
    case TKC_SAMPLECLEAR:                       // Get ready for sampling
    {
        wstr.Format(_T("SampleClear command received, data is %g %g"), pPkt->dParam1, pPkt->dParam2);
        vcsInfo.push_back(wstr);
        m_cHardW.SampleClear();                 // Carry out before-sampling initialisation
        break;
    }
    case TKC_ENABLECHAN:
    {
        int nChan = pPkt->nParam1;              // The channel number
        wstr.Format(_T("EnableChan command received, chan %d, data %d"), nChan, pPkt->nParam2);
        vcsInfo.push_back(wstr);
        rResp.nParam1 = m_cHardW.EnableChan(nChan); // Save channel in use flag in hardware module
        break;
    }
    case TKC_DRIFTINFO:
    {
        wstr.Format(_T("DriftInfo command received"));
        vcsInfo.push_back(wstr);
        TalkerDriftInfo rPkt;                   // The drift rate seems slow, and info jagged, so buffer behaviour
        rPkt.dSDDump = 6;                       // Try not to reject too much data from the SD calculations
        rPkt.dSDUse = 3;                        //  and from the drift calculations TODO review these safe settings if you want
        rPkt.nDiffAvg = 100;                    // Drift info is at 4 Hz so this is 25 seconds
        rPkt.nDrBf = 400;                       // Look back over the last 100 seconds to estimate drift slope
        talk.TweakDrift(rPkt, m_dDrYScale, m_dDrXScale); // Adjust the values as required
        talk.SendBlock(&rPkt, sizeof(TalkerDriftInfo)); // Send off the data
        bResp = false;                          // so no ordinary response wanted
        break;
    }
    case TKC_QUERYREADY:
    {
        rResp.nParam1 = m_cHardW.QueryReady();  // Hardware module says if we are ready
        break;
    }
    case TKC_SAMPLESTART:
    {                                           // Save some crucial time information
        if (talk.IsLocal())                     // If we are local to Spike2
            m_dTimeZero = pPkt->dParam1;        //  we know the sampling time zero value
        else
            m_dTimeZero = m_timer.Seconds() - pPkt->dParam2; // If remote we must estimate
        m_dHardZero = -1;                       // Reset the hardware time zero value
        wstr.Format(_T("SampleStart command received, clock %g, delay %g, local timer %g"), pPkt->dParam1, pPkt->dParam2, m_timer.Seconds());
        vcsInfo.push_back(wstr);
        if (m_cHardW.Sample(true) == 0)         // Kick off the sampling in the hardware module
        {
            // TODO any other start-of-sampling setup
            nRes = 1;                           //  and switch to active if we succeeded
        }
        break;
    }
    case TKC_SENDSTRING:                        // Spike2 sent a string to the talker
        AddMsg(_T("StrToTalker command received, function code %d, string %s"), vcsInfo, pPkt);
        // TODO add code to support this if wanted
        bResp = false;                          // No response required
        break;

    case TKC_COMMAND:                           // Spike2 sent a command to the talker
        AddMsg(_T("Command received from Spike2, function code %d, string %s"), vcsInfo, pPkt);
        // TODO add code to support this if wanted
        bResp = false;                          // No response required
        break;

    case TKC_TALKERCLOSE:                       // Spike2 wants the talker to close
        wstr.Format(_T("TalkerClose command received"));
        vcsInfo.push_back(wstr);
        bResp = false;                          // No response required
        nRes = -1;                              // -1 return will close connection
        break;
    }

    if (bResp)                                  // Send the standard response
        talk.SendBlock(&rResp, sizeof(TalkPacket));

    // We have to call DoneRx once the data packet has been handled. If we are going
    //  to disconnect as a result of a Spike2 request however, we don't call it as
    //  that can result in a race condition leading to a read error from CTalkIF.
    if (nRes >= 0)                              // Don't call if we are about to disconnect
        talk.DoneRx();                          // Otherwise MUST call this once packet handled
    return nRes;
}

//! Add a message to the vector of strings
/*!
\param szMsg    A message with %d followed by %s to be filled in from 
\param vcsInfo  Vector of string to append the result to.
\param pPkt     The talker packet to get the code and text from
*/
void CMainFrame::AddMsg(const TCHAR* szMsg, std::vector<CString>& vcsInfo, volatile TalkPacket* pPkt) const
{
    CString csParam(const_cast<const char*>(pPkt->szParam));    // Convert fom char to TCHAR
    CString cs;
    cs.Format(szMsg, pPkt->nParam1, csParam.GetString());
    vcsInfo.push_back(cs);
}

///////////////////////////////////////////////////////////////////////////////
//
// Active state packet handler. The packet has been checked for validity
//  and a good size so we can be sure it is basically correct.
//
// The return value is 1 if we want to keep in the active state, 0 if we
//  should switch to the idle state, and -1 if we should disconnect in
//  response to a Spike2 request.
//
int CMainFrame::TalkActive(CTalkIF& talk, std::vector<CString>& vcsInfo)
{
    int nRes = 1;                               // Default result is 1 to keep active
    CString wstr;                               // Workspace string
    volatile TalkPacket* pPkt = talk.RxBuf();   // Pointer to the received packet
    switch (pPkt->nCode)
    {
    case TKC_SAMPLEKEY:
        wstr.Format(_T("SampleKey notification received, key %d, time %g"), pPkt->nParam1, pPkt->dParam1);
        vcsInfo.push_back(wstr);
        break;

    case TKC_SAMPLESTOP:
    {
        if (pPkt->dParam1 >= 0)
            wstr.Format(_T("SampleStop command received, time %g"), pPkt->dParam1);
        else
            wstr.Format(_T("SampleStop received indicating sampling crash stop"));
        vcsInfo.push_back(wstr);
        m_cHardW.Sample(false);                 // Stop sampling
        if (pPkt->dParam1 >= 0)                 // Send partial blocks if not a crash-stop
            HandleLastData(pPkt->dParam1);      // Send any left-over data
        FlushBuffers();                         // Now we can make sure all the buffers are empty
        // TODO any other end-of-sampling shut down
        nRes = 0;                               // Return 0 to return to idle state
        break;
    }
    case TKC_SENDSTRING:                       // Spike2 sent a string to the talker
        AddMsg(_T("SendString command received, function code %d, string %s"), vcsInfo, pPkt);
        // TODO add code to support this if wanted
        break;

    case TKC_COMMAND:                          // Spike2 sent a command to the talker
        AddMsg(_T("Command received from Spike2, function code %d, string %s"), vcsInfo, pPkt);
        // TODO add code to support this if wanted
        break;

    case TKC_TALKERIDLE:
    {
        wstr = _T("TalkerIdle command received");
        vcsInfo.push_back(wstr);
        m_cHardW.Sample(false);                 // Stop sampling
        nRes = 0;                               // Return 0 to return to idle state
        break;
    }
    case TKC_TALKERCLOSE :                      // Spike2 wants the talker to close
    {
        wstr = _T("TalkerClose command received");
        vcsInfo.push_back(wstr);
        m_cHardW.Sample(false);                 // Stop sampling
        nRes = -1;                              // and return -1 to disconnect
        break;
    }
    }

    // We have to call DoneRx once the data packet has been handled. If we are going
    //  to disconnect as a result of a Spike2 request however, we don't call it as
    //  that can result in a race condition leading to a read error from CTalkIF.
    if (nRes >= 0)                              // Don't call if we are about to disconnect
        talk.DoneRx();                          // Otherwise MUST call this once packet handled
    return nRes;
}

/*!
Handles data received from the hardware, most obviously by polling for it
\returns            Zero or a -ve error code
*/
int CMainFrame::HandleData()
{
    int nRes = 0;
    // TODO what is necessary to deal with incoming data
    return nRes;
}

/*!
Handle any remaining packets of data at the end of sampling as this talker
has been told to stop.
*/
void CMainFrame::HandleLastData(double /*dEnd*/)
{
    // TODO what is necessary to deal with any left-over data that has not been
    // sent to Spike2.
}

//! Get all data that might be held in the hardware buffers
void CMainFrame::FlushBuffers()
{
    // TODO what is necessary to get rid of any data buffers holding data for Spike2
}

//! Return estimated Spike2 time since the sampling started
double CMainFrame::ActiveTime()
{
    double dTime = 0;
    if (m_cTalk.State() == TKS_ACTIVE)          // If active we can get time
        dTime = m_timer.Seconds() - m_dTimeZero; // Relative to sampling start
    return dTime;
}

//! Clear the text display window
void CMainFrame::OnEditClear()
{
    m_vcsLog.clear();                           // Empty out all the strings
    m_wndView.UpdateScroller();                 // Update scroll bar and redraw
}

//! Update the status bar panes
void CMainFrame::OnUpdateServer(CCmdUI *pCmdUI)
{
    if (m_csServer == _T("."))
        pCmdUI->SetText(_T("Local"));
    else
        pCmdUI->SetText(m_csServer);
}

void CMainFrame::OnUpdateConnect(CCmdUI *pCmdUI)
{
    if (m_cTalk.Connected())
        pCmdUI->SetText(_T("Connected to Spike2"));
    else
        pCmdUI->SetText(_T("Not connected"));
}

void CMainFrame::OnUpdateSampling(CCmdUI *pCmdUI)
{
    if (m_cTalk.Connected())
    {
        if (m_cTalk.Active())
            pCmdUI->SetText(_T("Sampling"));
        else
            pCmdUI->SetText(_T("Idle"));
    }
    else
        pCmdUI->SetText(_T(""));
}

void CMainFrame::OnUpdateTime(CCmdUI *pCmdUI)
{
    if (m_cTalk.Active())
    {
        CString str;
        str.Format(_T("%.1f s"), ActiveTime());
        pCmdUI->SetText(str);
    }
    else
        pCmdUI->SetText(_T(""));
}

//! Check that a path is valid and is not a file and is not read-only
/*!
Checks that we have passed in a valid path that refers to a valid, writeable directory.
\param szName The path to check. It can end with a \ or not; we cope either way.
\return       0=OK, 1=no such path, 2=file name, 3=read only, 4=other problem (like offline).
*/
int CMainFrame::PathExists(const CString& csPath)
{
    int iErr = 0;
    TCHAR full[_MAX_PATH+1];
    full[0] = 0;                                // Ensure that this starts off OK
    if (_tfullpath(full, csPath.GetString(), _MAX_PATH+1))
    {
        // Check that we have been passed a valid directory that is not read-only
        DWORD dwAttr = ::GetFileAttributes(full);   // get file attributes
        if (dwAttr == (DWORD)-1)                    // bad file name or no such path
            iErr = 1;
        else if ((dwAttr & FILE_ATTRIBUTE_DIRECTORY) == 0)
            iErr = 2;                               // this exists, but is a file
        else if (dwAttr & FILE_ATTRIBUTE_READONLY)  // must not be a read-only folder
            iErr = 3;                               // read only folder
        else if (dwAttr & FILE_ATTRIBUTE_OFFLINE)   // unsuitable for other reasons
            iErr = 4;
    }
    else
        iErr = 1;                               // name is too long

    return iErr;
}

// Menu command to edit the connection settings
void CMainFrame::OnConSet()
{
    CConSetDlg conDlg(m_csServer, Num(), this);
	if (conDlg.DoModal() == IDOK)
    {
        CString csServ = conDlg.Server();
        csServ.Trim();                          // Get rid of unwanted white space
        if (csServ.IsEmpty())                   // Convert empty string to local machine
            csServ = _T(".");
        int num = conDlg.Num();
        if ((m_csServer != csServ) || (Num() != num))
        {
            if (m_cTalk.Connected())            // Disconnect before changing settings
                m_cTalk.Disconnect(true);
            SetServer(csServ);                  // Save the new settings
            SetNum(num);
            m_dwSpikeConnect = 0;               // Allow an immediate connection attempt
            m_wndView.UpdateScroller();         // Update text, scroll bar and redraw
        }
    }
}

// Menu command to edit the timing drift compensation options
void CMainFrame::OnDriftOpt()
{
    CDriftOptDlg optDlg(m_dDrYScale, m_dDrXScale, m_bDrDebug, this);
	if (optDlg.DoModal() == IDOK)
    {
        m_dDrYScale = optDlg.YScale();          // Retrieve and save the new settings
        m_dDrXScale = optDlg.XScale();
        m_bDrDebug = optDlg.DrDebug();
        if (m_cTalk.Connected())                // Notify Spike2 as channels available may have changed
            m_cTalk.SendPacket(TKC_LOCALCONFIG);
    }
}

//! Enable for connection settings and drift options commands
void CMainFrame::OnUpdateNotActive(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(!m_cTalk.Active());
}


//! The dialog used to edit drift compensation options
CDriftOptDlg::CDriftOptDlg(double dYScale, double dXScale, bool bDrDebug, CWnd* pParent)
            : CDialog(CDriftOptDlg::IDD, pParent)
{
    m_dYScale = dYScale;
    m_dXScale = dXScale;
    m_bDrDebug = bDrDebug ? 1 : 0;
}

void CDriftOptDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
    DDX_Check(pDX, IDC_DRDEBUG, m_bDrDebug);
    DDX_Text(pDX, IDC_YSCALE, m_dYScale);
    DDV_MinMaxDouble(pDX, m_dYScale, 0.5, 3);
    DDX_Text(pDX, IDC_XSCALE, m_dXScale);
    DDV_MinMaxDouble(pDX, m_dXScale, 0.25, 10);
}


//! The dialog used to edit Spike2 connectiion settings
CConSetDlg::CConSetDlg(const CString& csServ, int num, CWnd* pParent)
    : CDialog(CConSetDlg::IDD, pParent)
{
    m_csServ = csServ;
    if (m_csServ == _T("."))                    // Convert local machine to blank
        m_csServ.Empty();
    m_num = num;
}

void CConSetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
    DDX_Text(pDX, IDC_MACHINE, m_csServ);
    DDX_Text(pDX, IDC_TNUM, m_num);
    DDV_MinMaxInt(pDX, m_num, 0, 9);
}

