////////////////////////////////////////////////////////////////////////////
//
// Hardware interface class
//
// This code provides all of the basic, lower-level functionality needed to
//  communicate with whatever hardware is in use. The functions and other
//  aspects of this class will of course depend crucially upon how the
//  hardware being supported operates.

#include "stdafx.h"
#include "hardw.h"                             // Definitions of our stuff

////////////////////////////////////////////////////////////////////////////
//
// CHardIF - the code that handles all or most of the hardware-specific stuff
//
////////////////////////////////////////////////////////////////////////////
//! Constructor initialises member variables and sets up events and buffers
CHardIF::CHardIF()
{
    m_pWnd = nullptr;
    m_pTalk = nullptr;
    m_nNum = 0;                                 // The talker number, zero is default
    m_nPar = 0;                                 // TODO Replace with initialisation of actual parameters
    m_dPar = 0;
    m_bConnected = false;                       // At the moment we are disconnected
    m_bActive = false;                          // and therefore not active
    m_uLastCount = 0;                           // Initialise timing information
    m_dBlockTime = 0;
}

//! Destructor makes sure we are disconnected and cleans up
CHardIF::~CHardIF()
{
    Disconnect();                               // Make sure we are disconnected
}

//! Connect to hardware
int CHardIF::Connect(CTalkIF* pTalk, CWnd* pWnd)
{
    m_csLastConErr.Empty();                     // Start off with no connection error
    if (Connected())                            // Cannot connect unless disconnected
    {
        m_csLastConErr = _T("Cannot connect when already connected");
        return DTE_BAD_STATE;
    }

    m_pTalk = pTalk;                            // Save pointer to the talker interface
    m_pWnd = pWnd;                              // Save the window for messages

    TRACE(_T("Connected to hardware\n"));

    SetConnected(true);                         // We are now connected
    Interrogate();                              // Find out what we have here; build the talker and channel info
    SetActive(false);                           //  and in the idle state
    return 0;
}

//! Shut down and disconnect from hardware
int CHardIF::Disconnect(bool bNotify)
{
    if (!Connected())                           // Do nothing if not connected
        return 0;
    if (m_bActive)                              // If sampling is in progress, kill it off
    {
        // TODO add code to kill sampling off
    }
    SetActive(false);
    if (bNotify)                                // Unless disabled, notify hardware
    {
        // TODO add code to notify hardware of closing connection, if needed
    }

    // TODO close connection to hardware

    SetConnected(false);                        // Tidy up the connection state information
    m_pWnd = nullptr;                           // Clean up and we are done
    m_pTalk = nullptr;
    return 0;
}

//! Check that comms with hardware appear to be OK, returns false if hardware gone
bool CHardIF::CheckComms()
{
    if (!Connected())                           // Do nothing if not connected
        return false;
    // TODO add code to return false if hardware appears to have gone, if possible
    return true;                                // Otherwise return true as all OK
}

//! reload information from the hardware
int CHardIF::Refresh()
{
    return Interrogate();                       // rebuild the talker and channel info
}

//! Return best estimate of current hardware time TODO make all necessary changes
// This is my current preferred mechanism for finding the current time for the
//  hardware to send to Spike2 for drift compensation. The idea is that m_uLastCount
//  holds the count of data points/blocks/whatever which gives us a data time when
//  divided by the rate. Then the value is adjusted using m_dBlockTime, which is the
//  time at which we got the data that set m_uLastCount, to give us our estimate of
//  the actual time now from the point-of-view of the hardware.
//
// The while loop is used because an obvious way of receiving data from the hardware
//  is to have a separate thread which polls for it or handles data reception. This
//  means that m_uLastCount and m_dBlockTime could change spontaneously when the other
//  thread does something, so we need to repeatedly find two times until they are the
//  same, which means they have not changed during the two calculations.
double CHardIF::Now()
{
    double dNow = 0;
    if (m_bActive)
    {
        double dN1, dN2;
        do                                      // The loop avoids problems
        {                                       // with data updating as we read it
            dN1 = (m_uLastCount / 1000.0) + (m_timer.Seconds()-m_dBlockTime);
            dN2 = (m_uLastCount / 1000.0) + (m_timer.Seconds()-m_dBlockTime);
        } while (fabs(dN1-dN2) > 1e-4);         // Keep going until the times match
        dNow = dN1;                             // Return our best time
    }
    return dNow;
}

/*!
Generate an error record, save it in the queue and notify the window of it.
\param  csErr    A string describing the error in a human-friendly fashion
\param  nLevel   Error level (0 to 3, being info, warning, error and critical)
\param  nChan    The channel number to which the error applies or -1 for all channels
\param  nCode    The (presumed negative) error code
*/
void CHardIF::LogError(const CString& csErr, int nLevel, int nChan, int nCode)
{
    CTalkErr err(csErr, nLevel, nChan, nCode);  // Build error information object
    m_errs.save(err);                           // Save it in the queue
}

//! Get the talker name - must be ASCII so don't do anything weird
CString CHardIF::Name() const
{
    CString str = TALK_NAME;                   // Get the basic talker name
    if (m_nNum > 0)                             // Append number if necessary
        str.Format(_T("%s%d"), TALK_NAME, m_nNum);  // just simple numeric text
    return str;
}

//! Get the number of talker channels available
int CHardIF::Chans()
{
    return (int)m_vChans.size();                // Channel count equals vector size
}

//! Return the general talker information
int CHardIF::Talk(TalkerInfo& talk)
{
    if (!Connected() || (Chans() <= 0))         // Return error if not connected to good hardware
        return DTE_NO_HW;

    // Return information about this talker as generated by Interrogate function
    talk = m_rInfo;                             // Start off with the basic info
    CStringA astr(Name());                      // We need the name as ASCII
    strcpy_s(talk.szName, TALK_NAME_SZ, astr.GetString()); // The name, might have number added
    talk.nChans = Chans();                      // The number of channels
    return 0;
}

//! Return the information about a talker channel
int CHardIF::Chan(int nChan, TalkerChanInfo& chan)
{
    if (!Connected() || (Chans() <= 0))         // Return error if not connected to good hardware
        return DTE_NO_HW;
    if ((nChan < 0) || (nChan >= Chans()))      // or if channel number is stupid
        return DTE_NO_HW;

    // Return information about this channel as generated by Interrogate function
    chan = m_vChans[nChan];                     // Copy all the information across
    chan.nChan = nChan;                         // Make sure the channel number is correct
    return 0;
}

/*! Return information about the configuraion dialog
\param  dlg     Structure to hold dialog information.
\return         0 or a -ve error code.
*/
int CHardIF::Dlg(TalkerDlgInfo& dlg)
{                                               // TODO Change the code to match the parameters needed
    dlg.nItems = 2;                             // Two example items in the dialog
    strcpy_s(dlg.szTitle, 60, "Example configuration");
    return 0;
}

/*! Return information about a dialog item
\param  nItem   The item number.
\param  item    Structure to hold dialog item information.
\return         0 or a -ve error code.
*/
int CHardIF::DlgItem(int nItem, TalkerDlgItem& item)
{                                               // TODO Change the code to match the parameters needed
    item.nItem = nItem;                         // The dialog item must be set
    switch (nItem)                              // Rest according to the item
    {
    case 0:                                     // Item zero is the exqmple integer
        item.nType = TDT_INT;
        strcpy_s(item.szText, 256, "Example integer|Used to show how an integer value acts");
        item.dLo = -25;                         // Allowed integer range
        item.dHi = 25;
        item.dSpin = 5.0;                       // Spinner at 5
        break;
    case 1:                                     // Item one is the example real
        item.nType = TDT_REAL;                  // A floating point value
        strcpy_s(item.szText, 256, "Example real|Used to show how a real value acts");
        item.dLo = 0;                           // Allowed real limits
        item.dHi = 100;
        item.dSpin = 0.1;                       // Spinner at 0.1 ms
        item.nPre = 4;
        break;
    default:                                    // This should never happen
        ASSERT(FALSE);                          // Unless the case statement does not match dialog item count
        break;
    }
    return 0;
}

/*! Return or save dialog item value
\param  bGet    True to get current value, false to set new value
\param  nItem   The item number.
\param  pkt     Structure holding or to hold relevant value.
\return         0 or a -ve error code.
*/
int CHardIF::DlgValue(bool bGet, int nItem, TalkPacket& pkt)
{                                               // TODO Change the code to match the parameters needed
    if (bGet)
        pkt.nParam1 = nItem;                    // The item number must be returned if reading
    switch (nItem)                              // Values according to the item
    {
    case 0:                                     // Item zero is example integer
        if (bGet)                               // Read or write according to bGet
            pkt.nParam2 = m_nPar;
        else
            m_nPar = pkt.nParam2;
        break;
    case 1:                                     // Item one is the example real
        if (bGet)                               // Read or write according to bGet
            pkt.dParam1 = m_dPar;
        else
            m_dPar = pkt.dParam1;
        break;
    default:                                    // This should never happen
        ASSERT(FALSE);                          // Unless the case statement does not match dialog item count
        break;
    }
    return 0;
}

/*!
Return XML item information. The szName and nType parts of xnv should be set to the
item name (as used in XML file) and type, respectively. The nVal, dVal or szText
parts of xnv (according to the type) should be set to the either the current value
or the default value of the parameter. Set nType to -1 if nItem is out-of-range,
this will indicate to Spike2 that there are no more XML items.
\param  bGet    True to get current value, false to get default value.
\param  nItem   The item number.
\param  xnv     Structure to hold the required information.
\return         0 or a -ve error code.
*/
int CHardIF::XmlNameValue(bool bGet, int nItem, TalkerXMLNameVal& xnv)
{                                               // TODO Change the code to match the parameters needed
    xnv.nItem = nItem;                          // Must always return the item number
    switch (nItem)
    {
    case 0:                                     // Parameter zero is example integer
        xnv.nType = 0;                          // Set the type flag
        strcpy_s(xnv.szName, 256, "Integer");
        if (!bGet)                  
            xnv.nVal = 0;                       // Default value
        else
            xnv.nVal = m_nPar;                  // or return current value
        break;
    case 1:                                     // Parameter one is example real
        xnv.nType = 1;                          // An real
        strcpy_s(xnv.szName, 256, "Real");
        if (!bGet)                  
            xnv.dVal = 1;                       // default is 1
        else
            xnv.dVal = m_dPar;                  // or return current value
        break;
    default:
        xnv.nType = -1;                         // Return -1 to indicate no more parameters
        break;
    }
    return 0;
}

/*!
Save configuration value read from XML. The nParam2, dParam1 or szParam parts
parts of pkt (according to the type) hold the new value of the parameter.
\param  nItem   The item number.
\param  pkt     Structure with the new parameter value in it.
\return         0 or a -ve error code.
*/
int CHardIF::XmlValue(int nItem, TalkPacket& pkt)
{                                               // TODO Change the code to match the parameters needed
    switch (nItem)
    {
    case 0:                                     // Parameter zero is example integer
        m_nPar = pkt.nParam2;
        break;
    case 1:                                     // Parameter one is example real
        m_dPar = pkt.dParam1;
        break;
    default:                                    // This should never happen
        ASSERT(FALSE);                          // Unless the case statement does not match XmlNameValue
        break;
    }
    return 0;
}

//! Deal with initialisation of sampling information
int CHardIF::SampleClear()
{
    return 0;
}

//! Deal with channel enabling for sampling. Return value is zero if all is
//  OK or -1 if the channel is somehow unavailable.
int CHardIF::EnableChan(int /*nChan*/)
{
    return 0;
}

//! Deal with query if ready to sample. Return value 1 if ready, 0 if not yet
//  or -1 if unable to sample
int CHardIF::QueryReady()
{
    return 1;
}

/*!
Start sampling or stop it
\param  bStart  True to start sampling, false to stop
\return         0 or a -ve error code
*/
int CHardIF::Sample(bool bStart)
{
    if (bStart)                                 // Do a bit of extra setup before starting
    {
        // TODO add code to start off sampling, log critical error if this fails
    }
    else
    {
        // TODO add code to stop sampling, log error if this fails
    }
    return 0;
}

//! 
/*!
Retrieve and save (locally) information about talker and available channels
\return         0 or a -ve error code
*/
int CHardIF::Interrogate()
{
    int nRes = 0;

    // TODO read back and save all available information about the hardware. The example code
    //  will at least give you a starting point.
    m_rInfo.nChans = 1;                         // Number of channels
    m_rInfo.nVer = 100;                         // Version of this talker * 100
    CStringA astr(Name());                      // We need the name as ASCII
    strcpy_s(m_rInfo.szName, TALK_NAME_SZ, astr.GetString()); // The talker name
    strcpy_s(m_rInfo.szDesc, TALK_DESC_SZ, "Talker interface to xxxxxx"); // Talker description TODO change
    m_rInfo.nVerComp = 100;                     // Compatible with version 1.00 and later of this talker
    m_rInfo.nConfigID = 1;                      // Spike2 manages configuration data
    m_rInfo.nFlags = m_pTalk->IsRemote() ? TKF_REMOTE : 0;  // Tell Spike2 if we are remote TODO check flags are as required
    m_rInfo.nFlags |= TKF_SPCONF;               //  and we use Spike2 configuration TODO again check if this is wanted

    m_vChans.clear();                           // Get rid of all channel information
    TalkerChanInfo chan;
    chan.nType = TCT_REALWAVE;                  // Generate information about the channel
    astr.Format("Data for channel %d", 1);      // TODO Make all below correct NBNB different channel types need different information!!!
    strcpy_s(chan.szDesc, TALK_DESC_SZ, astr);
    strcpy_s(chan.szUnique, TALK_UNIQ_SZ, "Unique"); // TODO NBNB The channel ID string *must* be unique!!
    chan.nFlags = 0;                            // Usually, no channel flags are needed
    strcpy_s(chan.szTitle, TALK_CTITL_SZ, "Title"); // TODO Make correct NBNB The channel titles must be unique if we allow spec version 3
    strcpy_s(chan.szUnits, TALK_CUNIT_SZ, "Units"); // The channel data units TODO make correct
    chan.dWRate = 2000.0;                       // Waveform sample rate
    chan.dMax = 5;                              // Supply real wave expected data limits
    chan.dMin = -5;
    chan.dScale = 1.0;                          // And also limits as
    chan.dOffset = 0.0;                         //  scale and offset values
    m_vChans.push_back(chan);

    return nRes;
}
