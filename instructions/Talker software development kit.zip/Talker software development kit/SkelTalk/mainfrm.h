//! mainfrm.h : interface for the CMainFrame class
#pragma once

#include "..\common\s2talk.h"                   // All the standard talker defines and structures
#include "childview.h"                          // The text view displaying status and log info
#include "..\common\talkif.h"                   // The talker interface object
#include "hardw.h"                              // The hardware interface object
#include "resource.h"

constexpr int MIN_SPEC_VER = 3;                 //!< The minimum talker interface spec version we accept
constexpr int CONNECT_INT = 1000;               //!< Milliseconds between attempts to connect to hardware/Spike2
constexpr int CONNECT_PAUSE = 5000;             //!< Milliseconds we hold off on Spike2 reconnect after Spike2 quits
constexpr int MAX_LOG = 60;                     //!< Maximum number of log message strings that are stored

class CMainFrame : public CFrameWnd
{
public:
	CMainFrame();
	virtual ~CMainFrame();

protected: 
	DECLARE_DYNAMIC(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL    PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL    OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);

// Implementation
public:
    void            SetNum(int num);            //!< Set and get the talker number
    int             Num() const;
    void            SetServer(const CString& csServer); //!< Set and get the Spike2 machine name
    CString         Server() const {return m_csServer;}

    int             LogStatus();                //!< Count of status strings at top of view
    CString         StatusString(int num);      //!< Generate status string n (0 based)
    std::vector<CString>& GetLog(){return m_vcsLog;} //!< Access to log text

private:
    void AddMsg(const TCHAR* szMsg, std::vector<CString>& vcsInfo, volatile TalkPacket* pPkt) const;

protected:
    bool            ValidScrPlace(WINDOWPLACEMENT* pPlace);
    void            DoRegistry(bool bSave);     //!< Save and load registry settings
    double          ActiveTime();               //!< Time since sampling started
    int             TalkIdle(CTalkIF& talk, std::vector<CString>& vcsInfo);
    int             TalkActive(CTalkIF& talk, std::vector<CString>& vcsInfo);
    int             HandleData();               //!< Deal with new data available from the hardware
    void            HandleLastData(double dEnd); //!< Deal with any left-over data at end of sampling
    void            FlushBuffers();             //!< Make sure all the data buffers are empty

    void            LogError(int nLev, bool bTalk, int nChan, const CString& csInfo, int nCode);
    void            LogStrings(const std::vector<CString>& vcsInfo);
    void            LogString(const CString& cStr);
    int             PathExists(const CString& csPath); //!< Function to test for usable directory

    CString         m_csServer;                 //!< The Spike2 talker server machine name or "." if local
	CString         m_csAppPath;                //!< Path to application data directory, if needed

    CToolBar        m_wndToolBar;               //!< Standard toolbar - change buttons in resource editor
    CStatusBar      m_wndStatusBar;             //!< Standard status bar with panes
	CChildView      m_wndView;                  //!< The text view that displays status and log info

    CTalkIF         m_cTalk;                    //!< Talker interface handler class
    CHardIF         m_cHardW;                   //!< Hardware interface class

    DWORD           m_dwHardConnect;            //!< The next time we are allowed to try to connect to the hardware
    DWORD           m_dwSpikeConnect;           //!< The next time we are allowed to try to connect to Spike2
    UINT_PTR        m_uTimer;                   //!< Identifier for SetTimer timer
    CTalkTimer      m_timer;                    //!< High-accuracy timer used for all timing
    double          m_dTimeZero;                //!< Our clock time corresponding to Spike2 sampling time zero
    double          m_dHardZero;                //!< Spike2 time for first-received data (= talker time offset)
    double          m_dTimeBase;                //!< The file time base from Spike2 - often not used

    // These are the parameters managed by the drift options dialog
    bool            m_bDrDebug;                 //!< Flag to enable drift debug info
    double          m_dDrYScale;                //!< Scale factor controlling SD limits
    double          m_dDrXScale;                //!< Scale factor controlling time range

    int             m_nLog;                     //!< The count of log messages so they can be numbered
    std::vector<CString> m_vcsLog;              //!< The array of log messages for display

// Generated message map functions
protected:
	afx_msg int     OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void    OnDestroy();
    afx_msg void    OnTimer(UINT_PTR nIDEvent);
	afx_msg void    OnSetFocus(CWnd *pOldWnd);
    afx_msg void    OnRefresh();
    afx_msg void    OnReconnect();
    afx_msg void    OnEditClear();
    afx_msg void    OnUpdateIfIdle(CCmdUI* pCmdUI);
    afx_msg void    OnUpdateReconnect(CCmdUI* pCmdUI);
    afx_msg LRESULT OnTalkPacket(WPARAM wParam, LPARAM lParam);
    afx_msg void    OnConSet();
    afx_msg void    OnDriftOpt();
    afx_msg void    OnUpdateNotActive(CCmdUI* pCmdUI);
    afx_msg void    OnUpdateServer(CCmdUI *pCmdUI);
    afx_msg void    OnUpdateConnect(CCmdUI *pCmdUI);
    afx_msg void    OnUpdateSampling(CCmdUI *pCmdUI);
    afx_msg void    OnUpdateTime(CCmdUI *pCmdUI);
	DECLARE_MESSAGE_MAP()
};

//! CDriftOptDlg dialog used to adjust drift compensation options
class CDriftOptDlg : public CDialog
{
public:
	CDriftOptDlg(double dYScale, double dXScale, bool bDrDebug, CWnd* pParent);

    double      YScale() const {return m_dYScale;} // Member var access
    double      XScale() const {return m_dXScale;}
    bool        DrDebug() const {return m_bDrDebug != 0;}

    // Dialog Data
	enum { IDD = IDD_DRIFTOPT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX); // DDX/DDV support

    // Implementation
protected:
    //virtual BOOL OnInitDialog();
	//virtual void OnOK();
    //afx_msg void OnHelp();

    //DECLARE_MESSAGE_MAP()

private:
    double      m_dYScale;                      //!< Local copies of data used for editing
    double      m_dXScale;
    int         m_bDrDebug;
};

//! CConSetDlg dialog used to alter connection settings
class CConSetDlg : public CDialog
{
public:
	CConSetDlg(const CString& csServ, int num, CWnd* pParent);

    CString     Server() const {return m_csServ;} // Member var access
    int         Num() const {return m_num;}

// Dialog Data
	enum { IDD = IDD_CONSET };

protected:
	virtual void DoDataExchange(CDataExchange* pDX); // DDX/DDV support

private:
    CString     m_csServ;
    int         m_num;
};

