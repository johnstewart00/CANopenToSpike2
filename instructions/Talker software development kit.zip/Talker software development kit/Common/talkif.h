////////////////////////////////////////////////////////////////////////////
//
// talkif.h
//
// Defines for code that manages connection and communication for a talker. This
//  is a newer enhanced version that maintains a queue of packets for transmission.
//
// Copyright (c) 2010 by Cambridge Electronic Design Ltd. All rights reserved.
//
// Started 23/Apr/2010 by TDB
//
#ifndef __TALKIF_H__
#define __TALKIF_H__

#include "..\common\s2talk.h"                   //! Talker interface defines

CString LastErrStr(DWORD dwCode = 0);           //! Function to help with error strings

//! Hi-res timer class for use by the talkers
/*!
This gives a time in seconds using the performance counter if available, otherwise
it uses the multimedia clock. In either case, the mechanisms used match those in
Spike2 so that both programs (if running on the same PC) use the same timing.

Right now there is no protection against overflow. This will occur once every year
or so for the performance counter and about every month for the multimedia system
timer, so we may need to look at this at some point to make the multimedia timer
bomb proof...
*/
class CTalkTimer
{
public:
    CTalkTimer();
    ~CTalkTimer();
    double Seconds() const; 
private:
    LARGE_INTEGER   m_llFrequency;              //! Performance counter frequency or zero
    DWORD           m_uiResolution;             //! Resolution for multimedia system time
};


//! A class that holds information about an error - so we can have a queue of errors
class CTalkErr
{
public:
    CTalkErr()                                  //! The default constructor
    {
        m_nLevel = 0;
        m_nChan = 0;
        m_nCode = 0;
    }
    CTalkErr(CString str, int nLevel, int nChan, int nCode) //! Constructor with values
    {
        m_csErr = str;
        m_nLevel = nLevel;
        m_nChan = nChan;
        m_nCode = nCode;
    }

    CString         string() const {return m_csErr;}
    int             level() const {return m_nLevel;}
    int             chan() const {return m_nChan;}
    int             code() const {return m_nCode;}

private:
    CString         m_csErr;                    //!< A string describing the error
    int             m_nLevel;                   //!< The error level from 0 (info) to 3 (critical), or -1 for disconnect request
    int             m_nChan;                    //!< The talker channel number or -1 for all channels
    int             m_nCode;                    //!< The error code
};

//! A class that implements a thread-safe queue of errors
/*!
The thread-safe queue errors is not strictly necessary unless there are multiple threads
in action, but its simple and clean.
*/
class CErrQ
{
public:
    CErrQ(){};                                  //!< Constructor does not need to do anything
    CErrQ(const CErrQ& rhs);                    //!< Copy constructor is needed because of mutex
    CErrQ& operator = (const CErrQ& rhs);       //!< As is assignment operator

    int             save(const CTalkErr& err);  //!< Add an error to the queue
    int             errors();                   //!< Return the count of errors in the queue
    CTalkErr        get();                      //!< Get the oldest error from the top of the queue
    void            clear();                    //!< Empty the entire queue

private:
    std::queue<CTalkErr> m_qErrs;               //!< The queue of saved errors
    std::mutex      m_mutErrQ;                  //!< The mutex that protects the queue
};


struct TalkPacket;                              //!< Forward definition for RxBuf

// A general-purpose pointer shift function
template <typename T>
T* MovePtr(T* ptr, size_t n) { return reinterpret_cast<T*>(reinterpret_cast<char*>(ptr) + n); }

//! Error codes, we start these at -840 to avoid other error code values.
/*!
These are codes that are only used by CTalkIF, others are defined in s2talk.h
*/
enum eErrCodesT
{
    TKE_NO_TALKER = -840,   //!< The talker interface was not found or was incompatible
    TKE_BAD_STATE = -841,   //!< Talker idle when should be active or vice-versa
    TKE_NO_MEMORY = -842,   //!< Memory or resource shortage caused failure
    TKE_NO_MPIPE = -843,    //!< The master pipe was not found (Spike2 not running, probably)
    TKE_BAD_SPEC = -844     //!< Spike2 was found, but the talker interface spec was too low
};


//! Definition of special message ID values
/*!
These messages are posted from the talker interface to the window indicated
in Connect() to notify it that something has happened. You can change the
message values to something else if you need to do so, as long as both bits
of code use the same definition and are recompiled.

TKN_PACKET indicates a packet has been received and checked. lParam is a
pointer to the sending CTalkIf so that multiple talkers can be managed. The
handler for this message should deal with the packet as nessesary and then
call the DoneRx() function to indicate that the packet is finished-with.
*/
constexpr int TKN_PACKET = WM_USER + 200;


//! The CTalkIF class manages all communications with Spike2
/*!
This is the code that manages communications for an individual talker. All of
the actual communications are carried out by the talker thread function, we
provide externally accessible functions to do various useful things.
*/
////////////////////////////////////////////////////////////////////////////
//
class CTalkIF
{
public:
    CTalkIF();
    virtual ~CTalkIF();
    CTalkIF(const CTalkIF& rhs);                //!< Copy constructor is needed because of mutex
    CTalkIF& operator = (const CTalkIF& rhs);   //!< As is assignment operator

    // Functions to try to connect to Spike2 and to disconnect
    int             Connect(CString csName, CString csSvr, int nMinSpec, int nSerNum, int nFlags, CWnd* pWnd);
    int             Disconnect(bool bNotify);

    // Various access functions of varying usefulness
    CString         Name() const {return m_csName;}
    CString         Server() const {return m_csServer;}
    int             SpecVer() const {return m_nSpecVer;}
    void            SetPipeID(int n) { m_nPipeID = n;}
    int             PipeID() const { return m_nPipeID;}
    bool            LowSpec() const {return m_bLowSpec;}
    bool            BadSerial() const {return m_bBadSerial;}
    void            ResetBlock(){m_bLowSpec = m_bBadSerial = false;}
    int             Spike2Ver() const {return m_nSpike2Ver;}
    CWnd*           MsgWnd() const {return m_pWnd;}

    // State access. You need to take care of switching between the idle and the active
    // state, internal code takes care of switching between idle and disconnected.
    int             State() const {return m_nState;}
    void            SetState(int nState){m_nState = nState;}
    bool            Connected() const {return m_nState >= TKS_IDLE;}
    bool            Active() const {return m_nState >= TKS_ACTIVE;}

    //! Find out if you are running remotely or not
    bool            IsRemote() const {return m_bRemote;}
    bool            IsLocal() const {return !m_bRemote;}

    //! Helper function used to apply skew to drift info settings
    void            TweakDrift(TalkerDriftInfo& rPkt, double dYScale, double dXScale);

    // Error information access functions
    int             Errors() {return m_errs.errors();}
    CTalkErr        GetError(){return m_errs.get();}    //!< Get the oldest error from the top of the queue
    void            LogError(const CString& csErr, int nLevel, int nChan, int nCode); //!< Save error and generate notification
    CString         LastConErr() const {return m_csLastConErr;} //!< Get info on last connect failure

    // Send data to Spike2. SendPacket builds a TalkPacket for you while SendBlock
    //  simply sends a block of memory, assumed to be a valid packet, to Spike2.
    int             SendProblem(int nLev, int nChan, const CString& csInfo); //< Sends problem report with checks
    int             SendPacket(int nCode, int nP1 = 0, int nP2 = 0, double dP1 = 0,
                               double dP2 = 0, const CString* pStr = nullptr);
    int             SendBlock(void* pData, DWORD dwSize); //!< Sends a block of data
    int             WaitForTxIdle(DWORD dwTO = 500);

    // These two functions give you access to the last packet received from Spike2
    volatile TalkPacket* RxBuf(){return reinterpret_cast<volatile TalkPacket*>(m_pInBuf);}  // Point to the last recieved packet
    DWORD           RxSize(){return m_dwRBytes;} //!< The size of the last received packet

    // This is the function you MUST call after you have been notified that a packet
    //  has been received and have completely finished dealing with it. The ONLY time
    //  you do not call it is when you are about to disconnect because Spike2 sent
    //  you a TALKERCLOSE packet.
    int             DoneRx();                   //!< Tidy up when read is over & ask for more

    // This function runs in the context of the interface thread and does all the
    //  nitty-gritty low-level communications. It is called by the thread created
    //  by a successful Connect() call. DO NOT DIRECTLY CALL THIS FUNCTION.
    int             ThreadProc();

protected:

private:
    // An internal function that waits for the talker to be in a particular state
    int             WaitForState(int nState, DWORD dwTO = 500);

    // Internal functions used for communications management
    int             NextPacket();               //!< Try to send next item in tx queue
    DWORD           DoneTx();                   //!< Tidy up after the write event has fired
    int             MaintainRx();               //!< Make sure read operation is on-going
    bool            NotifyRx();                 //!< Deal with data when the read event has fired

    // Variables holding various bits of general information
                CString m_csName;               //!< The name of this talker
                CWnd*   m_pWnd;                 //!< Window to receive notification messages
                int     m_nSpecVer;             //!< Specification version in use
                bool    m_bLowSpec;             //!< Talker spec level is too low auto disconnect flag
                bool    m_bBadSerial;           //!< Flag blocks auto connect because of serial number issue
                int     m_nSpike2Ver;           //!< Spike2 version number * 100
    volatile    int     m_nState;               //!< The talker state - one of the TKS_ codes
                int     m_nPipeID;              //!< Pipe ID used with multiple copies of Spike2
                CString m_csServer;             //!< The server machine name
                bool    m_bRemote;              //!< Flag indicating a remote connection

                CErrQ   m_errs;                 //!< The queue holding our errors
                int     m_lastProbLev;          //!< The level of the last problem report
                int     m_lastProbChan;         //!< The chan of the last problem report
                CString m_csLastProbStr;        //!< The string for the last problem report
                DWORD   m_dwLastProbTime;       //!< The time of the last problem report
                CString m_csLastConErr;         //!< Info string for last failure to connect

    volatile    HANDLE  m_hPipe;                //!< The pipe used to communicate with Spike2
                HANDLE  m_hThread;              //!< The thread that manages comms over the pipe
                HANDLE  m_hStopEvent;           //!< Set this event to cause the thread to stop

    // Variables used for packet transmission
    std::mutex          m_mutTx;                //!< The mutex that protects packet transmits
                HANDLE  m_hTxEvent;             //!< Event that is set when packet tx is done
    std::queue<std::vector<char>> m_qTxPkts;    //!< Holds the queue of output packets
                OVERLAPPED m_rWOl;              //1< Overlapped information for pending write
    volatile    bool    m_bWriting;             //!< Flag set true if a WriteFile operation is ongoing
    volatile    DWORD   m_dwWBytes;             //!< Bytes written by write operation
    volatile    bool    m_bWPending;            //!< Flag set true if the write operation is pending

    // Variables used for packet receives
    std::mutex          m_mutRx;                //!< The mutex that protects packet receives
                HANDLE  m_hRxEvent;             //!< Event that is set when a packet arrives
    volatile    void*   m_pInBuf;               //!< General purpose rx buffer, size is TALK_MAX_PKT bytes
                OVERLAPPED m_rROl;              //!< Overlapped information for pending read
    volatile    bool    m_bReading;             //!< Flag set true if a ReadFile operation is ongoing
    volatile    DWORD   m_dwRBytes;             //!< Bytes read by read operation
    volatile    bool    m_bRPending;            //!< Flag set true if the read operation is pending
    volatile    bool    m_bClosing;             //!< Flag set true when closing - so things stay quiet
};

#endif
