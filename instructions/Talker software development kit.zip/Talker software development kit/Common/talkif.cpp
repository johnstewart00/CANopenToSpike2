////////////////////////////////////////////////////////////////////////////
//
// Talker interface controller and useful timer class
//
// This code provides all of the basic, low-level functionality needed to
//  implement a talker.
//
#include "stdafx.h"
#include "talkif.h"                             // Definitions of our stuff

#include "mmsystem.h"                           // For the better system clock
#include "assert.h"                             // Non-MFC assert function


//! The high-accuracy timer class (matching Spike2) for use by talkers
//  Note that, to use this class, you have to link to winmm.lib
CTalkTimer::CTalkTimer()
{
    m_uiResolution = 0;
    if (!::QueryPerformanceFrequency(&m_llFrequency))
    {
        m_llFrequency.QuadPart = 0;             // Use mm timer if perf ounter not available
	    m_uiResolution = 1;                     // Try to get a fine timer resolution
        while (::timeBeginPeriod(m_uiResolution) == TIMERR_NOCANDO)
	    {
		    if (++m_uiResolution == 20)         // if cannot set this, we are in deep...
			    break;
	    }
    }
}

//! The destructor has to signal that we have finished using the timer services
CTalkTimer::~CTalkTimer()
{
    if (m_uiResolution > 0)                     // If we set up the mm timer
        ::timeEndPeriod(m_uiResolution);
}

//! Read the timer, returning the current time in seconds
double CTalkTimer::Seconds() const
{
    double dTime;
    if (m_llFrequency.QuadPart != 0)
    {
        LARGE_INTEGER llTime;
        ::QueryPerformanceCounter(&llTime);     // get current time
        dTime = (double)(llTime.QuadPart);
        dTime /= m_llFrequency.QuadPart;
    }
    else
    {
        assert(m_uiResolution > 0);
        dTime = ::timeGetTime() / 1000.0;
    }
    return dTime;
}


//! The copy constructor - copy all items from queue. It seems to be impossible
//  to make this truly thread-safe.
CErrQ::CErrQ(const CErrQ& rhs) :
    m_qErrs(rhs.m_qErrs)                        // Dumb copy of the error queue
{
}

//! The assignment operator, again not thread safe
CErrQ& CErrQ::operator = (const CErrQ& rhs)
{
    if (this != &rhs)
        m_qErrs = rhs.m_qErrs;                  // Dumb copy of the error queue
    return *this;
}

//! Add an error to the queue
int CErrQ::save(const CTalkErr& err)
{
    std::lock_guard<std::mutex> lck(m_mutErrQ); // Multi-threaded protection
    m_qErrs.push(err);                          // Add the new error to the queue
    return 0;
}

//! Return the count of errors in the queue
int CErrQ::errors()
{
    std::lock_guard<std::mutex> lck(m_mutErrQ); // Multi-threaded protection
    return (int)m_qErrs.size();
}

//! Get the top error from the queue, and shorten the queue
CTalkErr CErrQ::get()
{
    std::lock_guard<std::mutex> lck(m_mutErrQ); // Multi-threaded protection
    CTalkErr err;                               // Default error information is no error
    if (m_qErrs.size() > 0)                     // If we have a stored error
    {
        err = m_qErrs.front();                  // Retrieve the topmost error record
        m_qErrs.pop();                          // and remove the record from the queue
    }
    return err;
}

//! Empty out the entire queue
void CErrQ::clear()
{
    std::lock_guard<std::mutex> lck(m_mutErrQ); // Multi-threaded protection
    while (m_qErrs.size() > 0)                  // If we have any stored errors
        m_qErrs.pop();                          //  remove them
}


//! A static global function to give Windows error code information - the code value and string
CString LastErrStr(DWORD dwCode /* = 0*/)
{
    if (dwCode == 0) dwCode = GetLastError();   // Read the error ourself if necessary
    const int nMaxMsg = 512;
    TCHAR szMsg[nMaxMsg];
    FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, nullptr, dwCode, 0, szMsg, nMaxMsg, nullptr);
    CString str;
    str.Format(_T(": error code %lu (%s)"), dwCode, szMsg);
    return str;
}


//! This is the thread procedure itself, it simply calls back into us.
DWORD WINAPI TalkerProc(LPVOID lpParam)
{
    reinterpret_cast<CTalkIF*>(lpParam)->ThreadProc(); // Call the function to do the work
    return 0;                                   // It's done - and so are we
}

//! CTalkIF - the code that handles communications for a single external talker
CTalkIF::CTalkIF()
{
    m_hThread = NULL;                           // Make sure we initialise data
    m_hPipe = NULL;
    m_nPipeID = 0;
    m_pInBuf = nullptr;
    m_pWnd = nullptr;
    m_bRemote = false;
    m_nSpecVer = 0;
    m_bLowSpec = m_bBadSerial = false;          // No blocks on connecting
    m_nSpike2Ver = 0;
    m_lastProbLev = 0;
    m_lastProbChan = 0;
    m_dwLastProbTime = 0;

    m_bWriting = false;                         // Initialise write control variables
    m_bWPending = false;                        //  and data structures for Tx
    m_dwWBytes = 0;
    memset((void*)&m_rWOl, 0, sizeof(OVERLAPPED));
    m_bClosing = false;

    m_bReading = false;                         // Initialise read control variables
    m_bRPending = false;                        //  and data structures for Rx
    m_dwRBytes = 0;
    memset((void*)&m_rROl, 0, sizeof(OVERLAPPED));

    SetState(TKS_DISCONNECT);                   // Start off disconnected

    // Create event used to stop thread execution
    m_hStopEvent = CreateEvent(nullptr, TRUE, FALSE, nullptr);
    assert(m_hStopEvent);

    // Create event used to signal a packet transmit
    m_hTxEvent = CreateEvent(nullptr, TRUE, FALSE, nullptr);
    assert(m_hTxEvent);

    // Create event used to signal a packet receive
    m_hRxEvent = CreateEvent(nullptr, TRUE, FALSE, nullptr);
    assert(m_hRxEvent);

    // Create buffer used for packet receives, packet max size is half buffer size
    m_pInBuf = reinterpret_cast<volatile void*>(malloc(TALK_MAX_PKT));
    assert(m_pInBuf);
}

//! The destructor tidies up the effects of the constructor
//
// Note that we DO NOT close the pipe as this is not owned by us - it is owned by
//  the thread that drives us. We assume that setting the stop event will cause the
//  thread to go (closing the pipe as it does) or that the pipe and the thread are
//  gone already (very probably this is the case given the way the code works).
CTalkIF::~CTalkIF()
{
    // Make sure we are disconnected and the thread is gone
    Disconnect(true);                           // Notify Spike2 we are going if needed

    if (m_hStopEvent)                           // Now clean everything up
        CloseHandle(m_hStopEvent);              // Get rid of the stop request event
    m_hStopEvent = NULL;

    if (m_hTxEvent)
        CloseHandle(m_hTxEvent);                //  the packet tx event
    m_hTxEvent = NULL;

    if (m_hRxEvent)
        CloseHandle(m_hRxEvent);                //  and the packet rx event
    m_hRxEvent = NULL;

    if (m_pInBuf)
        free((void*)m_pInBuf);                  // The packet rx buffer
    m_pInBuf = nullptr;
}

//! We have to have a copy constructor because of the mutexes...
CTalkIF::CTalkIF(const CTalkIF& rhs)
{
    *this = rhs;                                // Use the assignment operator to do the work
}

//! We have to have an assignment operator because of the mutexes...
CTalkIF& CTalkIF::operator = (const CTalkIF& rhs)
{
    m_csName = rhs.m_csName;                    // We just copy across everything we can...
    m_pWnd = rhs.m_pWnd;
    m_nSpecVer = rhs.m_nSpecVer;
    m_bLowSpec = rhs.m_bLowSpec;
    m_bBadSerial = rhs.m_bBadSerial;
    m_nSpike2Ver = rhs.m_nSpike2Ver;
    m_nState = rhs.m_nState;
    m_csServer = rhs.m_csServer;
    m_bRemote = rhs.m_bRemote;
    m_errs = rhs.m_errs;
    m_lastProbLev = rhs.m_lastProbLev;
    m_lastProbChan = rhs.m_lastProbChan;
    m_csLastProbStr = rhs.m_csLastProbStr;
    m_dwLastProbTime = rhs.m_dwLastProbTime;
    m_csLastConErr = rhs.m_csLastConErr;
    m_hPipe = rhs.m_hPipe;
    m_nPipeID = rhs.m_nPipeID;
    m_hThread = rhs.m_hThread;
    m_hStopEvent = rhs.m_hStopEvent;
    m_hTxEvent = rhs.m_hTxEvent;
    m_qTxPkts = rhs.m_qTxPkts;
    m_rWOl = rhs.m_rWOl;
    m_bWriting = rhs.m_bWriting;
    m_dwWBytes = rhs.m_dwWBytes;
    m_bWPending = rhs.m_bWPending;
    m_hRxEvent = rhs.m_hRxEvent;
    m_pInBuf = rhs.m_pInBuf;
    m_rROl = rhs.m_rROl;
    m_bReading = rhs.m_bReading;
    m_dwRBytes = rhs.m_dwRBytes;
    m_bRPending = rhs.m_bRPending;
    m_bClosing = rhs.m_bClosing;
    return *this;
}

//! Connect this talker to Spike2
/*!
This is the function that opens the master pipe and sets up a connection with Spike2.
\param      csName      the (ASCII) name of the talker which we will represent.
\param      csSvr       the network name of the machine upon which Spike2 is running.
\param      nMinSpec    the minimum talker interface specification version number which
                        we can operate with. If Spike2 supports a lower spec than this we
                        set a flag which will cause an automatic disconnect.
\param      nSerNum     the full Spike2 serial number or zero for any serial number allowed.
\param      nFlags      connection option flags - set bit zero for checks on Spike2 version number
\param      pWnd        pointer to the window to receive TKN_ notification messages.
\return                 zero if the connection was set up or a negative error code.
*/
int CTalkIF::Connect(CString csName, CString csSvr, int nMinSpec, int nSerNum, int nFlags, CWnd* pWnd)
{
    if (m_bLowSpec)                             // Give up straight away (error is logged already)
        return TKE_BAD_SPEC;                    //  if prev attempt got bad spec version
    if (m_bBadSerial)                           // Give up straight away (error is logged already)
        return TKE_BAD_CONFIG;                  //  if prev attempt got license failure

    m_csLastConErr.Empty();                     // Start off with no connect error info
    m_pWnd = pWnd;                              // Save handle immediately so we can log errors
    if (Connected())                            // Cannot connect unless disconnected
    {
        m_csLastConErr.Format(_T("Cannot connect talker %s when already connected"), csName.GetString());
        TRACE(_T("%s\n"), m_csLastConErr.GetString());
        return TKE_BAD_STATE;
    }
    if (!m_hStopEvent || !m_hTxEvent ||         // Kick off connect only if we have events
        !m_hRxEvent || !m_pInBuf )              //  and rx buffer. Otherwise we are dead.
    {
        m_csLastConErr.Format(_T("Cannot connect talker %s as events or buffers were not created"), csName.GetString());
        TRACE(_T("%s\n"), m_csLastConErr.GetString());
        return TKE_NO_MEMORY;
    }
    if ((csName.GetLength() <= 0) || (csSvr.GetLength() <= 0)) // Sensible string values?
    {
        m_csLastConErr.Format(_T("Cannot connect to Spike2 as either the talker or the server name is blank"));
        TRACE(_T("%s\n"), m_csLastConErr.GetString());
        return TKE_NO_TALKER;
    }
    if (csName.GetLength() >= TALK_NAME_SZ)     // Check the talker name length, for goodness sake!
    {
        m_csLastConErr.Format(_T("Cannot connect to Spike2 as this talker name (%s) is too long (max 11 chars)"), csName.GetString());
        TRACE(_T("%s\n"), m_csLastConErr.GetString());
        return TKE_NO_TALKER;
    }
    m_errs.clear();                             // No stored errors
    m_csName = csName;                          // Save connection information - we know name is legal
    m_csServer = csSvr;                         // The server name
    m_nSpike2Ver = 0;                           // Start off with no Spike2 version number

    m_bRemote = false;                          // Assume local to start with
    TCHAR szName[128];
    memset(szName, 0, sizeof(szName));          // Get our machine name
    DWORD dwBuf = 127;                          //  to determine if remote connection
    GetComputerNameEx(ComputerNamePhysicalDnsHostname, szName, &dwBuf);
    if ((m_csServer != ".") && (m_csServer.CompareNoCase(szName) != 0))
        m_bRemote = true;                       // Remote if a different computer

    // Build the name of the master control pipe using the server name supplied
    CString csPipe = _T("\\\\") + m_csServer + _T("\\pipe\\") + CString{ TALK_MASTER_PIPE };
    if (m_nPipeID > 0)                          // Add code to allow multiple Spike2 copies?
    {
        TCHAR cp = (TCHAR)('0' + m_nPipeID);    // Get 1 to 9 as a character
        csPipe += cp;                           // and append it to the pipe name
    }

    // Try to open the master control pipe so we can talk to Spike2
    HANDLE hPipe = CreateFile( 
        csPipe,                                 // pipe name 
        GENERIC_READ | GENERIC_WRITE,           // Duplex access
        0,                                      // no sharing 
        nullptr,                                // default security attributes
        OPEN_EXISTING,                          // opens existing pipe 
        0,                                      // default attributes 
        NULL);                                  // no template file 

    // Give up right away if the pipe did not open as we are not going to get anywhere.
    // No error logging here as this is normal effect of Spike2 not running.
    if (hPipe == INVALID_HANDLE_VALUE)
    {
        DWORD dwMsg = GetLastError();
        if (dwMsg == ERROR_FILE_NOT_FOUND)
            m_csLastConErr = _T("Master pipe not found - Spike2 not running?");
        else
            m_csLastConErr.Format(_T("Master pipe %s open failed%s"), csPipe.GetString(), LastErrStr(dwMsg).GetString());
        TRACE(_T("%s\n"), m_csLastConErr.GetString());
        return TKE_NO_MPIPE;
    }
    TRACE(_T("Connect %s opened master pipe\n"), csName.GetString());

    // The pipe opened OK, change to message-read mode. Don't set maximum bytes or time.
    DWORD dwMode = PIPE_READMODE_MESSAGE;
    BOOL fSuccess = SetNamedPipeHandleState(hPipe, &dwMode, nullptr, nullptr);
    if (!fSuccess) 
    {
        m_csLastConErr.Format(_T("SetNamedPipeHandleState failed%s"), LastErrStr().GetString());
        TRACE(_T("%s\n"), m_csLastConErr.GetString());
        CloseHandle(hPipe);
        return TKE_NO_TALKER;
    }

    // Build a talkerConnect packet with the required parameters
    TalkPacket rConnect;
    rConnect.nCode = TKC_TALKERCONNECT;         // Code, spec version, flags and our name
    rConnect.nParam1 = TALK_SPEC_VER;           // This is in s2talk.h - the version we compiled with
    rConnect.nParam2 = nFlags;                  // Connection option flags
    CStringA astr(m_csName);                    // We need the name as ASCII
    strncpy_s(rConnect.szParam, 64, astr.GetString(), _TRUNCATE);

    // Pass across a serial number for restricted use?
    if (nSerNum > 0)                            // Only if serial number is non-zero
    {
        CStringA csSN;
        csSN.Format("%.6d", nSerNum);           // Convert serial number into at least 6 chars of text
        const CStringA csM("CED");
        CStringA csMSN;                         // Will hold modified serial number
        for (int i = 0; i < csSN.GetLength(); ++i)
            csMSN += (char)(csSN[i] + csM[i%3]);
        strcpy_s(&rConnect.szParam[64], 192, csMSN);
    }

    // Send the TalkerConnect packet to the pipe server, give up if the write failed.
    DWORD dwBytes;
    fSuccess = WriteFile(hPipe, &rConnect, sizeof(TalkPacket), &dwBytes, nullptr);
    if ((!fSuccess) || (dwBytes != sizeof(TalkPacket)))
    {
        m_csLastConErr.Format(_T("TalkerConnect packet write failed, flag %d, bytes %lu%s"), fSuccess, dwBytes, LastErrStr().GetString());
        TRACE(_T("%s\n"), m_csLastConErr.GetString());
        CloseHandle(hPipe); 
        return TKE_NO_TALKER;
    }

    // Now read back the response from Spike2. This is a TalkPacket with OK or error
    TalkPacket rResp;
    fSuccess = ReadFile(hPipe, &rResp, sizeof(TalkPacket), &dwBytes, nullptr);
    CloseHandle(hPipe);                         // Close the master control pipe now, as we are done with it
    if (!fSuccess || (dwBytes != sizeof(TalkPacket)))
    {
        m_csLastConErr.Format(_T("Bad read of TalkerConnect response, flag %d, bytes %lu%s"), fSuccess, dwBytes, LastErrStr().GetString());
        TRACE(_T("%s\n"), m_csLastConErr.GetString());
        return TKE_NO_TALKER;
    }

    // And check that the response is satisfactory
    if ((rResp.nSize != sizeof(TalkPacket)) ||
        (rResp.nCode != (TKC_TALKERCONNECT | TKC_RESPONSE_BIT)) ||
        (rResp.nParam1 != 0) ||
        (rResp.nParam2 < 0))
    {
        TRACE(_T("Bad response from master pipe, size %d, code %08X, param %d, spec ver %d\n"), rResp.nSize, rResp.nCode, rResp.nParam1, rResp.nParam2);
        TRACE(_T("Problem description from Spike2 is %s\n"), CString(rResp.szParam).GetString());
        m_csLastConErr.Format(_T("Bad TalkerConnect response from Spike2, parameters %d %d"), rResp.nParam1, rResp.nParam2);
        TRACE(_T("%s\n"), m_csLastConErr.GetString());
        int nRes = TKE_NO_TALKER;
        if (rResp.nParam1 == TKE_BAD_VERSION)   // If this looks like too early a Spike2 version
        {                                       // Try to give a more helpful response
            m_csLastConErr = "The Spike2 version is too old (update from CED web site)";
            TRACE(_T("%s\n"), m_csLastConErr.GetString());
            nRes = TKE_BAD_SPEC;
            m_bLowSpec = true;                  // Block further automatic reconnects
        }
        if (rResp.nParam1 == TKE_BAD_CONFIG)    // This is what we get for a missing license
        {                                       // Try to give a more helpful response
            m_csLastConErr = rResp.szParam;     // Information will be sent back by Spike2
            TRACE(_T("%s\n"), m_csLastConErr.GetString());
            nRes = TKE_BAD_CONFIG;
            m_bBadSerial = true;                // Block further automatic reconnects
        }
        return nRes;
    }


    // OK, all is OK and we are ready to go. Get as much stuff as possible into a tidy
    //  state and create the thread that will do the work.
    ResetEvent(m_hStopEvent);                   // Tidy up before we create the thread
    ResetEvent(m_hRxEvent);
    ResetEvent(m_hTxEvent);

    m_nSpecVer = (rResp.nParam2 == 0) ? 1 : rResp.nParam2; // Accept zero as meaning spec ver 1
    if (m_nSpecVer > TALK_SPEC_VER)             // Use the lowest common spec version number
        m_nSpecVer = TALK_SPEC_VER;

    // Now, if the talker interface spec is less than we can operate-with, we need to give up.
    // We don't do that now, but wait until the Spike2 end has started to read our info.
    m_bLowSpec = m_nSpecVer < nMinSpec;
    
    m_bWriting = false;                         // Initialise write control variables
    m_bWPending = false;                        //  and data structures for Tx
    m_dwWBytes = 0;
    memset((void*)&m_rWOl, 0, sizeof(OVERLAPPED));
    m_rWOl.hEvent = m_hTxEvent;                 // Set event used to signal packet write

    m_bReading = false;                         // Initialise read control variables
    m_bRPending = false;                        //  and data structures for Rx
    m_dwRBytes = 0;
    memset((void*)&m_rROl, 0, sizeof(OVERLAPPED));
    m_rROl.hEvent = m_hRxEvent;                 //  and event used to signal packet read
    m_bClosing = false;

    m_hThread = CreateThread(nullptr, 0, TalkerProc, this, 0, nullptr); //  and kick off the thread to do the rest
    if (!m_hThread)                             // Return result is null if thread creation failed
    {
        m_csLastConErr.Format(_T("Talker thread creation failed%s"), LastErrStr().GetString());
        TRACE(_T("%s\n"), m_csLastConErr.GetString());
        return TKE_FAILURE;
    }
    if (!SetThreadPriority(m_hThread, THREAD_PRIORITY_HIGHEST))
    {
        CString wstr;                           // Notify user if this fails
        wstr.Format(_T("Set highest thread priority for talker interface failed%s"), LastErrStr().GetString());
        LogError(wstr, 2, -1, TKE_FAILURE);
    }
    DWORD dwE = GetTickCount() + 500;           // Mimic WaitForState so we can handle errors better
    while (!Connected() && (GetTickCount() < dwE))
        Sleep(5);                               // Give back time while we are waiting
    if (!Connected())                           // If we did not become idle the thread proc failed
    {
        Disconnect(true);                       // Not sure if this achieve anything...
        return TKE_FAILURE;
    }
    return 0;
}

//! Disconnect this talker from Spike2
/*!
This function shuts down the worker thread and then cleans up after disconnection.
\param      bNotify     if true, notify Spike2 that we are disconnecting so that it
                        can clean up its own end of things, if false we don't notify
                        Spike2 because we are disconnecting at it's behest.
\return                 zero if the connection was set up or a negative error code.
*/
int CTalkIF::Disconnect(bool bNotify)
{
    m_bClosing = true;                          // Force read operations to abort

    // Tell Spike2 if wanted and we are running and not disconnected
    if (m_hThread && Connected() && bNotify)
    {
        SendPacket(TKC_TALKERCLOSE);            // Code to say we are closing
        WaitForTxIdle();                        // Wait until queue is empty
    }
    FlushFileBuffers(m_hPipe);                  // Make sure the packet has gone

    // Now we have to get the thread to shut down, it will close the pipe
    if (m_hThread)                              // Thread was created?
    {
        SetEvent(m_hStopEvent);                 // Signal the thread that it should stop
        if (WaitForSingleObject(m_hThread, 200) == WAIT_TIMEOUT)   // Give it 200 milliseconds
            TerminateThread(m_hThread, 0);      //  then kill it off viciously regardless
        CloseHandle(m_hThread);                 // Close the handle as we are terminated
        m_hThread = NULL;
    }

    // The thread should have closed the pipe and set it to NULL. So if it is
    //  non-NULL, we take care of closing it as a last-ditch measure
//    assert(m_hPipe == NULL);                    // This code should not be needed
    if (m_hPipe != NULL)
        CloseHandle(m_hPipe);
    m_hPipe = NULL;

    m_csName.Empty();                           // Tidy up some stuff
    m_csServer.Empty();
    m_errs.clear();                             // No stored errors
    m_pWnd = nullptr;
    m_nSpecVer = 0;
    return WaitForState(TKS_DISCONNECT);        // Wait until all is done
}

//! Helper function used to apply skew to drift info settings
/*!
Starting with the settings supplied, adjust using the supplied scale factors.
We detect parameters that have been left unset to get the defaults and use the
default values in those cases. That is a major reason for this function really;
to keep knowledge of the default values used in Spike2 in one place.

\param  rPkt     A drift info packet holding the data to be modified
\param  dYScale  Scaler for jitter rejection mechanisms
\param  dXScale  Scaler for time range over which drift analysis operates
*/
void CTalkIF::TweakDrift(TalkerDriftInfo& rPkt, double dYScale, double dXScale)
{
    if (dYScale < 0.05)                         // Force the scalings to a plausible
        dYScale = 0.05;                         //  though very wide range
    if (dYScale > 20)
        dYScale = 20;
    if (dXScale < 0.05)
        dXScale = 0.05;
    if (dXScale > 20)
        dXScale = 20;
    if (fabs(dYScale-1.0) >= 0.001)             // Y scale value is in use?
    {                                           // we do nothing if its 1.0
        if (rPkt.dSDDump != 0)                  // This is the limit for hopeless values
            rPkt.dSDDump *= dYScale;            // If caller has set a value then scale it
        else
            rPkt.dSDDump = dYScale * 3;         // otherwise generate scaled default
        if (rPkt.dSDUse != 0)                   // This is the limit for usable values
            rPkt.dSDUse *= dYScale;             // If caller has set a value then scale it
        else
            rPkt.dSDUse = dYScale * 2 ;         // otherwise generate scaled default
    }
    if (fabs(dXScale-1.0) >= 0.001)             // X scale value is in use?
    {                                           // again, do nothing if its 1.0
        if (rPkt.nDrBf > 0)                     // This is the length of the drift buffer
            rPkt.nDrBf = (int)(dXScale * rPkt.nDrBf); // If caller has set a value then scale it
        else if (rPkt.nDrBf < 0)                // Leave zero values (use all points) alone
            rPkt.nDrBf = (int)(dXScale * 1000); // otherwise generate scaled default
        if (rPkt.nDiffAvg > 0)                  // This is the points used for an averaged difference
            rPkt.nDiffAvg = (int)(dXScale * rPkt.nDiffAvg); // If caller has set a value then scale it
        else
            rPkt.nDiffAvg = (int)(dXScale * 20); // otherwise generate scaled default
        if (rPkt.nSlopeAcc > 0)                 // This is the points needed before slope averaging starts
            rPkt.nSlopeAcc = (int)(dXScale * rPkt.nSlopeAcc); // If caller has set a value then scale it
        else
            rPkt.nSlopeAcc = (int)(dXScale * 25); // otherwise generate scaled default
        if (rPkt.nSlopeAvg > 0)                 // This is the points needed before compensation starts
            rPkt.nSlopeAvg = (int)(dXScale * rPkt.nSlopeAvg); // If caller has set a value then scale it
        else
            rPkt.nSlopeAvg = (int)(dXScale * 25); // otherwise generate scaled default
    }
}

/*!
Generate an error record, save it in the queue and notify the window of it.
\param  csErr    A string describing the error in a human-friendly fashion
\param  nLevel   Error level (0 to 3, being info, warning, error and critical)
\param  nChan    The channel number to which the error applies or -1 for all channels
\param  nCode    The (presumed negative) error code
*/
void CTalkIF::LogError(const CString& csErr, int nLevel, int nChan, int nCode)
{
    CTalkErr err(csErr, nLevel, nChan, nCode);  // Build error information object
    m_errs.save(err);                           // Save it in the queue
}

//! Wait for the talker to reach a specified state
/*!
/param      nState      the talker state (TKS_ constant) which we are waiting-for.
/param      dwTO        the timeout period for the wait, in milliseconds, default 500.
/return                 zero if the state was reached or TKE_TIMEOUT if we timed-out.
*/
int CTalkIF::WaitForState(int nState, DWORD dwTO)
{
    int nRes = 0;
    DWORD dwS = GetTickCount();
    while ((State() != nState) && ((GetTickCount()-dwS) < dwTO))
        Sleep(5);                               // Give back time while we are waiting
    if (State() != nState)                      // Did we fail?
    {
        CString str;
        nRes = TKE_TIMEOUT;
        str.Format(_T("Wait for talker %s state to become %d failed"), Name().GetString(), nState);
        TRACE(_T("%s\n"), str.GetString());
        LogError(str, 1, -1, nRes);             // Log a warning
    }
    return nRes;
}

//! Wait for the talker packet transmit buffers to be empty
/*!
/param      dwTO        the timeout period for the wait, in milliseconds, default 500.
/return                 zero if the wait succeeded or TKE_TIMEOUT if we timed-out.
*/
int CTalkIF::WaitForTxIdle(DWORD dwTO /*= 500*/)
{
    if (!Connected())                           // Should not be disconnected
        return TKE_BAD_STATE;

    if (!m_bWriting)                            // Quick exit if no activity
        return 0;

    int nRes = 0;
    DWORD dwS = GetTickCount();
    while (m_bWriting && ((GetTickCount()-dwS) < dwTO))
        Sleep(5);                               // Give back time while we are waiting
    if (m_bWriting)                             // Did we fail?
    {
        CString str;
        nRes = TKE_TIMEOUT;
        str.Format(_T("Wait for talker %s to finish writing failed"), Name().GetString());
        TRACE(_T("%s\n"), str.GetString());
        LogError(str, 2, -1, nRes);             // Log an error
    }
    return nRes;
}

//! Build a TalkPacket indicating a problem using the parameters provided and send it to Spike2
int CTalkIF::SendProblem(int nLev, int nChan, const CString& str)
{
    if (!Connected())                           // Should not be disconnected
        return TKE_BAD_STATE;

    if ((nLev == m_lastProbLev) &&              // If the problem report is the same as the last one
        (nChan == m_lastProbChan) &&
        (str == m_csLastProbStr) &&
        ((GetTickCount() - m_dwLastProbTime) < 2000)) // and the last one was within 2 seconds
        return 0;                               // then do nothing

    m_lastProbLev = nLev;                       // Save the report information
    m_lastProbChan = nChan;
    m_csLastProbStr = str;
    m_dwLastProbTime = GetTickCount();          // and the time we sent it
    TalkPacket rPkt;                            // Constructor will zero the data & set the size
    rPkt.nCode = TKC_TALKERPROBLEM;             // Load up with our parameters
    rPkt.nParam1 = nChan;                       // The default value of all these is zero
    rPkt.nParam2 = nLev;
    int len = str.GetLength();
    if (len > 255)                              // Make sure we don't copy too much
        len = 255;
    if (len > 0)                                //  nor too little...
    {
        CStringA astr(str);                     // We need the string as ASCII
        strncpy_s(rPkt.szParam, 256, astr.GetString(), len+1);
    }
    return SendBlock(&rPkt, sizeof(TalkPacket));
}


//! Build a TalkPacket using the parameters provided and send it to Spike2
int CTalkIF::SendPacket(int nCode, int nP1, int nP2, double dP1,
                        double dP2, const CString* pStr)
{
    if (!Connected())                           // Should not be disconnected
        return TKE_BAD_STATE;

    TalkPacket rPkt;                            // Constructor will zero the data & set the size
    rPkt.nCode = nCode;                         // Load up with our parameters
    rPkt.nParam1 = nP1;                         // The default value of all these is zero
    rPkt.nParam2 = nP2;
    rPkt.dParam1 = dP1;
    rPkt.dParam2 = dP2;
    if (pStr)                                   // Got a string parameter?
    {
        int len = pStr->GetLength();
        if (len > 255)                          // Make sure we don't copy too much
            len = 255;
        if (len > 0)                            //  nor too little...
        {
            CStringA astr(*pStr);               // We need the string as ASCII
            strncpy_s(rPkt.szParam, 256, astr.GetString(), len+1);
        }
    }
    return SendBlock(&rPkt, sizeof(TalkPacket));
}

//! Send a block of memory (assumed to be a valid packet) to Spike2
int CTalkIF::SendBlock(void* pData, DWORD dwSize)
{
    if (!Connected())                           // Should not be disconnected
        return TKE_BAD_STATE;

    if (dwSize > TALK_MAX_PKT)                  // We must not have too much data here
        return TKE_BAD_PACKET;

    //TalkPacket* pPkt = (TalkPacket*)pData;
    //TRACE(_T("TALKIF SendBlock bytes %d, code 0x%08X, size %d\n"), (int)dwSize, pPkt->nCode, pPkt->nSize);
    std::lock_guard<std::mutex> lck(m_mutTx);   // Multi-threaded protection
    std::vector<char> vcPkt(dwSize, 0);         // Make a holder for the output packet
    memcpy(vcPkt.data(), pData, dwSize);        // Copy the data to the holder
    m_qTxPkts.push(vcPkt);                      // Add the vector to the queue
    int nRes = NextPacket();                    // Try to send the new packet
    return nRes;
}

//! Try to send the next packet in the queue
// Note you MUST be holding the tx critical section before you call this function
int CTalkIF::NextPacket()
{
    if (m_bWriting)                             // Do nothing if a write is in progress
        return 0;
    if (m_qTxPkts.size() == 0)                  // Also if the tx queue is empty
        return 0;

    // Now send off the packet
    int nRes = 0;
    m_dwWBytes = 0;                             // Clear the write result
    BOOL bOK = WriteFile(m_hPipe, m_qTxPkts.front().data(), (DWORD)m_qTxPkts.front().size(), (LPDWORD)&m_dwWBytes, &m_rWOl);
    //TalkPacket* pPkt = (TalkPacket*)m_qTxPkts.front().data();
    //TRACE(_T("TALKIF NextPacket bytes %d, code 0x%08X, size %d, OK %d, error code %lu\n"), (int)m_qTxPkts.front().size(), pPkt->nCode, pPkt->nSize, bOK, GetLastError());
    m_bWPending = (!bOK && (GetLastError() == ERROR_IO_PENDING));
    m_bWriting = bOK || m_bWPending;            // Flag for a write ongoing
    if (!m_bWriting)                            // We had a write failure if not writing
    {
        CString str;
        nRes = TKE_BAD_PACKET;
        str.Format(_T("SendBlock write by %s failed%s"), Name().GetString(), LastErrStr().GetString());
        TRACE(_T("%s\n"), str.GetString());
        LogError(str, 2, -1, nRes);             // Log an error
    }
    return nRes;
}

//! Tidy up after a write operation that has finished (immediately or if pending).
/*!
This function is called by the controlling thread after m_rTxEvent has been set to indicate
that the transmit is done.
/return             zero if nothing done (including error) or the positive packet byte count
*/
DWORD CTalkIF::DoneTx()
{
    DWORD dwRes = 0;
    std::lock_guard<std::mutex> lck(m_mutTx);   // Multi-threaded protection
    assert(m_bWriting);
    if (m_bWriting)                             // This had better be the case!
    {
        BOOL bOK = TRUE;                        // Either write was OK or we get result below
        if (m_bWPending)                        // Get the result now if IO was pending
            bOK = GetOverlappedResult(m_hPipe, &m_rWOl, (LPDWORD)&m_dwWBytes, FALSE);
        m_bWPending = false;                    // Nothing pending any more
        //TRACE(_T("TALKIF DoneTx OK %d, bytes %d\n"), bOK, m_dwWBytes);
        if (bOK && (m_dwWBytes == m_qTxPkts.front().size())) // All OK?
            dwRes = m_dwWBytes;                 // Return byte count for success
        else                                    // Here for a write error - tell Spike2
        {
            CString str;
            str.Format(_T("DoneTx packet write by %s failed, wrote %d, got %lu%s"), Name().GetString(), m_qTxPkts.front().size(), m_dwWBytes, LastErrStr().GetString());
            TRACE(_T("%s\n"), str.GetString());
            LogError(str, 3, -1, TKE_FAILURE);  // Log a critical error
        }
        ResetEvent(m_hTxEvent);                 // As we are done now, we can clean up
        m_qTxPkts.pop();                        // Get rid of the now-transmitted packet
        m_bWriting = false;
        m_bWPending = false;
        m_dwWBytes = 0;
        NextPacket();                           // Try to send the next packet
    }
    return dwRes;
}

//! Function to keep read operations on-going
int CTalkIF::MaintainRx()
{
    int nRes = 0;
    if (m_bClosing)                             // Do nothing if we are closing down
        return 0;
    std::lock_guard<std::mutex> lck(m_mutRx);   // Multi-threaded protection
    if (!m_bReading)                            // Only do anything if no read in progress
    {
        BOOL bOK = ReadFile(m_hPipe, (void*)m_pInBuf, TALK_TALKER_BSIZE/2, (LPDWORD)&m_dwRBytes, &m_rROl);
        m_bRPending = (!bOK && (GetLastError() == ERROR_IO_PENDING));
        m_bReading = bOK || m_bRPending;        // Flag for a read ongoing
        if (!m_bReading)                        // We had a failure if not reading
        {
            CString str;
            nRes = TKE_FAILURE;
            str.Format(_T("MaintainRx packet read by %s failed%s"), Name().GetString(), LastErrStr().GetString());
            TRACE(_T("%s\n"), str.GetString());
            LogError(str, 3, -1, nRes);         // Log a critical error
        }
    }
    return nRes;
}

// This is a structure used to hold information about talker packets for initial checks 
//  after something has been received. Basically it defines the packets that can be accepted
//  in a given situation and information for checking them, so that by the time we have
//  passed though the tests, we know we have a good packet.
typedef struct TalkFilt
{
    int     nCode;                              //< The relevant talker code
    int     nSize;                              //< Required size if +ve or -ve size that must be exceeded
    int     nMinSpec;                           //< Minimum spec level or packet is dumped
} TalkFilt;

// Message filter for the idle talker state.
TalkFilt g_arIdleF[] = {
    {TKC_GETINFO,       sizeof(TalkPacket),    1},
    {TKC_GETCHAN,       sizeof(TalkPacket),    1},
    {TKC_GETCONFIG,     sizeof(TalkPacket),    1},
    {TKC_SETCONFIG,     -((int)sizeof(TalkPacket)),    1},
    {TKC_LOCALCONFIG,   sizeof(TalkPacket),    1},
    {TKC_DLGINFO,       sizeof(TalkPacket),    1},
    {TKC_DLGITEM,       sizeof(TalkPacket),    1},
    {TKC_DLGGET,        sizeof(TalkPacket),    1},
    {TKC_DLGSET,        sizeof(TalkPacket),    1},
    {TKC_SAMPLECLEAR,   sizeof(TalkPacket),    1},
    {TKC_ENABLECHAN,    sizeof(TalkPacket),    1},
    {TKC_DRIFTINFO,     sizeof(TalkPacket),    1},
    {TKC_QUERYREADY,    sizeof(TalkPacket),    1},
    {TKC_SAMPLESTART,   sizeof(TalkPacket),    1},
    {TKC_SENDSTRING,    sizeof(TalkPacket),    2},
    {TKC_COMMAND,       sizeof(TalkPacket),    4},
    {TKC_XMLNAMEVAL,    sizeof(TalkPacket),    3},
    {TKC_XMLVALUE,      sizeof(TalkPacket),    3},
    {TKC_TALKERCLOSE,   sizeof(TalkPacket),    1}
};

// Message filter for the active (sampling) state.
TalkFilt g_arActiveF[] = {
    {TKC_SAMPLESTOP,    sizeof(TalkPacket),    1},
    {TKC_SAMPLEKEY,     sizeof(TalkPacket),    1},
    {TKC_SENDSTRING,    sizeof(TalkPacket),    2},
    {TKC_COMMAND,       sizeof(TalkPacket),    4},
    {TKC_TALKERCLOSE,   sizeof(TalkPacket),    1}
};


//! Function to finish off the IO for a read operation and check packet
/*!
Finish off the IO for a read operation (has to be done if pending). This function
is called by the worker thread when m_hRxEvent has been set to indicate a read done.

After checking for errors, we also check incoming packets against the filters, so that
the more awful errors can be detected automatically, we send an error response to
Spike2 if the packet is rejected here.
/return             false for a bad packet or failed read, true if all OK, in which
                    case the relevant window has been notified of a checked packet.
*/
bool CTalkIF::NotifyRx()
{
    if (m_bClosing)                             // Do nothing if we are closing down
    {
        ResetEvent(m_hRxEvent);                 // Reset the read packet event to avoid deadlock
        return false;
    }
    m_mutRx.lock();                             // Multi-threaded protection
    assert(m_bReading);
    if (m_bReading)                             // This had better be the case!
    {
        BOOL bOK = TRUE;                        // Either read was OK or we get result below
        if (m_bRPending)                        // Get the result now if IO was pending
            bOK = GetOverlappedResult(m_hPipe, &m_rROl, (LPDWORD)&m_dwRBytes, FALSE);
        m_bRPending = false;                    // Nothing pending any more
        volatile TalkPacket* pPkt = RxBuf();    // Data access
//        TRACE(_T("NotifyRx got a packet, read %d, code 0x%08X, size %d\n"), m_dwRBytes, pPkt->nCode, pPkt->nSize);
        ResetEvent(m_hRxEvent);                 // Reset the read packet event while still protected
        m_mutRx.unlock();
        if (!bOK)
        {                                       // Deal with a bad read here
            CString str;
            str.Format(_T("Packet read by %s failed%s"), Name().GetString(), LastErrStr().GetString());
            TRACE(_T("%s\n"), str.GetString());
            LogError(CString(str), 3, -1, TKE_FAILURE);  // Log a critical error
            if (!Active())                      // Notify Spike2 as best we can
                SendPacket(TKC_RESPONSE_BIT | TKC_ERROR_BIT, TKE_FAILURE, 0, 0, 0, &str);
            else 
                SendProblem(1, -1, str);        // Send a problem report
            return false;                       // That's all we can do here
        }

        // Sort out which filters we are using
        TalkFilt* pFilt = Active() ? g_arActiveF : g_arIdleF;
        int limit = Active() ? sizeof(g_arActiveF) : sizeof(g_arIdleF);
        limit /= sizeof(TalkFilt);              // Number of filter entries

        // Now find an entry for this packet in the filter tables
        int iFilt;
        for (iFilt = 0; iFilt < limit; ++iFilt)
        {
            if ((pPkt->nCode & 0xffff) == pFilt[iFilt].nCode)
                break;
        }

        // If we didn't find it in the filter tables it's an invalid packet. Dump it.
        if (iFilt >= limit)                     // An unknown packet code?
        {
            CString str;
            str.Format(_T("Unknown command received for %s, code %d (0x%08X), param1 %d"), Name().GetString(), pPkt->nCode, pPkt->nCode, pPkt->nParam1);
            TRACE(_T("%s\n"), str.GetString());
            LogError(str, 2, -1, TKE_BAD_PACKET); // Log an error
            if (!Active())                      // Notify Spike2 as best we can
                SendPacket(pPkt->nCode | TKC_RESPONSE_BIT | TKC_ERROR_BIT, TKE_BAD_COMMAND, 0, 0, 0, &str);
            else
                SendProblem(1, -1, str);        // Send a problem report
            return false;
        }

        // Now we can check that the packet size matches the filter. Or it's dumped.
        if ((pPkt->nSize != (int)m_dwRBytes) || // Packet matches the read
            ((pFilt[iFilt].nSize > 0) && (pPkt->nSize != pFilt[iFilt].nSize)) || // Equals fixed size
            ((pFilt[iFilt].nSize < 0) && (pPkt->nSize <= -pFilt[iFilt].nSize)))  // Not more than mimimum
        {
            CString str;
            if (pFilt[iFilt].nSize > 0)
                str.Format(_T("Talker command %d received from %s, but size wrong: read %d, size in packet %d, expected %d"), pPkt->nCode & 0xffff, Name().GetString(), m_dwRBytes, pPkt->nSize, g_arIdleF[iFilt].nSize);
            else
                str.Format(_T("Talker command %d received from %s, but size wrong: read %d, size in packet %d, expected more than %d"), pPkt->nCode & 0xffff, Name().GetString(), m_dwRBytes, pPkt->nSize, -g_arIdleF[iFilt].nSize);
            TRACE(_T("%s\n"), str.GetString());
            LogError(str, 2, -1, TKE_BAD_PACKET); // Log an error
            if (!Active())                      // Notify Spike2 as best we can
                SendPacket(pPkt->nCode | TKC_RESPONSE_BIT | TKC_ERROR_BIT, TKE_BAD_PACKET, 0, 0, 0, &str);
            else
                SendProblem(1, -1, str);        // Send a problem report
            return false;
        }

        // Dump any packets requiring too high a specification version. This should never
        // happen unless something has gone very wrong with Spike2
        if (pFilt[iFilt].nMinSpec > m_nSpecVer) // We are running at too low a spec version?
        {
            CString str;
            str.Format(_T("Talker command %d received from %s, but needs specification version %d while we are using version %d"), pPkt->nCode & 0xffff, Name().GetString(), pFilt[iFilt].nMinSpec, m_nSpecVer);
            TRACE(_T("%s\n"), str.GetString());
            LogError(str, 2, -1, TKE_BAD_VERSION); // Log an error
            if (!Active() &&                    // Notify Spike2 as best we can
                (pFilt[iFilt].nCode != TKC_SENDSTRING) && // No response to SENDSTRING
                (pFilt[iFilt].nCode != TKC_COMMAND)) // or to COMMAND
            {
                SendPacket(pPkt->nCode | TKC_RESPONSE_BIT | TKC_ERROR_BIT, TKE_BAD_VERSION, 0, 0, 0, &str);
            }
            else if (Active())
                SendProblem(1, -1, str);        // Send a problem report
            return false;
        }

        // Save the Spike2 version number passed in the GetInfo request. Also force an error response
        // if Spike2 supports too low a talker specification version, causing Spike2 to disconnect.
        if (pPkt->nCode == TKC_GETINFO)         // At this point the packet has passed all the tests
        {
            m_nSpike2Ver = pPkt->nParam1;       // Try to retrieve the Spike2 version number
            if (m_bLowSpec || m_bBadSerial)     // Here is where we react to a low specification version or serial no bypass
            {                                   // by forcing an error response
                SendPacket(TKC_GETINFO|TKC_RESPONSE_BIT|TKC_ERROR_BIT, TKE_BAD_VERSION); // This forces Spike2 to disconnect
                DoneRx();                       // Clean up after this packet
                CString str;
                int nErr = TKE_BAD_VERSION;
                if (m_bLowSpec)
                {
                    str.Format(_T("Specification version (%d) supported by Spike2 is too low, forcing disconnect"), m_nSpecVer);
                    nErr = TKE_BAD_SPEC;
                }
                else
                    str = "Spike2 serial number was incorrect, forcing disconnect";
                TRACE(_T("%s\n"), str.GetString());
                LogError(str, 3, -1, nErr);     // Log a critical error
                return true;                    //  and exit early
            }
        }
        else if ((pPkt->nCode != TKC_TALKERCLOSE) && m_bLowSpec) // We should never get here with the low spec flag set
        {                                       // so if we are here there is something very wrong
            SendPacket(pPkt->nCode|TKC_RESPONSE_BIT|TKC_ERROR_BIT, TKE_BAD_VERSION);
            DoneRx();                           // Clean up after this packet
            CString str;
            str.Format(_T("Failed auto-close with low (%d) specification version, disconnecting immediately (may hang Spike2)"), m_nSpecVer);
            TRACE(_T("%s\n"), str.GetString());
            LogError(str, 3, -1, TKE_BAD_SPEC); // Log a critical error
            LogError(_T(""), -1, -1, 0);        // Log special error to cause a disconnect
            return true;                        //  and exit early
        }
    }
    else                                        // If we are not reading, something is very wrong....
    {                                           //  so wrong that this will probably never happen
        ResetEvent(m_hRxEvent);                 // Reset the read packet event while still protected
        m_mutRx.unlock();
        CString str;
        str.Format(_T("Packet read by %s when no read operation used%s"), Name().GetString(), LastErrStr().GetString());
        TRACE(_T("%s\n"), str.GetString());
        LogError(str, 3, -1, TKE_FAILURE);      // Log a critical error
        if (Active())                           // Notify Spike2 as best we can, a response is incorrect I think
            SendProblem(2, -1, str);            // Send a problem report
        return false;
    }

    // If we got here all is well, so notify the relevant window of a good packet
    m_pWnd->PostMessage(TKN_PACKET, 0, (LPARAM)this);
    return true;
}

//! Function to be called after received packet is done with, allows another packet read
int CTalkIF::DoneRx()
{
    if (!Connected())                           // Should not be disconnected
        return TKE_BAD_STATE;
    {
        std::lock_guard<std::mutex> lck(m_mutRx); // Multi-threaded protection
        m_bReading = false;                     // Just for this bit
        m_bRPending = false;
        m_dwRBytes = 0;
    }
    MaintainRx();                               //  kick off the Rx once again
    return 0;
}

//! The thread procedure that does all actual talker communications
// This function is called by the m_hThread thread to manage all comms.
// Strictly not for use by anything else.
//
// It is called (by thread creation) once the main talker interface code has
//  got a good response back from Spike2 in reply to a TALKERCONNECT request.
// It creates the named pipe and loops while managing the connection for the
//  talker. Once the loop finishes we tidy up and exit.
int CTalkIF::ThreadProc()
{
    // The first thing to do is to open our pipe using the name based upon our talker
    //  name. We do this repeatedly to give Spike2 a chance to get it's act together.
    CString csPipe = _T("\\\\") + Server() + _T("\\pipe\\") + CString{ TALK_TALKER_PIPE };
    if (m_nPipeID > 0)                          // If not the default, amend pipe name
    {
        csPipe = csPipe.Left(csPipe.GetLength() - 1); // Remove trailing _ character
        TCHAR cp = (TCHAR)('0' + m_nPipeID);    // Get 1 to 9 as a character
        csPipe += cp;                           // and append it to the pipe name
        csPipe += '_';                          // put back the trailing _ character
    }
    csPipe += Name();                           // Finally,append the talker name

    DWORD dwS = GetTickCount();                 // Start time saved in case of problem
    while(1) 
    {
        // I have put the sleep at the start of the loop to avoid a problem when the talker
        //  opens the pipe before Spike2 creates it. This would cause earlier versions of
        //  Spike2 to fail to connect (due to a coding error). The issue is fixed in Spike2
        //  versions 7.19 and 8.12 so we can change back later if we want.
        Sleep(50);                              // To avoid thrashing, sleep a bit
        m_hPipe = CreateFile( 
            csPipe,                             // pipe name 
            GENERIC_READ|GENERIC_WRITE,         // Duplex access
            0,                                  // no sharing 
            nullptr,                            // default security attributes
            OPEN_EXISTING,                      // opens existing pipe 
            FILE_FLAG_OVERLAPPED,               // Overlapped I/O
            NULL);                              // no template file 

        // Break if the pipe handle is valid as this means we have opened it OK
        if (m_hPipe != INVALID_HANDLE_VALUE) 
            break;

        // Give up if we are past the timeout time (4000 ms) as this is not going to work...
        if ((GetTickCount() - dwS) >= 4000)
        {
            m_csLastConErr.Format(_T("Timed-out trying to open pipe %s%s"), csPipe.GetString(), LastErrStr().GetString());
            TRACE(_T("%s\n"), m_csLastConErr.GetString());
            m_hPipe = NULL;                     // Make sure pipe handle is clean
            return 0;
        }
    }

    // The pipe opened OK, change to message-read mode. Don't set maximum bytes
    //  or time.
    DWORD dwMode = PIPE_READMODE_MESSAGE;
    BOOL fSuccess = SetNamedPipeHandleState(m_hPipe, &dwMode, nullptr, nullptr);
    if (!fSuccess)                              // Error will be logged by Connect()
    {                                           // but we need to save an error string
        m_csLastConErr.Format(_T("SetNamedPipeHandleState on %s pipe failed%s"), csPipe.GetString(), LastErrStr().GetString());
        TRACE(_T("%s\n"), m_csLastConErr.GetString());
        CloseHandle(m_hPipe); 
        m_hPipe = NULL;                         // Make sure pipe handle is clean
        return 0;
    }
    SetState(TKS_IDLE);                         // We are now in the idle state

    bool bStop = false;                         // Keep going until this is true
    HANDLE hArray[3];                           // For waiting for multiple objects
    hArray[0] = m_hTxEvent;                     // First wait is for transmit done
    hArray[1] = m_hRxEvent;                     //  the second is for packet receive
    hArray[2] = m_hStopEvent;                   //  and the third is the stop request

    TRACE(_T("Talker %s connection now open for use\n"), Name().GetString());
    while(!bStop)
    {
        try
        {
            MaintainRx();                       // make sure read operation is on-going
            switch (WaitForMultipleObjects(3, hArray, FALSE, INFINITE))
            {
            case WAIT_OBJECT_0:                 // Here for transmit done
                DoneTx();                       // Tidy up after transmit so OK for next one
                break;
            case WAIT_OBJECT_0+1:               // Here for packet read event
                if (!NotifyRx())                // Read the data into the buffer and notify
                    DoneRx();                   // Finish off after a bad read
                break;
            default:                            // Any other result is the stop event
                bStop = true;                   // So just stop, please
                break;
            }
            if (!Connected())                   // Also stop if state disconnected
                bStop = true;
        }
        catch(CException* pe)
        {
            TCHAR szCause[512];
            pe->GetErrorMessage(szCause, 512);
            CString csInfo;
            csInfo.Format(_T("Talker %s communications handling caused exception: %s, terminating"), Name().GetString(), szCause);
            LogError(csInfo, 3, -1, TKE_FAILURE);
            bStop = true;                       // An exception causes talker to exit
            pe->Delete();
        }
    }

    TRACE(_T("Talker %s disconnecting\n"), Name().GetString());
    SetState(TKS_DISCONNECT);                   // Tidy up the talker
    m_errs.clear();                             // No stored errors
    CloseHandle(m_hPipe);                       // Close the pipe
    m_hPipe = NULL;
    return 0;
}